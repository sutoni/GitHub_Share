<?php
session_start();
include "config/conn.php";


function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['username']);
$pass     = anti_injection(md5($_POST['password']));


// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  echo "Mohon maaf sekali, anda tidak bisa memasuki program ini.";
}
else{
    
    $login="SELECT * FROM user WHERE username='$username' AND passuser='$pass' AND blokir='N'";
    $hasil=  mysql_query($login);
    $ketemu=mysql_num_rows($hasil);
   echo "$login";
// Apabila username dan password ditemukan
if ($ketemu==1){
    
 
  include "config/fungsi_indotgl.php";
  $r=mysql_fetch_array($hasil); 
    $usernya=$r['username'];
    echo "$usernya";
        $_SESSION[username]     = $r['username'];
        $_SESSION[namalengkap]  = $r['nama_lengkap'];
        $_SESSION[passuser]     = $r['passuser'];
        $_SESSION[level]    = $r['level'];
  
	$sid_lama = session_id();
	session_regenerate_id();
	$sid_baru = session_id();
	$namauser= $_SESSION['namalengkap'];
        
	//cek user online
	
	$today = date("H:i:s"); 
	$tgl = date("Y-m-d");

	
				
	
		$masuk1 = "INSERT INTO log_user values 
			('',
			'$usernya',
			'$tgl',
			'$today',
			'logged',
			'online'
			)"; 
				$hasil1 = mysql_query($masuk1);	
	
	
	
	
	
     echo"";
	  mysql_query("UPDATE user SET id_session='$sid_baru' WHERE username='$username'");
   header('location:media.php?module=home');
}
else{
  echo "<link href=../config/adminstyle.css rel=stylesheet type=text/css>";
  echo "<center>LOGIN GAGAL! <br> 
        Username atau Password Anda tidak benar.<br>
        Atau account Anda sedang diblokir.<br>";
  echo "<a href=index.php><b>ULANGI LAGI</b></a></center>";
}
}
?>

