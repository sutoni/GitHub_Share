<?php
class core_db extends PDO{
    private $engine;
    private $host;
    private $database;
    private $user;
    private $pass;
 
    private $result;    
 
    public function __construct()
        {
        $this->engine   = 'mysql';
        $this->host     = 'localhost';
        $this->database = 'hrsd_dev';
        $this->user     = 'root';
        $this->pass     = '';
 
        $dns = $this->engine.':dbname='.$this->database.";host=".$this->host;
        parent::__construct( $dns, $this->user, $this->pass );
    }   
 
        public function getResult()
        {
         return $this->result;
         }
}
 
?>