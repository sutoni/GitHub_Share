<?php


if($_GET['module']=="siswa"){
include "module/siswa/siswa.php";
}
if($_GET['module']=="tampil"){
include "module/siswa/tampil.php";
}
if($_GET['module']=="input_siswa"){
include "module/siswa/input_siswa.php";
}
if($_GET['module']=="siswa_det"){
include "module/siswa/siswa_det.php";
}
if($_GET['module']=="detail_siswa"){
include "module/siswa/detail_siswa.php";
}

if($_GET['module']=="pilih"){
include "module/absen/pilih.php";
}
if($_GET['module']=="pilih_view"){
include "module/absen/pilih_view.php";
}

if($_GET['module']=="input_absen"){
include "module/absen/input_absen.php";
}
if($_GET['module']=="absen"){
include "module/absen/absen.php";
}
if($_GET['module']=="pilih_laporan"){
include "module/laporan/pilih_laporan.php";
}
if($_GET['module']=="laporan"){
include "module/laporan/laporan.php";
}
if($_GET['module']=="user"){
include "module/user/user.php";
}
if($_GET['module']=="input_user"){
include "module/user/input_user.php";
}

if($_GET['module']=="input_guru"){
include "module/guru/input_guru.php";
}
if($_GET['module']=="detail_guru"){
include "module/guru/detail_guru.php";
}
if($_GET['module']=="guru_det"){
include "module/guru/guru_det.php";
}

if($_GET['module']=="guru"){
include "module/guru/guru.php";
}
if($_GET['module']=="tampil_guru"){
include "module/guru/tampil_guru.php";
}
if($_GET['module']=="input_kelas"){
include "module/kelas/input_kelas.php";
}
if($_GET['module']=="kelas"){
include "module/kelas/kelas.php";
}
if($_GET['module']=="input_sekolah"){
include "module/sekolah/input_sekolah.php";
}
if($_GET['module']=="sekolah"){
include "module/sekolah/sekolah.php";
}


if($_GET['module']=="form_pelamar"){
include "module/data_pelamar/form_pelamar.php";
}

if($_GET['module']=="simpan"){
include "module/simpan.php";
}

//Basic Konfigurasi
if($_GET['module']=="orglevel"){
include "module/organization/org_level.php";
}

if($_GET['module']=="orgstruktur"){
include "module/organization/org_struktur.php";
}
if($_GET['module']=="view_organization"){
include "module/organization/view_organization.php";
}
if($_GET['module']=="rec_costitem"){
include "module/recruitment_base/rec_costitem.php";
}
if($_GET['module']=="rec_budget"){
include "module/recruitment_base/rec_budget.php";
}
if($_GET['module']=="rec_activity"){
include "module/recruitment_base/rec_activity.php";
}
if($_GET['module']=="mcu_vendor"){
include "module/medical_checkup/mcu_vendor.php";
}
if($_GET['module']=="psi_vendor"){
include "module/biro_psikolog/psi_vendor.php";
}
if($_GET['module']=="view_companyoffice"){
include "module/biro_psikolog/psi_vendor.php";
}
if($_GET['module']=="rec_periode"){
include "module/recruitment_base/rec_periode.php";
}
if($_GET['module']=="rec_event"){
include "module/recruitment_base/rec_event.php";
}
if($_GET['module']=="rec_calendar"){
include "pages/calendar.html";
}
if($_GET['module']=="rec_calendar2"){
include "calendar.html";
}
if($_GET['module']=="rec_method"){
include "module/recruitment_base/rec_method.php";
}
if($_GET['module']=="rec_step"){
include "module/recruitment_base/rec_step.php";
}
if($_GET['module']=="view_recbase"){
include "module/recruitment_base/view_recbase.php";
}
if($_GET['module']=="edu_level"){
include "module/education/edu_level.php";
}
if($_GET['module']=="edu_institusi"){
include "module/education/edu_institusi.php";
}
if($_GET['module']=="pos_industry"){
include "module/position/pos_industry.php";
}
if($_GET['module']=="pos_areajob"){
include "module/position/pos_jobareafunctional.php";
}
if($_GET['module']=="pos_jobfam"){
include "module/position/pos_jobfam.php";
}
if($_GET['module']=="pos_class"){
include "module/position/pos_class.php";
}
if($_GET['module']=="pos_struktur"){
include "module/position/pos_struktur.php";
}

if($_GET['module']=="view_position"){
include "module/position/view_position.php";
}
if($_GET['module']=="org_compoff"){
include "module/organization/comp_office.php";
}
if($_GET['module']=="org_compcat"){
include "module/organization/comp_category.php";
}
if($_GET['module']=="org_compoffgroup"){
include "module/organization/comp_office_group.php";
}
if($_GET['module']=="view_company"){
include "module/organization/view_company.php";
}

//Applicant Information - Register
if($_GET['module']=="import_apppsikotest"){
include "module/data_pelamar/import_applicantpsikotest.php";
}
if($_GET['module']=="import_appinterviewhr"){
include "module/data_pelamar/import_applicantinterviewhr.php";
}
if($_GET['module']=="import_appexperience"){
include "module/data_pelamar/import_applicantexp.php";
}
if($_GET['module']=="import_appeducation"){
include "module/data_pelamar/import_applicantedu.php";
}
if($_GET['module']=="import_apppersonal"){
include "module/data_pelamar/import_applicanpersonal.php";
}
//
if($_GET['module']=="import_assessment"){
include "module/prp/import_assessment.php";
}
if($_GET['module']=="app_overview"){
include "module/data_pelamar/view_applicant.php";
}
//Applicant Information - WIDGET
if($_GET['module']=="app_widget"){
include "module/data_pelamar/applicant_reg.php";
}
//Applicant Information - WIDGET
if($_GET['module']=="app_screening"){
include "module/data_pelamar/applicant_screening.php";
}
if($_GET['module']=="home"){
include "module/dashboard/dashboard-front.php";
}
if($_GET['module']=="dashboard-development"){
include "module/dashboard/dashboard-development.php";
}
if($_GET['module']=="dashboard-assessment"){
include "module/dashboard/dashboard-assessment.php";
}
//Dashboard - 
if($_GET['module']=="dashboard-marketing"){
include "module/dashboard/dashboard-marketing.php";
}
//Dashboard - 
if($_GET['module']=="dashboard-line"){
include "module/dashboard/inline.php";
}
//Dashboard Screening Process 
if($_GET['module']=="dashboard-process"){
include "module/dashboard/dashboard-proses.php";
}
//Dashboard Activity 
if($_GET['module']=="dashboard-activity"){
include "module/dashboard/dashboard-activity.php";
}
//recruitment view man power planning - 
if($_GET['module']=="view_transrec"){
include "module/recruitment_base/view_transrec.php";
}
//registrasi MCU
if($_GET['module']=="reg_mcu"){
include "module/medical_checkup/reg_mcu.php";
}
//Berhenti
if($_GET['module']=="berhenti"){
include "module/berhenti/importpa.php";
}
//Fullfillment Berhenti
if($_GET['module']=="dashboard-turnover"){
include "module/dashboard/fullfillement-berhenti.php";
}
if($_GET['module']=="dashboard-turnover-mr"){
include "module/dashboard/fullfillement-berhenti-mr.php";
}
if($_GET['module']=="fullfillment"){
include "module/dashboard/fullfillement.php";
}

if($_GET['module']=="dashboard-front"){
include "module/dashboard/dashboard-front.php";
}

if($_GET['module']=="exitinterview"){
include "module/berhenti/dashboard-ExitInt.php";
}
if($_GET['module']=="exitinterviewunit"){
include "module/berhenti/dashboard-ExitInt_unit.php";
}
if($_GET['module']=="exitinterviewposition"){
include "module/berhenti/dashboard-ExitInt_position.php";
}
if($_GET['module']=="viewexitint"){
include "module/berhenti/view_Exitint.php";
}
//Personnel Action 
if($_GET['module']=="personnelaction"){
include "module/mon_performance/index2.php";
}
//Exit Interview 
if($_GET['module']=="inExitinterview"){
include "module/berhenti/in_exitinterview.php";
}
//Cari karyawan berhenti 
if($_GET['module']=="caribht"){
include "module/berhenti/cari_karybht.php";
}
if($_GET['module']=="aksiExitinterview"){
include "module/berhenti/aksi_exitinterview.php";
}
if($_GET['module']=="docresign"){
include "module/berhenti/view_berkas.php";
}
if($_GET['module']=="details_berkas"){
include "module/existing_employee/details_berkas.php";
}
if($_GET['module']=="view_berkaskaryawan"){
include "module/existing_employee/view_berkaskaryawan.php";
}
//organization mapping
if($_GET['module']=="import_orgmapping"){
include "module/organization/import_orgmapping.php";
}
//import RKTK
if($_GET['module']=="import_rktk"){
include "module/recruitment_base/import_rktk.php";
}
if($_GET['module']=="rktk_ifs"){
include "module/manpower/rktk_ifs.php";
}
if($_GET['module']=="family_employee"){
include "module/existing_employee/import_keluarga.php";
}
//Import Position mapping
if($_GET['module']=="import_positionmapping"){
include "module/position/import_positionmapping.php";
}
//Import existing employee
if($_GET['module']=="import_empexist"){
include "module/existing_employee/import_existingemployee.php";
}
//Surat Pengantar MCU
if($_GET['module']=="surket"){
include "module/medical_checkup/suratpengantar_mcu.php";
}
if($_GET['module']=="printsurket"){
include "module/medical_checkup/invoice-print.html";
}
//performance management
if($_GET['module']=="strategi_individual"){
include "module/mon_performance/view_performance.php";
}
if($_GET['module']=="import_prpinformation"){
include "module/prp/import_prpinformation.php";
}
if($_GET['module']=="view_prp"){
include "module/prp/view_prpinformation.php";
}

if($_GET['module']=="useradd"){
include "module/mod_users/users.php";
}
if($_GET['module']=="aksi_user"){
include "module/mod_users/aksi_users.php";
}
if($_GET['module']=="edituser"){
include "module/mod_users/editusers.php";
}
if($_GET['module']=="userpass"){
include "module/mod_users/users.php";
}
//Rayon
if($_GET['module']=="stdrayon_import"){
include "module/manpower/importstdrayon.php";
}
if($_GET['module']=="rayonperemployee"){
include "module/manpower/import_rayonperemp.php";
}
if($_GET['module']=="smbyorgcoy"){
include "module/manpower/import_sm_byorgcoy.php";
}
if($_GET['module']=="smbyrayon"){
include "module/manpower/import_smbyrayon.php";
}

//IDP
if($_GET['module']=="import_idpgambaran"){
include "module/idp/import_gambaran.php";
}
if($_GET['module']=="import_programidp"){
include "module/idp/import_idp_transaksi.php";
}
if($_GET['module']=="view_pdf"){
include "module/idp/view_idp.php";
}
if($_GET['module']=="view_strength"){
include "module/idp/view_gambaran.php";
}
if($_GET['module']=="training_participant"){
include "module/import/import_trainingparti.php";
}


if($_GET['module']=="logout"){
include "module//logout.php";
}


?>


