<?php
	
	session_start();
	include "config/conn.php";
	
        
	$usersekarang=$_SESSION['username'];
     
        
  
 
  
  $jam = date("H:i:s");
                      
  $update=("UPDATE log_user SET jamout='$jam',
                              status='offline'
				WHERE username = '$usersekarang' AND jamout='00:00:00' AND status='online'");
  $hasil=mysql_query($update);
 
  
  session_destroy();
  echo "<center>Anda telah sukses keluar sistem <b>[LOGOUT]<b><br>";
  echo "<a href=http://192.168.86.53/human_resources><b>LOGIN<b></a><br>";

// Apabila setelah logout langsung menuju halaman utama website, aktifkan baris di bawah ini:

//  header('location:http://www.alamatwebsite.com');
?>
	