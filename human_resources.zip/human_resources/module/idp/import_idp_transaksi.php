<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Import Development Personal</h1> 
              <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Import</a></li>
            <li class="active">Import Development Plan</li>
          </ol>
        </section>
        <BR><BR>
                <div class="box-body">
                    <form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
                        <font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
                        <input type='file' name='filename' size='20'><br>
                        <input type='submit' name='submit' value='Insert'>
                        
                                    <?php



                                    include "config/conn.php";
                                    if(isset($_POST['submit']))
                                    {
                                    $target_path = 'c:\xampp\htdocs\human_resources\test';  

                                    $target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

                                    if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
                                    echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
                                    } else{
                                    echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
                                    } // ini untuk mengupload file CSV ke alamat tadi
                                    // ini script untuk mengimport data CSV ke MySQL
                                    $filename=$target_path;
                                    $handle = fopen("$filename", "r");
                                    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE)
                                    {
                                            $idgambaran=$data[1];                                           
                                            $querycek="SELECT COUNT(ididp)as Jumlah
                                                       FROM idp_transaksi
                                                       WHERE ididp='$idgambaran'";
                                            $hasilcek=mysql_query($querycek);
                                               
                                            echo "$idgambaran";
                                            $row=mysql_fetch_array($hasilcek);                                                
                                                $progdesc=$data[1];
                                                $idprogram=  substr($data[9],0,4);
                                                $loginput=DATE('Y-m-d');
                                                $logupdate=DATE('Y-m-d');
                                                $loguser='admin';
                                                
                                                echo "$progdesc";
                                                $row1=$row[Jumlah];
                                                if($row1 > 0){
                                                $ididp=$data[1];
                                               
                                                
                                               
                                                $tujuanprogram=$data[12];
                                                $isiprogram=$data[13];
                                                $istatus=$data[14];
                                                $tglplan=$data[15];
                                                
                                                $keterangan=$data[11];
                                                $evaluasi=$data[12];
                                                $kesesuaian=$data[13];    
                                                $loginput=DATE(Y-m-d);
                                                $logupdate=DATE(Y-m-d);
                                                $loguser='admin';
                                                
                                               $updatepa    =" UPDATE idp_transaksi SET
                                                                    
                                                                    isiprogram       =   '$isiprogram',
                                                                    istatus      =   '$istatus',
                                                                    tglplan          =   '$tglplan',
                                                                    keterangan        =   '$keterangan'
                                                                  
                                                                    WHERE ididp  =   '$ididp'";       
                                                                $masuk=  mysql_query($updatepa); 

                                                }               

                                            else {
                                                $sekarang=DATE('Y-m-d');
                                                
                                    $import="INSERT into idp_transaksi values(
                                             '$data[1]','$data[14]','$data[15]','$data[16]','$data[18]','$data[17]','$data[19]','$data[21]','$data[22]','$data[23]','$data[24]','$data[25]','$data[26]'
                                            )";
                                    $masuk=  mysql_query($import);
                                           // '$data[1]','$idprogram','$data[9]','','$data[10]','$data[11]','$data[13]','$data[12]','','sesuai','$sekarang','$sekarang','admin'
                                            }
                                    }
                                    
                                    fclose($handle);
                                            echo "<script>window.alert(' Terima kasih yaa, Data Telah Terimport');
                                                 window.location=('?module=view_pdf')</script>";
                                           
                                           

                                           }
                                    else
                                    {

                                    print "";
                                    }

                                    ?>
                    </form>
                    
                </div>
        





</BODY>
</HTML>
