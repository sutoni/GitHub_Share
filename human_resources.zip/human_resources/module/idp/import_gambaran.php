<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Import Gambaran Personal</h1> 
              <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Import</a></li>
            <li class="active">Import Gambaran IDP</li>
          </ol>
        </section>
        <BR><BR>
                <div class="box-body">
                    <form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
                        <input type='file' name='filename' size='20'><br>
                        <input type='submit' name='submit' value='Insert'>
                        
                                    <?php



                                    include "config/conn.php";
                                    if(isset($_POST['submit']))
                                    {
                                    $target_path = 'c:\xampp\htdocs\human_resources\test';  

                                    $target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

                                    if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
                                    echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
                                    } else{
                                    echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
                                    } // ini untuk mengupload file CSV ke alamat tadi
                                    // ini script untuk mengimport data CSV ke MySQL
                                    $filename=$target_path;
                                    $handle = fopen("$filename", "r");
                                    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE)
                                    {
                                            $idgambaran=$data[0];
                                           
                                            $querycek="SELECT COUNT(idgambaran)as Jumlah
                                                       FROM idp_gambaran
                                                       WHERE idgambaran='$idgambaran'";
                                            $hasilcek=mysql_query($querycek);
                                               
                                            WHILE($row=mysql_fetch_array($hasilcek)){

                                                $row1=$row[Jumlah];
                                                if($row1 > 0){
                                                $idgambaran=$data[0];
                                                $empno=$data[1];
                                                $kekuatan=$data[11];
                                                $kelemahan=$data[12];
                                                $minat=$data[13];
                                                $formidp=$data[14];
                                                $tglterima=$data[15];
                                               

                                               $updatepa    =" UPDATE idp_gambaran SET
                                                                    
                                                                    kekuatan       =   '$kekuatan',
                                                                    kelemahan      =   '$kelemahan',
                                                                    minat          =   '$minat',
                                                                    formidp        =   '$formidp',
                                                                    tglterima      =   '$tglterima'
                                                                  
                                                                    WHERE idgambaran  =   '$idgambaran'";       
                                                                $masuk=  mysql_query($updatepa); 

                                                }               

                                            else {

                                    $import="INSERT into idp_gambaran values(
                                             '$data[0]','$data[1]','$data[11]','$data[12]','$data[13]','$data[14]','$data[15]'
                                            )";
                                    $masuk=  mysql_query($import);

                                            }}
                                    }
                                    fclose($handle);
//                                            echo "<script>window.alert(' Terima kasih yaa, Data Telah Terimport');
//                                                 window.location=('?module=view-idp')</script>";
                                             echo "$import <BR>$querycek";
                                    }


                                    else
                                    {

                                    print "";
                                    }

                                    ?>
                    </form>
                    
                </div>
        





</BODY>
</HTML>
