<?php
include "config/conn.php";

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";

}
else{
    
    
?>
<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap.min.js"></script>
<link rel="stylesheet" href="bootstrap-theme.min.css">
<link rel="stylesheet" href="bootstrap.min.css">


<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
     
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Overview Personal Strength & Weakness
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_company">Individual Development</a></li>
            <li class="active">Development Information</li>
          </ol>
        </section>
    
   <br>
          
  
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                <!-- <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview Company Category
                        </div>
                         /.panel-heading 
                        <div class="panel-body">
                            <div class="table-responsive">-->
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title"></h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=app_screening"><i class="fa fa-filter text-success"></i></a>&nbsp;&nbsp
                                      <a href="?module=app_widget&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Orgname</th>
                                            <th class="text-center">Position</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Kekuatan</th>                                            
                                            <th class="text-center">Kelemahan</th>
                                            <th class="text-center">Minat</th>
                                            <th class="text-center">Periode</th>
                                           

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";





$no=1;
	$sql  =" SELECT DISTINCT SUBSTR(a.idgambaran,1,11)AS empno, CONCAT(b.firstname,' ', b.lastname)AS nama,
                a.kekuatan, a.kelemahan, a.minat, a.tglterima, b.orgname, b.postitle,SUBSTR(a.idgambaran,12,4)AS periode

                FROM idp_gambaran a
                INNER JOIN exist_employee b ON SUBSTR(a.idgambaran,1,11)=b.empno";
        $hasil1=  mysql_query($sql);
	
            
            
        while($rsa=mysql_fetch_array($hasil1)){
            $tgllahir=  $rsa['tgllahir'];
            $tgl = date('Y-m-d', strtotime($tgllahir));
            $umur = round( floor(time() - strtotime($tgl))/(60*60*24*365));
//                 $tglsekarang=  date('Y-m-d');
//                 $date1 = new DateTime(date('Y-m-d', strtotime($tgllahir)));
//                 $date2 = new DateTime(date('Y-m-d'));
//                 $interval = $date1->diff($date2);
//                 $usia=$interval->y ;
             
           // $usia=round(( $birth_date -  $tglsekarang)/360,0);            
                         
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[orgname]";  ?></td>
                                            <td><?php echo"$rsa[postitle]";  ?></td>
                                            
                                            <td align="center"><?php echo"$rsa[nama]";  ?></td>
                                           
                                            <td align="center"><?php echo"$rsa[kekuatan]";  ?></td>
                                            <td align="center"><?php echo"$rsa[kelemahan]";  ?></td>
                                            <td align="center"><?php echo"$rsa[minat]";  ?></td>
                                            <td align="center"><?php echo"$rsa[periode]";  ?></td>
                                            
                                            

                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">Orgname</th>
                                            <th class="text-center">Position</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Kekuatan</th>                                            
                                            <th class="text-center">Kelemahan</th>
                                            <th class="text-center">Minat</th>
                                            <th class="text-center">Periode</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
             <!-- DATA TABES SCRIPT -->
    <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>
<?php } ?>