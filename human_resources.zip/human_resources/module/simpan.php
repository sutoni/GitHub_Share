 <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<?php
include "config/conn.php";

if($_GET['act']=="input_user"){
$pw=md5($_POST['pass']);
mysql_query("INSERT INTO user(nama,pass,level,id) 
VALUES(
'$_POST[nama]',
'$pw',
'admin_guru','$_POST[sekolah]')");
echo "<script>window.alert('Data Tersimpan');
        window.location=('../media.php?module=user')</script>";

}

//Simpan Organization Level
if($_GET['act']=="input_orglevel"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO organization_level(orglevelname,orglevel,keterangan) 
        VALUES(
        '$_POST[txtorglevelname]',
            '$_POST[txtorglevel]',
         '$_POST[txtketerangan]')");
        echo "<script>window.alert('Data Tersimpan');
                window.location=('?module=orglevel&act=input')</script>";

}

//Update Organization Level
if($_GET['act']=="edit_orglevel"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        $updateorglevel =" UPDATE organization_level SET
                        orglevelname = '$_POST[txtorglevelname]',
                        orglevel = '$_POST[txtorglevel]',       
                        keterangan = '$_POST[txtketerangan]'";
        $masuk=  mysql_query($updateorglevel);
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_organization&act=view_organization/&id=$id')</script>";

}

//Hapus Organization Level
if($_GET['act']=="hapus_orglevel"){
mysql_query("delete from organization_level where orglevelname='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_organization')</script>";
}

//Simpan Organization Struktur
if($_GET['act']=="input_orgstruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        mysql_query("INSERT INTO organization_struktur(orgcode, org_name, parent_orgcode,levelorg, costcenter, validfrom, validto) 
        VALUES(
            '$_POST[txtorgcode]',
             '$_POST[txtorgname]',
             '$_POST[txtparentorgcode]',
             '$_POST[txtorglevel]',
             '$_POST[txtcostcenter]',
             '$_POST[txtvalidfrom]',
         '$_POST[txtvalidto]')");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=orgstruktur&act=view&id=$id')</script>";

}

//Update Organization Struktur
if($_GET['act']=="edit_orgstruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        $org_name = $_POST[txtorgname];
        $parent_orgcode = $_POST[txtparentorgcode];
        $txtorglevel=$_POST[txtorglevel];
        $costcenter = $_POST[txtcostcenter];    
        $validfrom = $_POST[txtvalidfrom];    
        $validto = $_POST[txtvalidto];
        
        $updateorgstruktur ="UPDATE organization_struktur SET
                        org_name = '$_POST[txtorgname]',
                        parent_orgcode = '$_POST[txtparentorgcode]',
                        orglevel = '$_POST[txtorglevel]',
                        costcenter = '$_POST[txtcostcenter]',    
                        validfrom = '$_POST[txtvalidfrom]',    
                        validto = '$_POST[txtvalidto]' WHERE orgcode='$id'";
        $masuk=  mysql_query($updateorgstruktur);
        
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
        window.location=('?module=view_organization&act=view_orgstruktur')</script>";

}

//Hapus Organization Struktur
if($_GET['act']=="hapus_orgstruktur"){
mysql_query("delete from organization_struktur where orgcode='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_organization&act=view_orgstruktur')</script>";
}

//Simpan Company Category

if($_GET['act']=="input_compcat"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        mysql_query("INSERT INTO company_category(Nm_comp_category, keterangan) 
        VALUES(
        '$_POST[txtcompcat]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_company&act=view_companycat&id=$id')</script>";

}


//Hapus Company Category
if($_GET['act']=="hapus_compcat"){
mysql_query("delete from company_category where Nm_comp_category='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_company&act=view_companycat')</script>";
}




//Update Company Category

if($_GET['act']=="edit_compcat"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        $updatecompcat =" UPDATE company_category SET
                        Nm_comp_category = '$_POST[txtcompcat]',
                        keterangan = '$_POST[txtketerangan]'";       
                        $masuk=  mysql_query($updatecompcat);
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_company&act=view_companycat')</script>";

}

//Simpan Company Office Group

if($_GET['act']=="input_compoffgroup"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffgroup];
        mysql_query("INSERT INTO company_office_group(Nm_comp_group, keterangan) 
        VALUES(
        '$_POST[txtcompoffgroup]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_company&act=view_companygroup&id=$id')</script>";

}

//Update Company Office Group

if($_GET['act']=="edit_compoffgroup"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffgroup];
        $updatecompoffgroup =" UPDATE company_office_group SET
                        Nm_comp_group = '$_POST[txtcompoffgroup]',
                        keterangan = '$_POST[txtketerangan]'";       
                        $masuk=  mysql_query($updatecompoffgroup);
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_company&act=view_companygroup')</script>";

}


//Hapus Company Office Group
if($_GET['act']=="hapus_compoffgroup"){
mysql_query("delete from company_office_group where Nm_comp_group='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_company&act=view_companygroup')</script>";
}


//Simpan Company Office Details

if($_GET['act']=="input_compoffdetail"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffgroup];
        mysql_query("INSERT INTO company_office_detail(Nm_comp_office,Id_comp_category,Id_comp_group,Address,Nomor_npwp,Nm_cabang_pajak,Fax,Tlp,Validfrom,validto) 
        VALUES(
                '$_POST[txtcompoffname]',
                '$_POST[txtcompoffcat]',
                '$_POST[txtcompoffgroup]',
                '$_POST[txtaddress]',
                '$_POST[txtnpwp]',
                '$_POST[txtkantorpajak]',
                '$_POST[txtfax]',
                '$_POST[txttelpon]',
                '$_POST[txtvalidfrom]',
                '$_POST[txtvalidto]'    
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_company&act=view_companyoffdetail&ilid=$id')</script>";

}

//Update Company Office Detil

if($_GET['act']=="edit_compoffdetail"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffname];
        $updatecompoffdetail =" UPDATE company_office_detail SET
                                Nm_comp_office      =   '$_POST[txtcompoffname]',
                                Id_comp_category    =   '$_POST[txtcompoffcat]',
                                Id_comp_group       =   '$_POST[txtcompoffgroup]',
                                Address             =   '$_POST[txtaddress]',
                                Nomor_npwp          =   '$_POST[txtnpwp]',
                                Nm_cabang_pajak     =   '$_POST[txtkantorpajak]',
                                Fax                 =   '$_POST[txtfax]',
                                Tlp                 =   '$_POST[txttelpon]',
                                Validfrom           =   '$_POST[txtvalidfrom]',
                                validto             =   '$_POST[txtvalidto]'";       
                            $masuk=  mysql_query($updatecompoffdetail);
                            echo "<br><br> $updatecompoffdetail";            
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_company&act=view_companyoffdetail')</script>";

}
//Hapus Company Office Detail
if($_GET['act']=="hapus_compoffdetail"){
mysql_query("delete from company_office_detail where Nm_comp_office='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_company&act=view_companyoffdetail')</script>";
}




//Simpan Vendor MCU

if($_GET['act']=="input_vendormcu"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO t_vendormcu(id_vendor,namavendor,cabang, alamat, kontakperson, telpon, hp, email, fax, npwp, norek, validfrom, validto) 
        VALUES('',
        '$_POST[txtcostitem]',            
         '$_POST[txtketerangan]')");
        echo " <script>window.alert('Terima kasih, Data telah Tersimpan');
                window.location=('?module=rec_costitem&act=input')</script>";

}

//Simpan Vendor MCU

if($_GET['act']=="input_vendorpsi"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO t_vendorbiropsi(id_vendor,namavendor,cabang, alamat, kontakperson, telpon, hp, email, fax, npwp, norek, validfrom, validto) 
        VALUES('',
        '$_POST[txtcostitem]',            
         '$_POST[txtketerangan]')");
        echo " <script>window.alert('Terima kasih, Data telah Tersimpan');
                window.location=('?module=psi_vendor&act=input')</script>";

}


//input job family
if($_GET['act']=="input_jobfam"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        mysql_query("INSERT INTO job_family(id_job, job_title, keterangan) 
        VALUES(
        '$_POST[txtjobid]','$_POST[txtjobtitle]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_jobfam&id=$id')</script>";

}

//edit job family
if($_GET['act']=="edit_jobfam"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtjobid];
        $txtjobtitle=$_POST[txtjobtitle];
        $txtketerangan=$_POST[txtketerangan];
        $updatejobfam =" UPDATE job_family SET
                                id_job              =   '$id',
                                job_title           =   '$txtjobtitle',
                                keterangan       =   '$txtketerangan'";       
                            $masuk=  mysql_query($updatejobfam);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_jobfam')</script>";
}
//hapus job family
if($_GET['act']=="hapus_jobfam"){
mysql_query("delete from job_family where id_job='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_jobfam')</script>";
}

//input Functional Area
if($_GET['act']=="input_funcarea"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtfidfuncarea];
        $txtfuncareaname=$_POST[txtfuncareaname];
        $txtketerangan=$_POST[txtketerangan];
        $sql="INSERT INTO functional_area(id_functarea, func_area, keterangan) 
        VALUES(
        '$id','$txtfuncareaname',
             '$txtketerangan'
            )";
        $hasil=mysql_query($sql);
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_funcarea&id=$id')</script>";
}
//edit Functional Area
if($_GET['act']=="edit_funcarea"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtfidfuncarea];
        $txtfuncareaname=$_POST[txtfuncareaname];
        $txtketerangan=$_POST[txtketerangan];
        $updatefuncarea =" UPDATE functional_area SET
                                id_functarea     =   '$id',
                                func_area              =   '$txtfuncareaname',
                                keterangan       =   '$txtketerangan'";       
                            $masuk=  mysql_query($updatefuncarea);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_funcarea')</script>";
}
//hapus Functional Area
if($_GET['act']=="hapus_funcarea"){
mysql_query("delete from functional_area where id_functarea='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_funcarea')</script>";
}

//input Industry Area
if($_GET['act']=="input_posind"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtindname];
        $txtindareaname=$_POST[txtindareaname];
        $txtketerangan=$_POST[txtketerangan];
        $sql="INSERT INTO industry_area(industry_name, industry_area_name, keterangan) 
        VALUES(
        '$id','$txtindareaname',
             '$txtketerangan'
            )";
        $hasil=mysql_query($sql);
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_indarea&id=$id')</script>";
}
//edit Industry Area
if($_GET['act']=="edit_posind"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtindname];
        $txtindareaname=$_POST[txtindareaname];
        $txtketerangan=$_POST[txtketerangan];
        $updateindarea =" UPDATE industry_area SET
                                industry_name       =   '$id',
                                industry_area_name  =   '$txtindareaname',
                                keterangan          =   '$txtketerangan'";       
                            $masuk=  mysql_query($updateindarea);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_indarea')</script>";
}
//hapus Industry Area
if($_GET['act']=="hapus_indarea"){
mysql_query("delete from industry_area where industry_name='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_indarea')</script>";
}




//input Position Struktur

if($_GET['act']=="input_postruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtposid];
        mysql_query("INSERT INTO position_struktur(id_position, position_title, position_summary,position_class,direct_superior,job_id,organization_code,validfrom,validto) 
        VALUES(
        '$_POST[txtposid]','$_POST[txtpostitle]','$_POST[txtpossummary]','$_POST[txtposclass]','$_POST[txtposiddir]',
         '$_POST[txtjobid]','$_POST[txtorgcode]','$_POST[txtvalidfrom]','$_POST[txtvalidto]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_posstruktur&id=$id')</script>";

}
//edit Position Struktur
if($_GET['act']=="edit_postruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtposid];
        $updatepostruktur =" UPDATE position_struktur SET
                                id_position              =   '$_POST[txtposid]',
                                position_title           =   '$_POST[txtpostitle]',
                                position_summary              =   '$_POST[txtpossummary]',
                                position_class              =   '$_POST[txtposclass]',
                                direct_superior           =   '$_POST[txtposiddir]',
                                job_id              =   '$_POST[txtjobid]',
                                organization_code           =   '$_POST[txtorgcode]',
                                validfrom           =   '$_POST[txtvalidfrom]',
                                validto       =   '$_POST[txtvalidto]'";       
                            $masuk=  mysql_query($updatepostruktur);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_posstruktur')</script>";

}
//hapus Position Struktur
if($_GET['act']=="hapus_postruktur"){
mysql_query("delete from position_struktur where id_position='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_posstruktur')</script>";
}

//input Position Class
if($_GET['act']=="input_posclass"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtposclass];
        mysql_query("INSERT INTO position_class(posclass, keterangan) 
        VALUES(
        '$_POST[txtposclass]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_posclass&id=$id')</script>";

}

//edit Position Class
if($_GET['act']=="edit_posclass"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtposclass];
        $id2=$_POST[txtketerangan];
        
        $updateposclass =" UPDATE position_class SET
                                posclass         =   '$_POST[txtposclass]',
                                keterangan       =   '$id2'";       
                            $masuk=  mysql_query($updateposclass);
                            
        
       echo "$updateposclass <script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_position&act=view_posclass')</script>";
}
//hapus Position Class
if($_GET['act']=="hapus_posclass"){
mysql_query("delete from position_class where posclass='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_posclass')</script>";
}



//input Recruitment Base Event
if($_GET['act']=="input_recevent"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txteventid];
        mysql_query("INSERT INTO recruitment_event(idevent,namaevent,keterangan, validfrom, validto) 
        VALUES(
        '$_POST[txteventid]','$_POST[txtnamaevent]',
             '$_POST[txtketerangan]','$_POST[txtvalidfrom]','$_POST[txtvalidto]'
            )");
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_recbase&act=view_recevent&id=$id')</script>";
}
//edit Recruitment Base Event
if($_GET['act']=="edit_recevent"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txteventid];
        $txtnamaevent=$_POST[txtnamaevent];
        $txtketerangan=$_POST[txtketerangan];
        $txtvalidfrom=$_POST[txtvalidfrom];
        $txtvalidto=$_POST[txtvalidto];
        
        $updaterecevent =" UPDATE recruitment_event SET
                                namaevent         =   '$txtnamaevent',
                                keterangan         =   '$txtketerangan',
                                validfrom         =   '$txtvalidfrom',
                                validto         =   '$txtvalidto'    
                                WHERE idevent  =   '$id'";       
                            $masuk=  mysql_query($updaterecevent);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_recevent')</script>";
}
//hapus Recruitment Base Event
if($_GET['act']=="hapus_recevent"){
mysql_query("delete from recruitment_event where idevent='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_recevent')</script>";
}

//input Recruitment Base Method
if($_GET['act']=="input_recmethod"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txteventid];
        mysql_query("INSERT INTO recruitment_method(idrecmethod,recmethodname,recmethodgroup, keterangan) 
        VALUES(
        '$_POST[txtidrecmethod]','$_POST[txtrecmethodname]',
             '$_POST[txtrecmethodgroup]','$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_recbase&act=view_recmethod&id=$id')</script>";
}
//edit Recruitment Base Method
if($_GET['act']=="edit_recmethod"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtidrecmethod];
        $txtnamaevent=$_POST[txtrecmethodname];
        $txtrecmethodgroup=$_POST[txtrecmethodgroup];
        $txtketerangan=$_POST[txtketerangan];
        $updaterecmethod =" UPDATE recruitment_method SET
                                recmethodname    =   '$txtnamaevent',
                                recmethodgroup   =   '$txtrecmethodgroup',
                                keterangan   =   '$txtketerangan' 
                                WHERE idrecmethod  =   '$id'";       
                            $masuk=  mysql_query($updaterecmethod);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_recmethod')</script>";
}
//hapus Recruitment Base Method
if($_GET['act']=="hapus_recmethod"){
mysql_query("delete from recruitment_method where idrecmethod='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_recmethod')</script>";
}
//input Recruitment Base Periode
if($_GET['act']=="input_recperiode"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtrecperiode];
        mysql_query("INSERT INTO recruitment_periode(recperiode,periode,validfrom, validto) 
        VALUES(
        '$_POST[txtrecperiode]','$_POST[txtperiode]',
             '$_POST[txtvalidfrom]','$_POST[txtvalidto]'
            )");
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_recbase&act=view_recperiode&id=$id')</script>";
}
//edit Recruitment Base Periode
if($_GET['act']=="edit_recperiode"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtrecperiode];
        $txtperiode=$_POST[txtperiode];
        $txtvalidfrom=$_POST[txtvalidfrom];
        $txtvalidto=$_POST[txtvalidto];
        $updaterecperiode =" UPDATE recruitment_periode SET
                                periode    =   '$txtperiode',
                                validfrom   =   '$txtvalidfrom',
                                validto   =   '$txtvalidto' 
                                WHERE recperiode  =   '$id'";       
                            $masuk=  mysql_query($updaterecperiode);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_recperiode')</script>";
}
//hapus Recruitment Base Periode
if($_GET['act']=="hapus_recperiode"){
mysql_query("delete from recruitment_periode where recperiode='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_recperiode')</script>";
}

//Simpan Recruitment Base Cost Item
if($_GET['act']=="input_costitem"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO t_rec_costitem(idcostitem,costitem,keterangan) 
        VALUES(
        '$_POST[txtidcostitem]','$_POST[txtcostitem]','$_POST[txtketerangan]'
         )");
        echo " <script>window.alert('Terima kasih, Data telah Tersimpan');
                window.location=('?module=view_recbase&act=view_reccost')</script>";
}
//edit Recruitment Base costitem
if($_GET['act']=="edit_costitem"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtidcostitem];
        $txtcostitem=$_POST[txtcostitem];
        $txtketerangan=$_POST[txtketerangan];
        
        $updatereccostitem =" UPDATE t_rec_costitem SET
                                costitem   =   '$txtcostitem',
                                keterangan   =   '$txtketerangan' 
                                WHERE id  =   '$id'";       
                            $masuk=  mysql_query($updatereccostitem);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_reccost')</script>";
}
//hapus Recruitment Base costitem
if($_GET['act']=="hapus_costitem"){
mysql_query("delete from t_rec_costitem where id='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_reccost')</script>";
}

//Simpan Applicant Personal
if($_GET['act']=="input_apppersonal"){
        $pt='DXM-CV/';
        $year=DATE('Y');
        
        $txtfirstname=$_POST[txtfirstname];
        $txtlastname=$_POST[txtlastname];
        $txttglapply=$_POST[txttglapply];
        $tgllahir=$_POST[txttgllahir];
        $idBLNapply=SUBSTR($txttglapply,5,2);
        
        $hari=  substr($tgllahir, 8,2);
        $bulan=  substr($tgllahir, 5,2);
        $tahun=  substr($tgllahir, 0,4);
        $tgllahir1=$tahun.$bulan.$hari;
        $cekgabungnama=$txtfirstname.' '.$txtlastname;
        $gabung1=$year."/".$idBLNapply."/";
        $applicantid1=$pt.$gabung1;
        
        
        $ceknama="SELECT CONCAT(firstname,' ',lastname)AS nama, tgllahir, gender FROM applicant_personal WHERE CONCAT(firstname,' ',lastname)='$cekgabungnama' AND tgllahir='$tgllahir'";
        $hasil=mysql_query($ceknama);
        
        if ($row=mysql_fetch_row($hasil))
	{
               $nomor++;
               $nama=$row[nama];
               $gender=$row[gender];
               $tgllahirnya=$row[tgllahir];
               
                ?>
               <script> alert('Maaf Nama : <?php echo"$nama - $tgllahirnya"; ?>   sudah terdaftar'); location.replace("?module=app_overview&act=view_appinfo"); </script>
             <?php
        }
        else {
                $caricount="SELECT COUNT(applicantid)AS hitung FROM applicant_personal WHERE MONTH(tglapply)='$idBLNapply' AND YEAR(tglapply)='$year' ";
                $hasilcari=  mysql_query($caricount);
                $scount=  mysql_fetch_array($hasilcari);
                $jmlcount=$scount['hitung'];
                
                if($jmlcount < 9){
                    $urutanjml=$jmlcount+1;
                    $nonol='000';
                    $noapplicant=$applicantid1.$nonol.$urutanjml;
                    
                     $masuk1= "INSERT INTO applicant_personal(applicantid,firstname,lastname,
                                gender,tempatlahir,tgllahir,
                               telpon,hp,email,alamat,statusnikah,status,statuspull,
                                tglinterviewhr, statusinterviewhr,tglinterviewuser1, statusinterviewuser1, tglinterviewuser2, statusinterviewuser2, 
                                tglpsikotest, statuspsikotest, tglapply, recmethod, recevent) 
                                VALUES('$noapplicant',
                                '$_POST[txtfirstname]','$_POST[txtlastname]','$_POST[txtgender]',
                                '$_POST[txttmplahir]','$_POST[txttgllahir]','$_POST[txttelpon]',
                                '$_POST[txthp]','$_POST[txtemail]','$_POST[txtalamat]'
                                ,'$_POST[txtstatusnikah]','polled','belum','0000-00-00',"
                             . "'belum','0000-00-00','belum','0000-00-00','belum','0000-00-00','belum','$_POST[txttglapply]',
                                 '$_POST[txtrecmethod]','$_POST[txteventmethod]'   
                                     )";
                    $hasilmasuk1=mysql_query($masuk1);
                    $leveledu1=$_POST[idlevel1];
                    $edu1=1;
                    $appedu1=$noapplicant.$edu1.$leveledu;
                    $idlevel2=$_POST[idlevel2];
                    $idlevel1=$_POST[idlevel1];
                    IF($idlevel2=''){
                        $masukedu1="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu1','$noapplicant','$_POST[idlevel1]','$_POST[jurusan1]','$_POST[txtinstitusi1]',
                            '$_POST[txtipk1]')";                    
                    $hasilmasukedu1=mysql_query($masukedu1);
                    }
                    else if($idlevel2!='' AND $idlevel1!=''){
                        $masukedu1="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu1','$noapplicant','$_POST[idlevel1]','$_POST[jurusan1]','$_POST[txtinstitusi1]',
                            '$_POST[txtipk1]')";                    
                    $hasilmasukedu1=mysql_query($masukedu1);
                    $edu2=2;
                    $leveledu2=$_POST[idlevel2];
                    $appedu2=$noapplicant.$edu2.$leveledu2;
                    $masukedu2="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu2','$noapplicant','$_POST[idlevel2]','$_POST[jurusan2]','$_POST[txtinstitusi2]',
                            '$_POST[txtipk2]')";                    
                    $hasilmasukedu2=mysql_query($masukedu2);
                    }
                    else{
                        
                    }
                    
                    
                    $exp1=exp1;
                    $appexp1=$noapplicant.$exp1;
                    $masukexp1="INSERT INTO applicant_experience(experienceid,applicantid,industryarea,functionalarea,position,duration)
                            VALUES('$appexp1','$noapplicant','$_POST[txtindarea1]','$_POST[txtfuncarea1]','$_POST[txtposition1]','$_POST[daterange1]')";
                    $hasilmasukexp1=mysql_query($masukexp1);
                            
                    
                    
                     echo "<script>window.alert('Terimakasih data telah tersimpan');
                        window.location=('?module=app_overview&act=view_appinfo')</script>";
                }
                elseif($jmlcount < 99){
                    $urutanjml=$jmlcount+1;
                    $nonol='00';
                    $noapplicant=$applicantid1.$nonol.$urutanjml;
                    
                   $masuk1= "INSERT INTO applicant_personal(applicantid,firstname,lastname,
                                gender,tempatlahir,tgllahir,
                               telpon,hp,email,alamat,statusnikah,status,statuspull,
                                tglinterviewhr, statusinterviewhr,tglinterviewuser1, statusinterviewuser1, tglinterviewuser2, statusinterviewuser2, 
                                tglpsikotest, statuspsikotest, tglapply, recmethod, recevent) 
                                VALUES('$noapplicant',
                                '$_POST[txtfirstname]','$_POST[txtlastname]','$_POST[txtgender]',
                                '$_POST[txttmplahir]','$_POST[txttgllahir]','$_POST[txttelpon]',
                                '$_POST[txthp]','$_POST[txtemail]','$_POST[txtalamat]'
                                ,'$_POST[txtstatusnikah]','polled','belum','0000-00-00',"
                             . "'belum','0000-00-00','belum','0000-00-00','belum','0000-00-00','belum','$_POST[txttglapply]',
                                 '$_POST[txtrecmethod]','$_POST[txteventmethod]'   
                                     )";
                    $hasilmasuk1=mysql_query($masuk1);
                    $leveledu1=$_POST[idlevel1];
                    $edu1=1;
                    $appedu1=$noapplicant.$edu1.$leveledu;
                    $idlevel2=$_POST['idlevel2'];
                    $idlevel1=$_POST['idlevel1'];
                    echo "level 1 =$idlevel1 <br>level 2 =$idlevel2 ";
                    IF($idlevel1!='' && $idlevel2=''){
                        $masukedu1="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu1','$noapplicant','$_POST[idlevel1]','$_POST[jurusan1]','$_POST[txtinstitusi1]',
                            '$_POST[txtipk1]')";                    
                    $hasilmasukedu1=mysql_query($masukedu1);
                      
                    }
                    else if($idlevel2!='' && $idlevel1!=''){
                        $masukedu1="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu1','$noapplicant','$_POST[idlevel1]','$_POST[jurusan1]','$_POST[txtinstitusi1]',
                            '$_POST[txtipk1]')";                    
                    $hasilmasukedu1=mysql_query($masukedu1);
                    $edu2=2;
                    $leveledu2=$_POST[idlevel2];
                    $appedu2=$noapplicant.$edu2.$leveledu2;
                    $masukedu2="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu2','$noapplicant','$_POST[idlevel2]','$_POST[jurusan2]','$_POST[txtinstitusi2]',
                            '$_POST[txtipk2]')";                    
                    $hasilmasukedu2=mysql_query($masukedu2);
                    
                    $exp1=exp1;
                    $appexp1=$noapplicant.$exp1;
                    $masukexp1="INSERT INTO applicant_experience(experienceid,applicantid,industryarea,functionalarea,position,duration)
                            VALUES('$appexp1','$noapplicant','$_POST[txtindarea1]','$_POST[txtfuncarea1]','$_POST[txtposition1]','$_POST[daterange1]')";
                    $hasilmasukexp1=mysql_query($masukexp1);
                            
                    }  else {
                        echo "- $idlevel2 - $idlevel1 o $masukedu1";
                    }
                    
                     
                    
                    
                }
                elseif($jmlcount < 999) {
                    $urutanjml=$jmlcount+1;
                    $nonol='0';
                    $noapplicant=$applicantid1.$nonol.$urutanjml;
                    
                    $masuk1= "INSERT INTO applicant_personal(applicantid,firstname,lastname,
                                gender,tempatlahir,tgllahir,
                               telpon,hp,email,alamat,statusnikah,status,statuspull,
                                tglinterviewhr, statusinterviewhr,tglinterviewuser1, statusinterviewuser1, tglinterviewuser2, statusinterviewuser2, 
                                tglpsikotest, statuspsikotest, tglapply, recmethod, recevent) 
                                VALUES('$noapplicant',
                                '$_POST[txtfirstname]','$_POST[txtlastname]','$_POST[txtgender]',
                                '$_POST[txttmplahir]','$_POST[txttgllahir]','$_POST[txttelpon]',
                                '$_POST[txthp]','$_POST[txtemail]','$_POST[txtalamat]'
                                ,'$_POST[txtstatusnikah]','polled','belum','0000-00-00',"
                             . "'belum','0000-00-00','belum','0000-00-00','belum','0000-00-00','belum','$_POST[txttglapply]',
                                 '$_POST[txtrecmethod]','$_POST[txteventmethod]'   
                                     )";
                    $hasilmasuk1=mysql_query($masuk1);
                    $leveledu1=$_POST[idlevel1];
                    $edu1=1;
                    $appedu1=$noapplicant.$edu1.$leveledu;
                    $idlevel2=$_POST[idlevel2];
                    $idlevel1=$_POST[idlevel1];
                    IF($idlevel2=''){
                        $masukedu1="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu1','$noapplicant','$_POST[idlevel1]','$_POST[jurusan1]','$_POST[txtinstitusi1]',
                            '$_POST[txtipk1]')";                    
                    $hasilmasukedu1=mysql_query($masukedu1);
                    }
                    else if($idlevel2!='' AND $idlevel1!=''){
                        $masukedu1="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu1','$noapplicant','$_POST[idlevel1]','$_POST[jurusan1]','$_POST[txtinstitusi1]',
                            '$_POST[txtipk1]')";                    
                    $hasilmasukedu1=mysql_query($masukedu1);
                    $edu2=2;
                    $leveledu2=$_POST[idlevel2];
                    $appedu2=$noapplicant.$edu2.$leveledu2;
                    $masukedu2="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu2','$noapplicant','$_POST[idlevel2]','$_POST[jurusan2]','$_POST[txtinstitusi2]',
                            '$_POST[txtipk2]')";                    
                    $hasilmasukedu2=mysql_query($masukedu2);
                    
                    $exp1=exp1;
                    $appexp1=$noapplicant.$exp1;
                    $masukexp1="INSERT INTO applicant_experience(experienceid,applicantid,industryarea,functionalarea,position,duration)
                            VALUES('$appexp1','$noapplicant','$_POST[txtindarea1]','$_POST[txtfuncarea1]','$_POST[txtposition1]','$_POST[daterange1]')";
                    $hasilmasukexp1=mysql_query($masukexp1);
                    }        
                       
                     echo "<script>window.alert('Terimakasih data telah tersimpan');
                        window.location=('?module=app_overview&act=view_appinfo')</script>";   
                    
                }
                else{
                    $urutanjml=$jmlcount+1;
                    $noapplicant=$applicantid1.$urutanjml;
                    
                    $masuk1= "INSERT INTO applicant_personal(applicantid,firstname,lastname,
                                gender,tempatlahir,tgllahir,
                               telpon,hp,email,alamat,statusnikah,status,statuspull,
                                tglinterviewhr, statusinterviewhr,tglinterviewuser1, statusinterviewuser1, tglinterviewuser2, statusinterviewuser2, 
                                tglpsikotest, statuspsikotest, tglapply, recmethod, recevent) 
                                VALUES('$noapplicant',
                                '$_POST[txtfirstname]','$_POST[txtlastname]','$_POST[txtgender]',
                                '$_POST[txttmplahir]','$_POST[txttgllahir]','$_POST[txttelpon]',
                                '$_POST[txthp]','$_POST[txtemail]','$_POST[txtalamat]'
                                ,'$_POST[txtstatusnikah]','polled','belum','0000-00-00',"
                             . "'belum','0000-00-00','belum','0000-00-00','belum','0000-00-00','belum','$_POST[txttglapply]',
                                 '$_POST[txtrecmethod]','$_POST[txteventmethod]'   
                                     )";
                    $hasilmasuk1=mysql_query($masuk1);
                    $leveledu1=$_POST[idlevel1];
                    $edu1=1;
                    $appedu1=$noapplicant.$edu1.$leveledu1;
                    $masukedu1="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu1','$noapplicant','$_POST[idlevel1]','$_POST[jurusan1]','$_POST[txtinstitusi1]',
                            '$_POST[txtipk1]')";                    
                    $hasilmasukedu1=mysql_query($masukedu1);
                    $edu2=2;
                    $leveledu2=$_POST[idlevel2];
                    $appedu2=$noapplicant.$edu2.$leveledu2;
                    $masukedu2="INSERT INTO applicant_education(appeduid,applicantid,leveledukasi,jurusan,institusi,ipk)
                             VALUES('$appedu2','$noapplicant','$_POST[idlevel2]','$_POST[jurusan2]','$_POST[txtinstitusi2]',
                            '$_POST[txtipk2]')";                    
                    $hasilmasukedu2=mysql_query($masukedu2);
                    
                    $exp1=exp1;
                    $appexp1=$noapplicant.$exp1;
                    $masukexp1="INSERT INTO applicant_experience(experienceid,applicantid,industryarea,functionalarea,position,duration)
                            VALUES('$appexp1','$noapplicant','$_POST[txtindarea1]','$_POST[txtfuncarea1]','$_POST[txtposition1]','$_POST[daterange1]')";
                    $hasilmasukexp1=mysql_query($masukexp1);
                            
                    $exp2=exp2;
                    $appexp2=$noapplicant.$exp2;
                    $masukexp2="INSERT INTO applicant_experience(experienceid,applicantid,industryarea,functionalarea,position,duration)
                            VALUES('$appexp2','$noapplicant','$_POST[txtindarea2]','$_POST[txtfuncarea2]','$_POST[txtposition2]','$_POST[daterange2]')";
                    $hasilmasukexp2=mysql_query($masukexp2);     
                      echo "<script>window.alert('Terimakasih data telah tersimpan');
                        window.location=('?module=app_overview&act=view_appinfo')</script>";
                    
                }
        }
        
           
              
        
        
        
        
       
}
//Recruitment Activity
if($_GET['act']=="input_recactivity"){
        $ad     = $_POST["item"];
        $jumlah = count($_POST["item"]);
        
        $pw     = md5($_POST['pass']);
        $status = $_POST['btnsubmit'];
        
               $txteventid=$_POST['txteventid'];
               $txttempatevent=$_POST['txttempatevent'];
               $txtkontakperson=$_POST['txtkontakperson'];
               $txtkontakno=$_POST['txtkontakno'];
               $txttglawal=$_POST['txttglawal'];
               $txttglakhir=$_POST['txttglakhir'];
               $txtpic=$_POST['txtpic'];
               $txtketerangan=$_POST['txtketerangan'];
               
               
               $tahun=substr($txttglawal, 0, 4);
               $bulan=substr($txttglawal, 5, 2);
               $hari=substr($txttglawal, 8, 2);
               
               $idrec_activity=$txteventid.$txtpic.$tahun.$bulan.$hari;
               
               $sql1  ="Select * from recruitment_activitydetails where idrec_activity = '$idrec_activity'";
               $hasil = mysql_query($sql1);
               
               
               
                if ($row=mysql_fetch_row($hasil))
                {
                      
                        echo " <script>window.alert('Maaf Nama Sudah Terdaftar');
                         window.location=('?module=view_transrec&act=view_recactivity')</script>";
                }
                else if($idrec_activity !='') {
                    
                          $masukid="INSERT INTO recruitment_activity(idrec_activity, eventid, tempat, kontakperson, kontakno, startdate, enddate, pic, keterangan, istatus)
                                   VALUES('$idrec_activity','$txteventid','$txttempatevent','$txtkontakperson','$txtkontakno','$txttglawal','$txttglakhir','$txtpic','$txtketerangan', 'plan')";
                           $hasilmasukid=mysql_query($masukid);
        
                           

                            for($i=0; $i < $jumlah; $i++) 
                            {
                               $id=$_POST["item"][$i];


                               $txtidcost1=$_POST['txtidcost'];
                               $txtidcost=$txtidcost1[$id-1];

                               $cosid=$txtidcost.$idrec_activity;

                               $txtidbudget1=$_POST['txtidbudget'];
                               $txtidbudget=$txtidbudget1[$id-1];
                               $txtbudget1=$_POST['txtbudget'];
                               $txtbudget=$txtbudget1[$id-1];




                                           $masuk2 = "INSERT INTO recruitment_activitydetails(costid, idrec_activity,idcostitem, budget)
                                                   VALUES('$cosid','$idrec_activity','$txtidcost','$txtbudget')";
                                            $hasilmasuk2=mysql_query($masuk2);       

                                          
                                            ?>
                                                <script> location.replace("?module=view_transrec&act=view_recactivity"); </script> 
                                           <?php
                                }
                        }   
                    else {
                        echo "data empty";
                    }    
    
}

//Edit Recruitment Activity
  if($_GET['act']=="edit_recactivity"){
               $ad     = $_POST["item"];
               $jumlah = count($_POST["item"]);
               $id=$_GET['id'];
               $pw     = md5($_POST['pass']);
               $status = $_POST['btnsubmit'];
               
               $txttempatevent=$_POST['txttempatevent'];
               $txtkontakperson=$_POST['txtkontakperson'];
               $txtkontakno=$_POST['txtkontakno'];
               $txttglawal=$_POST['txttglawal'];
               $txttglakhir=$_POST['txttglakhir'];
               $txtpic=$_POST['txtpic'];
               $txtketerangan=$_POST['txtketerangan'];
               $txtbudget=$_POST['txtbudget'];
        
               if($status=='update')
               {
                   $txtbudget=$_POST['txtbudget'];
                   $txteventid=$_POST['txteventid'];
                   $idrec_activity=$txteventid.$txtpic.$tahun.$bulan.$hari;
               
                    
                    
                    $updaterec_activity="UPDATE recruitment_activity SET
                                tempat   =   '$txttempatevent',
                                kontakperson   =   '$txtkontakperson',
                                kontakno = '$txtkontakno', 
                                startdate ='$txttglawal',
                                enddate ='$txttglakhir', 
                                pic = '$txtpic',        
                                keterangan   =   '$txtketerangan' 
                                WHERE idrec_activity  ='$id'";       
                            $masuk=  mysql_query($updaterec_activity);
                    
                        
                     $sqlactivity = "Select * from recruitment_activitydetails where idrec_activity = '$id'";
                     $hasil = mysql_query($sqlactivity);
                            echo "$jumlah";
                           for($i=0; $i < $jumlah; $i++) 
                            {
                               $id=$_POST["item"][$i];


                               $txtidcost1=$_POST['txtidcost'];
                               $txtidcost=$txtidcost1[$id-1];

                               $cosid=$txtidcost.$idrec_activity;

                               $txtidbudget1=$_POST['txtidbudget'];
                               $txtidbudget=$txtidbudget1[$id-1];
                               $txtbudget1=$_POST['txtbudget'];
                               $txtbudget4=$txtbudget1[$id-1];
                               
                               $xd=$_GET['id'];
                               $costid=$txtidcost.$xd;
                                
                                
                                $updaterec_activitydetails="UPDATE recruitment_activitydetails SET
                                budget   =   '$txtbudget4'
                                WHERE costid  ='$costid'";   
                               
                                $masuk=  mysql_query($updaterec_activitydetails);


                                          
                                            ?>
                                                <script> location.replace("?module=view_transrec&act=view_recactivity"); </script> 
                                           <?php
                                             
                                } 
                   
               }
               elseif ($status=='cancel') {
                        $updaterec_activitycancel="UPDATE recruitment_activity SET
                                keterangan='$txtketerangan',
                                istatus='cancel'    
                                WHERE idrec_activity  ='$id'";       
                            $masuk=  mysql_query($updaterec_activitycancel);
                            echo "$updaterec_activitycancel <br>";
                        for($i=0; $i < $jumlah; $i++) 
                            {
                               $id=$_POST["item"][$i];


                               $txtidcost1=$_POST['txtidcost'];
                               $txtidcost=$txtidcost1[$id-1];

                               $cosid=$txtidcost.$idrec_activity;

                               $txtidbudget1=$_POST['txtidbudget'];
                               $txtidbudget=$txtidbudget1[$id-1];
                               $txtbudget1=$_POST['txtbudget'];
                               $txtbudget4=$txtbudget1[$id-1];
                               
                               $xd=$_GET['id'];
                               $costid=$txtidcost.$xd;
                                
                                
                                $updaterec_activitydetails="UPDATE recruitment_activitydetails SET
                                budget   =   '0'
                                WHERE costid  ='$costid'";   
                                $masuk=  mysql_query($updaterec_activitydetails);

                                echo "$updaterec_activitydetails <br>";
                                          
                                            ?>
                                               
                                           <?php
                                }    
                }
                else {
                    echo "$status";
                }
               
                   
    
}  





//
//Recruitment Budget

if($_GET['act']=="input_costbudget"){
        $ad     = $_POST["item"];
        $jumlah = count($_POST["item"]);
        
        $pw     = md5($_POST['pass']);
        $status = $_POST['btnsubmit'];

        for($i=0; $i < $jumlah; $i++) 
            {
               $id=$_POST["item"][$i];
               
               $txtidbudget1=$_POST['txtidbudget'];
               $txtidbudget=$txtidbudget1[$id-1];
               $idcostitem = substr($txtidbudget,4,2);
               $periode = substr($txtidbudget,0,4);
               
               
               $txtbudget1 =$_POST['txtbudget']; 
               $txtbudget = $txtbudget1[$id-1];
               $txtadjustbudget1 =$_POST['txtadjustbudget'];
               $txtadjustbudget=$txtadjustbudget1[$id-1];
               $txttotal =$txtbudget+$txtadjustbudget;
               
               $txtremark1 =$_POST['txtremark'];
               $txtremark = $txtremark1[$id-1];
               
               $sql1  ="Select * from recruitment_budget where idbudget = '$txtidbudget'";
               $hasil = mysql_query($sql1);
               
               
                if ($row=mysql_fetch_row($hasil))
                {

                            echo " <script>window.alert('Maaf Nama Sudah Terdaftar');
                           window.location=('?module=app_widget')</script>";
                }
                else {
                    
                    $masuk2="INSERT INTO recruitment_budget(idbudget, idcostitem, budget, adjust, totalbudget,periode, keterangan)
                            VALUES('$txtidbudget','$idcostitem','$txtbudget','$txtadjustbudget','$txttotal','$periode',
                            '$txtremark')";
                    $hasilmasuk2=mysql_query($masuk2);
                    
                  
                     ?>
                          <script> location.replace("?module=view_transrec&act=view_recbudget"); </script> 
                    <?php
                
                }
               
               
            }                
        
}

//edit_costbudget
if($_GET['act']=="edit_costbudget"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtidbudget];
        $txtcostitem=$_POST[txtcostitem];
        $txtbudget=$_POST[txtbudget];
        $txtadjust=$_POST[txtadjust];
        $totalbgt = $txtbudget + $txtadjust;
        $txtketerangan=$_POST[txtketerangan];
        
        $updatecostbudget =" UPDATE recruitment_budget SET
                                budget   =   '$txtbudget',
                                adjust   =   '$txtadjust',
                                totalbudget = '$totalbgt',    
                                keterangan   =   '$txtketerangan' 
                                WHERE idbudget  =   '$id'";       
                            $masuk=  mysql_query($updatecostbudget);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_transrec&act=view_recbudget')</script>";
}

//edit Recruitment Base costitem
if($_GET['act']=="edit_costitem"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtidcostitem];
        $txtcostitem=$_POST[txtcostitem];
        
        $txtketerangan=$_POST[txtketerangan];
        
        $updatereccostitem =" UPDATE t_rec_costitem SET
                                costitem   =   '$txtcostitem',
                                keterangan   =   '$txtketerangan' 
                                WHERE id  =   '$id'";       
                            $masuk=  mysql_query($updatereccostitem);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_reccost')</script>";
}
//hapus Recruitment Base costitem
if($_GET['act']=="hapus_costitem"){
mysql_query("delete from t_rec_costitem where id='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_reccost')</script>";
}
//update status tolak screening
//edit Recruitment Base costitem
if($_GET['act']=="update_appscreening"){
        $ad=$_POST["item"];
        
        $jumlah = count($_POST["item"]);
        
        $pw=md5($_POST['pass']);
        $status=$_POST['btnsubmit'];
        
        
        if($status =='tolakscreening'){
            
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                     
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step1', statuspull='tolak' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);?>
                            <script> location.replace("?module=app_screening&act=view_screening"); </script>  
                                <!-- //header("Location:http://localhost/recruitment_center/media.php?module=app_screening&act=view_screening");                 -->
<?php                    }
                else {
                    echo "gagal dunk 1";
                }    
            }
            
        }
        
        else if($status =='terimascreening'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step1', statuspull='ok' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screening"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk 2";
                }    
            }
        }
        
        
        
            //echo "cek : $id -  $updatescreening";                  
            // echo "<script>window.alert(' Telah Terupdate');
           //  window.location=('?module=app_screening')</script>";
}




//update pull
if($_GET['act']=="update_appspull"){
        $ad=$_POST["item"];
        
        $jumlah = count($_POST["item"]);
        
        $pw=md5($_POST['pass']);
        $status=$_POST['btnsubmit'];
        
        
        if($status =='tolak'){
            
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                     
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='tolakstep2' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                                <!-- //header("Location:http://localhost/recruitment_center/media.php?module=app_screening&act=view_screening");                 -->
<?php                    }
                else {
                    echo "gagal dunk";
                }    
            }
            
        }
        
        else if($status =='terima'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step3' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        
        else if($status =='tolakuser'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='tolakstep3' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        else if($status =='terimauser'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step4' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        
        
        else if($status =='tolakpsi'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step2', statuspsikotest='tolak' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        else if($status =='terimapsi'){ echo "keluar modal";
           ?>
             <!-- Modal Terima psi -->
                  <div id="myPsiOk" class="modal fade " role="dialog">
                  <div class="modal-dialog modal-lg">

                    
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Details Psikotest</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewposition">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'>$rsd[tahun]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   <br><br>
                                                &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                                            <label>Position Level :</label>
                                            <select id="txtposlevel" name="txtposlevel" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT poslevel FROM `position_mapping` GROUP BY poslevel";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[poslevel]'>$rsd[poslevel]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>  
                                            
                                        </form>
                                      
                            
                           
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  
                  </div>
                </div>
                    
                    <!-- End Modal Position -->  
            
<!--            $empno2=$_POST['item'];
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];
               
               
                $arrEmp=$_POST['txtempno'];
               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='Inproses',statuspull='step2', statuspsikotest='ok' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                                
                                    $sql2 ="Select applicantid,COUNT(applicantid)as juml from applicant_psikotest where applicantid = '$id'";
                                    $hasi2 = mysql_query($sql2);    
                                   
                                    if ($rowz=mysql_fetch_row($hasi2))
                                    {       
                                          if(in_array($arrEmp[$i],$empno2)){ //saya tambahin kondisi ini
                                                $keys=array_search ($arrEmp[$i], $empno2);
                                                $applicantid=$arrEmp[$i]; 
                                                $tgl=$_POST['txttgl'][$keys];
                                                
                                                
                                        
                                    
                                       
                                        $jumlah=$rowz['juml']+1;
                                        $psikotestid=$applicantid.$jumlah;
                                        $masukz="INSERT INTO applicant_psikotest(psikotestid, applicantid, tglpsikotest, nilaiwpt, nilaiiq, nilaipauli, nilaikreplin, statuspsikotest)"
                                                . "  VALUES('$psikotestid','$applicantid','$tgl','','','','','ok')";
                                        $hasilmasuk=mysql_query($masukz);
                                        
                                        
                                          }
                                          else {
                                              echo "$arrEmp[$i]";
                                          }
                                    } 
                                     echo "$masukz";       
                    }        ?>-->
                             
                            <!--<script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  -->
                           
                     <?php
//                else {
//                    echo "gagal dunk";
//                }    
            }
        }
        
        
           
//}
//update interview hr
if($_GET['act']=="update_appsinthr"){
        $ad=$_POST["item"];
        
        $jumlah = count($_POST["item"]);
        
        $pw=md5($_POST['pass']);
        $status=$_POST['btnsubmit'];
        
        
        if($status =='tolakinterviewuser'){
            
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                     
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                             status='step4', statusinterviewuser='tolak' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                                <!-- //header("Location:http://localhost/recruitment_center/media.php?module=app_screening&act=view_screening");                 -->
<?php                    }
                else {
                    echo "gagal dunk";
                }    
            }
            
        }
        
        else if($status =='terimainterviewuser'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step4', statusinterviewuser='ok' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        
        
        
           
}



//update interview user

if($_GET['act']=="update_appsintuser"){
        $ad=$_POST["item"];
        
        $jumlah = count($_POST["item"]);
        
        $pw=md5($_POST['pass']);
        $status=$_POST['btnsubmit'];
        
        
        if($status =='tolak'){
            
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                     
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='tolakstep4' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                                <!-- //header("Location:http://localhost/recruitment_center/media.php?module=app_screening&act=view_screening");                 -->
<?php                    }
                else {
                    echo "gagal dunk";
                }    
            }
            
        }
        
        else{
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step5' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        
        
        
           
}

//update psikotest

if($_GET['act']=="update_appspsi"){
        $ad=$_POST["item"];
        
        $jumlah = count($_POST["item"]);
        
        $pw=md5($_POST['pass']);
        $status=$_POST['btnsubmit'];
        
        
        if($status =='tolakinthr'){
            
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                     
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step3' , statusinterviewhr='tolak' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                                <!-- //header("Location:http://localhost/recruitment_center/media.php?module=app_screening&act=view_screening");                 -->
<?php                    }
                else {
                    echo "gagal dunk";
                }    
            }
            
        }
        
        else if($status =='terimainthr'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step3' , statusinterviewhr='ok' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                                            
                                       //     echo "$updatescreening";
                            ?>
                                
                           <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        
        
        
           
}

//update mcu

if($_GET['act']=="daftar_mcu"){
        
        
        $jumlah = count($_POST["item"]);
        
        $pw=md5($_POST['pass']);
        $status=$_POST['btnsubmit'];
        
        
        if($status =='prepare'){
            
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from reg_mcu where idpelamar = '$id'";
                            $hasil = mysql_query($sql1);
                            
                     
                           
                if ($row=  mysql_num_rows($hasil))
                    {            
                            Print"<b><Center>Maaf $id sudah terdaftar  <b></center>";
                    }
                else{      
                            $squery1="SELECT * FROM applicant_personal WHERE applicantid='$id'";
                            $hasil= mysql_query($squery1);
                            while ($rs1= mysql_fetch_object($hasil))
                            {
                            $tglmcu1=$_POST['txttglmcu'];
                            $tglmcu=$tglmcu1[$id-1];
                            $idvendor1=$_POST['txtvendor'];
                            $idvendor=$idvendor1[$id-1];
                            $remark1=$_POST['txtremark'];
                            $remark=$remark1[$id-1];
                            $tahun=date(Y);
                            $bulan=date(mm);
                            
                            $nosurat=mcu.$tahun.$bulan++;
                            
                            $inputregmcu ="INSERT INTO reg_mcu(idpelamar,nosurat,  tglmcu, idvendor,remark, status)
                                                   VALUES('$id','$nosurat','$tglmcu','$idvendor','$remark','submited')";       
                                            $masuk=  mysql_query($inputregmcu);
                                         echo "$inputregmcu - $jumlah";               
                                     ?>
                           
<!--                            <script> location.replace("?module=app_screening&act=view_interviewuser"); </script>  -->
                                <!-- //header("Location:http://localhost/recruitment_center/media.php?module=app_screening&act=view_screening");                 -->
<?php                    
                            }
                        }
                 
            }
            
        }
        
        else if($status =='terimainterviewuser'){
            for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="Select * from applicant_personal where applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            
                       
                            
                if ($row=mysql_fetch_row($hasil))
                    {            
                            $updatescreening =" UPDATE applicant_personal SET
                                            status='step4', statusinterviewuser='ok' WHERE applicantid = '$id'";       
                                            $masuk=  mysql_query($updatescreening);
                            ?>
                            <script> location.replace("?module=app_screening&act=view_screeningpull"); </script>  
                     <?php       
                    }
                else {
                    echo "gagal dunk";
                }    
            }
        }
        
        
        
           
}

//Simpan Tanda Terima Berkas Berhenti
if($_GET['act']=="ttb_resign"){
 // print_r($_POST);exit;
        $jumlah = count($_POST["txtempno"]); //jumlah pake count txtempno
        $empno2=$_POST['item'];
        $arrEmp=$_POST['txtempno'];
        //$jumlah = count($_POST["item"]);
        $pw=md5($_POST['pass']);
        $empno=$_POST['txtempno'];
        
        
        for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];
               //print_r($_POST['item']);exit;
                $ad=$_POST['item'][$i];    
                $empno1=$_POST['txtempno'];
                                $empno=$empno1[$id];
                $total=COUNT($id);
               $sql1 ="Select * from t_berkasbht WHERE empno = '$id'";
                            $hasil = mysql_query($sql1);
                     
                  if ($row=mysql_num_rows($hasil))
                    {            
                           
                            
                            //update data
                                  //    print_r('txt'.$arrEmp[$i]);
                            if(in_array($arrEmp[$i],$empno2)){ //saya tambahin kondisi ini
                                $keys=array_search ($arrEmp[$i], $empno2);
                                    
                               
                                $empno1=$_POST['txtempno'];
                                $empno=$empno1[$id-1];
                                $cksrtresign1=$_POST['cksrtresign'];
                              
                                $txturl1=$_POST['txturl'];
                                $txturl=$txturl1[$i];
                                $tempId=$arrEmp[$i];  
                                $cksrtresignx=$_POST['cksrtresign'][$keys];
                                $txtkphk=$_POST['txtkphk'][$keys];
                                $txtklksrhterima=$_POST['txtklksrhterima'][$keys];
                                $txttglsrtresign=$_POST['txttglsrtresign'][$keys];
                                $txttglterimaklk=$_POST['txttglterimaklk'][$keys];
                              
                                $updateberkas =" UPDATE t_berkasbht SET
                                            srtresign='$cksrtresignx', 
                                            tglterimasrt='$txttglsrtresign',
                                            kphk='$txtkphk',
                                            klksrhterima='$txtklksrhterima',
                                            tglterimaklk='$txttglterimaklk',
                                            urlberkas='$txturl'
                                            WHERE empno = '$tempId'";       
                                            $masuk=  mysql_query($updateberkas);
                             
                                  echo " update : $updateberkas <br>";
                                 
                            } //
                             ?>   
                          <?php
                    }
                else{          // print_r('txt'.$arrEmp[$i]);
                            if(in_array($arrEmp[$i],$empno2)){ //saya tambahin kondisi ini
                                $keys=array_search ($arrEmp[$i], $empno2);
                                    
                               
                                $empno1=$_POST['txtempno'];
                                $empno=$empno1[$id-1];
                                $cksrtresign1=$_POST['cksrtresign'];
                               // $cksrtresign=$cksrtresign1[$id-1];
                                $cksrtresign=$cksrtresign1[$i];//ini pak $id = emp_no, seharusnya di isi array 0,1,2,dst.. saya hardcode 0 dulu biar keluar Y nya
                                $cksrtresign2=$txttglsrtresign1[$id];
                                $cksrtresign3=$cksrtresign2[$i-1];
                                $cksrtresign4=$cksrtresign2[$i+1];
                                $txttglsrtresign1=$_POST['txttglsrtresign'];
                                $txttglsrtresign=$txttglsrtresign1[$i];
                                //$txtkphk1=$_POST['txtkphk'];
                                //$txtkphk=$txtkphk1[$i];
                                //$txtklksrhterima1=$_POST['txtklksrhterima'];
                                //$txtklksrhterima=$txtklksrhterima1[$i];
                                $txttglterimaklk1=$_POST['txttglterimaklk'];
                                $txttglterimaklk=$txttglterimaklk1[$i];
                                $txturl1=$_POST['txturl'];
                                $txturl=$txturl1[$i];
                                $tempId=$arrEmp[$i];  
                                $cksrtresignx=$_POST['cksrtresign'][$keys];
                                $txtkphk=$_POST['txtkphk'][$keys];
                                $txtklksrhterima=$_POST['txtklksrhterima'][$keys];
                               // print_r($keys);
                                
                                
                                //echo "<br> nilai i = $i ";
                                   
                                   $masuk="INSERT INTO t_berkasbht(empno, srtresign, tglterimasrt, kphk, klksrhterima, klkexitint, 
                                     tglterimaklk, urlberkas, sketbht, tglkirim, istatus, remark) 
                                 VALUES(
                                 '$tempId','$cksrtresignx','$txttglsrtresign','$txtkphk','$txtklksrhterima',                                     "
                                        . "'$txtklksrhterima','$txttglterimaklk',
                                  '$txturl','','','receive',''    
                                  )";
                                   mysql_query($masuk);
                                  
                            }
                            
                              ?>   
                            <script> location.replace("?module=docresign"); </script> <?php
                        }
                 
            }       
        echo "keluar
             <br>
          ";

}
//Simpan Tanda Terima Berkas karyawan aktif
if($_GET['act']=="ttb_berkaskaryawan"){
                
                $txtempno=$_GET[id];
                $txttglberkas=$_POST[txttglberkas];
                $rbsrtlam1=$_POST[rbsrtlam1];
                $rbcurvit1=$_POST[rbcurvit1];
                $rbphoto1=$_POST[rbphoto1];
                
                $rbdpel1=$_POST[rbdpel1];
                $rbref1=$_POST[rbref1];
                $rbtranskrip1=$_POST[rbtranskrip1];
                $rbijzsmu1=$_POST[rbijzsmu1];
                $rbijzdiploma1=$_POST[rbijzdiploma1];
                $rbstrata2=$_POST[rbstrata2];
                
                $rbktp1=$_POST[rbktp1];
                $rbsim1=$_POST[rbsim1];
                $rbaktelahir=$_POST[rbaktelahir];
                $rbkk=$_POST[rbkk];
                $rbnpwp1=$_POST[rbnpwp1];
                $rbpassport=$_POST[rbpassport];
                
                $rbkitas=$_POST[rbkitas];
                $rbaktenikah=$_POST[rbaktenikah];
                $rbaktecerai=$_POST[rbaktecerai];
                $rbstnk=$_POST[rbstnk];
                $rbjamsostek=$_POST[rbjamsostek];
                
                
                $rbktppas=$_POST[rbktppas];
                $rbaktelhrpass=$_POST[rbaktelhrpass];
                $rbaktelhranak=$_POST[rbaktelhranak];
                
                $rbspk=$_POST[rbspk];
                $rbpajak=$_POST[rbpajak];
                $rbkerahasiaan=$_POST[rbkerahasiaan];
                $rbkodeetik=$_POST[rbkodeetik];
                $rbpenempatan=$_POST[rbpenempatan];
                $rbpersonnelaction=$_POST[rbpersonnelaction];
                
                $rbikatandinas=$_POST[rbikatandinas];
                $rbkomitmen=$_POST[rbkomitmen];
                
                $rbasuransi=$_POST[rbasuransi];
                $rbpendjamsostek=$_POST[rbpendjamsostek];
                $rbbpjspensiun=$_POST[rbbpjspensiun];
                
                $txtnorek=$_POST[txtnorek];
                $txtnamabank=$_POST[txtnamabank];
                $txtcabangbank=$_POST[txtcabangbank];
                
                $rbpauli=$_POST[rbpauli];
                $rbbeta3=$_POST[rbbeta3];
                $rbwpt=$_POST[rbwpt];
                $rbpsikorecruitment=$_POST[rbpsikorecruitment];
                $rbwarteg=$_POST[rbwarteg];
                $rbdisc=$_POST[rbdisc];
                
                
                $rbwwcruser=$_POST[rbwwcruser];
                $rbwwcrhr=$_POST[rbwwcrhr];
                $rbtestkesehatan=$_POST[rbtestkesehatan];
                $rbpsikoassessment=$_POST[rbpsikoassessment];
                
                $txtsimpandmana=$_POST[txtsimpandmana];
                $txtsimpanhardcopy=$_POST[txtsimpanhardcopy];
                $rbelo=$_POST[rbelo];
                
                $txtcathrd=$_POST[txtcathrd];
                
                //cari ada yang double tidak
                
                $caridouble="SELECT * FROM berkas_employeefile WHERE empno='$txtempno'";
                $hasilcari=mysql_query($caridouble);
                 if ($rownya=mysql_num_rows($hasilcari))
                    { 
                       $updateberkas =" UPDATE berkas_employeefile SET
                                        srtlamaran= '$_POST[rbsrtlam1]',
                                        srtcv='$_POST[rbcurvit1]',
                                        photo='$_POST[rbphoto1]',

                                        dtpelamar='$_POST[rbdpel1]',
                                        srtrefrensi='$_POST[rbref1]',
                                        transkripnilai='$_POST[rbtranskrip1]',
                                        ijzhama='$_POST[rbijzsmu1]',
                                        ijzhdiploma='$_POST[rbijzdiploma1]',
                                        ijzhsdua='$_POST[rbstrata2]',

                                        ktp='$_POST[rbktp1]',
                                        sim='$_POST[rbsim1]',
                                        aktelahir='$_POST[rbaktelahir]',
                                        kk='$_POST[rbkk]',
                                        npwp='$_POST[rbnpwp1]',
                                        passport='$_POST[rbpassport]',

                                        kitas='$_POST[rbkitas]',
                                        aktenikah='$_POST[rbaktenikah]',
                                        aktecerai='$_POST[rbaktecerai]',
                                        stnk='$_POST[rbstnk]',
                                        kartujamsostek='$_POST[rbjamsostek]',


                                        ktppasangan='$_POST[rbktppas]',
                                        aktelahirpasangan='$_POST[rbaktelhrpass]',
                                        aktelahiranak='$_POST[rbaktelhranak]',

                                        spk='$_POST[rbspk]',
                                        pajak='$_POST[rbpajak]',
                                        kerahasiaan='$_POST[rbkerahasiaan]',
                                        kodeetik='$_POST[rbkodeetik]',
                                        penempatan='$_POST[rbpenempatan]',
                                        personactions='$_POST[rbpersonnelaction]',

                                        perjanjiandinas='$_POST[rbikatandinas]',
                                        komitmen='$_POST[rbkomitmen]',

                                        pendaftaranasuransi='$_POST[rbasuransi]',
                                        pendbpjstenagakerja='$_POST[rbpendjamsostek]',
                                        pendbpjspensiun='$_POST[rbbpjspensiun]',

                                        norek='$_POST[txtnorek]',
                                        namabank='$_POST[txtnamabank]',
                                        cabang='$_POST[txtcabangbank]',

                                        hasilpauli='$_POST[rbpauli]',
                                        beta3='$_POST[rbbeta3]',
                                        wpt='$_POST[rbwpt]',
                                        psikogramrekrut='$_POST[rbpsikorecruitment]',
                                        warteg='$_POST[rbwarteg]',
                                        disc='$_POST[rbdisc]',

                                        wawancarauser='$_POST[rbwwcruser]',
                                        wwcrhr='$_POST[rbwwcrhr]',
                                        mcu='$_POST[rbtestkesehatan]',
                                        psikogramassess='$_POST[rbpsikoassessment]',

                                        rblokasisimpan='$_POST[txtsimpandmana]',
                                        lokasisimpan='$_POST[txtsimpanhardcopy]',
                                        scanelo= '$_POST[rbelo]',
                                         istatus='aktif',   
                                        remark= '$_POST[txtcathrd]'
                                            
                                            
                                            WHERE empno = '$txtempno'";      
                                            $masuk=  mysql_query($updateberkas);
                                           ?>   
                            <script> location.replace("?module=view_berkaskaryawan"); </script> <?php
                                           
                    }
                 else{
                                $masuk="INSERT INTO berkas_employeefile(
                                         empno, tglterimaberkas, srtlamaran, srtcv, photo ,
                                        dtpelamar, srtrefrensi, transkripnilai, ijzhama, ijzhdiploma, ijzhsdua, ktp, sim, aktelahir, kk, 
                                        npwp, passport, kitas,aktenikah, aktecerai, stnk, kartujamsostek, ktppasangan, aktelahirpasangan,
                                        aktelahiranak, spk, pajak, kerahasiaan, kodeetik, penempatan, personactions, perjanjiandinas, komitmen, 
                                        pendaftaranasuransi, pendbpjstenagakerja, pendbpjspensiun, norek, namabank, cabang, hasilpauli, beta3,wpt,psikogramrekrut, warteg,disc,
                                        wawancarauser, wwcrhr, mcu,psikogramassess,  rblokasisimpan, 
                                        lokasisimpan, scanelo, istatus, remark 
                                     )
                                 VALUES('$txtempno','$txttglberkas','$_POST[rbsrtlam1]','$_POST[rbcurvit1]','$_POST[rbphoto1]',
                                        '$_POST[rbdpel1]','$_POST[rbref1]','$_POST[rbtranskrip1]',"
                                        . "'$_POST[rbijzsmu1]','$_POST[rbijzdiploma1]','$_POST[rbstrata2]','$_POST[rbktp1]',"
                                        . "'$_POST[rbsim1]','$_POST[rbaktelahir]','$_POST[rbkk]','$_POST[rbnpwp1]','$_POST[rbpassport]',"
                                        . "'$_POST[rbkitas]','$_POST[rbaktenikah]','$_POST[rbaktecerai]','$_POST[rbstnk]',
                                          '$_POST[rbjamsostek]','$_POST[rbktppas]','$_POST[rbaktelhrpass]','$_POST[rbaktelhranak]',"
                                        . "'$_POST[rbspk]','$_POST[rbpajak]','$_POST[rbkerahasiaan]',
                                         '$_POST[rbkodeetik]','$_POST[rbpenempatan]','$_POST[rbpersonnelaction]',"
                                        . "'$_POST[rbikatandinas]','$_POST[rbkomitmen]','$_POST[rbasuransi]','$_POST[rbpendjamsostek]',"
                                        . "'$_POST[rbbpjspensiun]',
                                          '$_POST[txtnorek]','$_POST[txtnamabank]','$_POST[txtcabangbank]','$_POST[rbpauli]',"
                                        . "'$_POST[rbbeta3]','$_POST[rbwpt]','$_POST[rbpsikorecruitment]',   
                                          '$_POST[rbwarteg]','$_POST[rbdisc]','$_POST[rbwwcruser]','$_POST[rbwwcrhr]', "
                                        . "'$_POST[rbtestkesehatan]','$_POST[rbpsikoassessment]','$_POST[txtsimpandmana]',"
                                        . "'$_POST[txtsimpanhardcopy]','$_POST[rbelo]','aktif','$_POST[txtcathrd]'    
                                  )";
                                   mysql_query($masuk);
                                    ?>   
                            <script> location.replace("?module=view_berkaskaryawan"); </script> <?php
                     
}}   
?>
