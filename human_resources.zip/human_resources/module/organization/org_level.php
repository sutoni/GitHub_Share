<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Organization
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_organization">Organization</a></li>
            <li class="active">Organization Level</li>
          </ol>
        </section>


<?php
if($_GET['act']=="input"){
	?>

           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Organization Struktur</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=orglevel&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_orglevel">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Organization Level Name</label>
                                            <input class="form-control" placeholder="Organization Level Name" name="txtorglevelname" id="txtorglevelname">
                                        </div>
                                       <div class="form-group">
                                            <label>Level</label>
                                            <input class="form-control" placeholder="Level" name="txtorglevel" id="txtorglevel">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                        </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
           <?php } ?>
           
           
           
           <?php
if($_GET['act']=="edit_orglevel"){
    $id=$_GET[id];
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Organization Level</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=orglevel&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                
                                <?php                            
                            	$sql="select orglevelname,orglevel, keterangan from organization_level where orglevelname='$id'";
                                $hasil=mysql_query($sql);
				$rs=mysql_fetch_array($hasil);
                                $orglevelname=$rs[orglevelname];
                                
                                
                                ?>
                                    <form method="post" role="form" action="?module=simpan&act=edit_orglevel">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Organization Level Name</label>
                                            <input class="form-control" placeholder="Organization Level Name" name="txtorglevelname" id="txtorglevelname" value="<?php echo $orglevelname; ?>">
                                        </div>
                                       <div class="form-group">
                                            <label>Level</label>
                                            <input class="form-control" placeholder="Level" name="txtorglevel" id="txtorglevel" value="<?php echo $rs[orglevel]; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rs[keterangan]; ?></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                          </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
             </section>
            <!-- /.row -->
            <?php } ?>
      </div>          