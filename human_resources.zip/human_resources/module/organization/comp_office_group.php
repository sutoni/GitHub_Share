<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Company Office
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-building-o"></i> Home</a></li>
            <li><a href="?module=view_company&act=view_companygroup">Company</a></li>
            <li class="active">Company Office Group</li>
          </ol>
        </section>

<?php
if($_GET['act']=="input"){
	?>
              <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Company Office Group</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=companygroup&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_compoffgroup">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Company Office Group</label>
                                            <input class="form-control" placeholder="Company Office Group" name="txtcompoffgroup" id="txtcompoffgroup">
                                        </div>
                                      
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                         </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
           <?php } ?>
           
           
           
           <?php
if($_GET['act']=="edit_compoffgroup"){
    $id=$_GET['id'];
    ?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Company Office Group</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=companygroup&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=edit_compoffgroup">
                                   <?php
                                        $sql="SELECT * FROM company_office_group WHERE Nm_comp_group='$id'";
                                        $hasil=mysql_query($sql);
                                        $rsu=  mysql_fetch_array($hasil);
                                   
                                   ?>
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Company Office Group</label>
                                            <input class="form-control" placeholder="Company Office Group" name="txtcompoffgroup" id="txtcompoffgroup" value="<?php echo $rsu[Nm_comp_group]; ?>">
                                        </div>
                                      
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rsu[keterangan]; ?></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <?php } ?>
      </div>         