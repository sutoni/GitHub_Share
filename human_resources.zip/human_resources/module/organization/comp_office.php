<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Company Office
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-building-o"></i> Home</a></li>
            <li><a href="?module=view_company&act=view_companyoffdetail">Company</a></li>
            <li class="active">Company Office Detail</li>
          </ol>
        </section>
<?php
if($_GET['act']=="input"){
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Company Office Detail</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=compoffdetail&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_compoffdetail">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Company Office </label>
                                            <input class="form-control" placeholderCompany Office " name="txtcompoffname" id="txtcompoffname">
                                        </div>
                                      
                                          <div class="form-group">
                                            <label>Company Office Category</label>  
                                            <select class="form-control" name="txtcompoffcat" id="txtcompoffcat">
                                                        <?php 
                                                              $sql=mysql_query("select Nm_comp_category from company_category");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                 echo " <option value='$rs[Nm_comp_category]'>$rs[Nm_comp_category]</option>";
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                    
                                         <div class="form-group">
                                            <label>Company Office Group</label>
                                            <select class="form-control" name="txtcompoffgroup" id="txtcompoffgroup">
                                                        <?php 
                                                              $sql=mysql_query("select * from company_office_group");
                                                              while($rsi=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rsi[Nm_comp_group]'>$rsi[Nm_comp_group]</option>";
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Address</label>
                                            <textarea class="form-control" placeholder="Address" name="txtaddress" id="txtaddress" rows="3"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label>Tax Compulsion No</label>
                                            <input class="form-control" placeholder="Nomer NPWP" name="txtnpwp" id="txtnpwp">
                                        </div>
                                        <div class="form-group">
                                            <label>Kantor Pelayanan Pajak</label>
                                            <input class="form-control" placeholder="Kantor Pajak Terdekat" name="txtkantorpajak" id="txtkantorpajak">
                                        </div>
                                    
                                        
                                         <div class="form-group col-lg-5">
                                            <label>Fax</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txtfax" id="txtfax">
                                         </div>
                                        <div class="form-group col-lg-5" colspan="0">
                                            <label>Telpon</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txttelpon" id="txttelpon">
                                        </div>
                                    
                                       
                                        
                                    <BR>
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    <p></p>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        
                                    <br>
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
           <?php } ?>
           
           
           
           <?php
if($_GET['act']=="edit_compoffdetail"){
    $id=$_GET['id'];
    ?>
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Company Office Detail</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=compoffdetail&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=edit_compoffdetail">
                                         <?php
                                            $sql1="SELECT * FROM company_office_detail WHERE Nm_comp_office='$id'";
                                            $hasil2=mysql_query($sql1);
                                            $rs2=  mysql_fetch_array($hasil2);
                                         ?> 
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Company Office </label>
                                            <input class="form-control" placeholder="Company Office " name="txtcompoffname" id="txtcompoffname" value="<?php echo $rs2[Nm_comp_office]; ?>" >
                                        </div>
                                      
                                          <div class="form-group">
                                            <label>Company Office Category</label>  
                                            <select class="form-control" name="txtcompoffcat" id="txtcompoffcat">
                                                        <?php 
                                                            echo " <option value='$rs2[Id_comp_category]'>$rs2[Id_comp_category]</option>";
                                                            $compcat=$rs2[Id_comp_category];
                                                              $sql=mysql_query("select Nm_comp_category from company_category WHERE Nm_comp_category != '$compcat'");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                 echo " <option value='$rs[Nm_comp_category]'>$rs[Nm_comp_category]</option>";
                                                      }
                                                      ?>
                                            </select>
                                           </div>
                                    
                                         <div class="form-group">
                                            <label>Company Office Group</label>
                                            <select class="form-control" name="txtcompoffgroup" id="txtcompoffgroup">
                                                        <?php 
                                                              echo " <option value='$rs2[Id_comp_group]'>$rs2[Id_comp_group]</option>";  
                                                              $compgroup = $rs2[Id_comp_group] ;
                                                              $sql=mysql_query("select Nm_comp_group from company_office_group  Nm_comp_group !='$compgroup'");
                                                              while($rsi=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rsi[Nm_comp_group]'>$rsi[Nm_comp_group]</option>";
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Address</label>
                                            <textarea class="form-control" placeholder="Address" name="txtaddress" id="txtaddress" rows="3"><?php echo $rs2[Address]; ?></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label>Tax Compulsion No</label>
                                            <input class="form-control" placeholder="Nomer NPWP" name="txtnpwp" id="txtnpwp" value="<?php echo $rs2[Nomor_npwp]; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Kantor Pelayanan Pajak</label>
                                            <input class="form-control" placeholder="Kantor Pajak Terdekat" name="txtkantorpajak" id="txtkantorpajak" value="<?php echo $rs2[Nm_cabang_pajak]; ?>">
                                        </div>
                                    
                                        
                                         <div class="form-group col-lg-5">
                                            <label>Fax</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txtfax" id="txtfax" value="<?php echo $rs2[Fax]; ?>">
                                         </div>
                                        <div class="form-group col-lg-5" colspan="0">
                                            <label>Telpon</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txttelpon" id="txttelpon" value="<?php echo $rs2[Tlp]; ?>">
                                        </div>
                                    
                                       
                                        
                                    <BR>
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom" value="<?php echo $rs2[Validfrom]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto" value="<?php echo $rs2[validto]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                  <p></p>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        
                                    <br>
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <?php } ?>
      </div>      