 <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Organization
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_organization">Organization</a></li>
            <li class="active">Organization Struktur</li>
          </ol>
        </section>

<?php
if($_GET['act']=="input"){
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Organization Struktur</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=orgstruktur&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_orgstruktur&id=txtorgcode">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Organization Code</label>
                                            <input class="form-control col-sm-3" placeholder="Organization Code" name="txtorgcode" id="txtorgcode" >
                                        </div>
                                       <div class="form-group">
                                            <label>Organization Name</label>
                                            <input class="form-control" placeholder="Organization Name" name="txtorgname" id="txtorgname">
                                        </div>
                                        <div class="form-group">
                                            <label>Parent Organization Code</label>
                                            <input class="form-control" placeholder="Parent Organization Code" name="txtparentorgcode" id="txtparentorgcode">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Organization Level</label>
                                            <select id="txtorglevel" name="txtorglevel" class="form-control">
                                                
                                                <?php
                                                    $cari="SELECT * FROM organization_level ORDER BY orglevel";
                                                    $hasil=  mysql_query($cari);
                                                     WHILE($rs1=  mysql_fetch_array($hasil)){
                                                    $orglevel=$rs1[orglevel];
                                                    $orglevelname=$rs1[orglevelname];
                                                    echo "<option value='$orglevel'>$orglevelname</option>";}
                                                ?>                                                
                                            </select>
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Cost Center</label>
                                            <input class="form-control" placeholder="Cost Center" name="txtcostcenter" id="txtcostcenter">
                                        </div>
                                        
                                     <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
            
           <?php } ?>


           
           <?php
if($_GET['act']=="edit_orgstruktur"){
	$id=$_GET[id];
    ?>
           
             <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Organization Struktur</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=app_widget"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=edit_orgstruktur">
                                <?php
                                    
                                    include "config/conn.php";
                                    $sql="SELECT a.orgcode, a.org_name, a.parent_orgcode, b.orglevel, a.costcenter,
                                    a.validfrom, a.validto, b.orglevelname ,a.levelorg
                                    FROM organization_struktur a
                                    INNER JOIN organization_level b ON b.orglevel=a.levelorg WHERE a.orgcode='$id' ";
                                    $hasil = mysql_query($sql);
                                    $rs=  mysql_fetch_array($hasil);
                                    
                                ?>
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Organization Code</label>
                                            <input class="form-control col-sm-3" placeholder="Organization Code" name="txtorgcode" id="txtorgcode" value="<?php echo $rs[orgcode]; ?>" >
                                        </div>
                                       <div class="form-group">
                                            <label>Organization Name</label>
                                            <input class="form-control" placeholder="Organization Name" name="txtorgname" id="txtorgname" value="<?php echo $rs[org_name]; ?> ">
                                        </div>
                                        <div class="form-group">
                                            <label>Parent Organization Code</label>
                                            <input class="form-control" placeholder="Parent Organization Code" name="txtparentorgcode" id="txtparentorgcode" value="<?php echo $rs[parent_orgcode]; ?> ">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Organization Level</label>
                                            <select id="txtorglevel" name="txtorglevel" class="form-control">
                                                <option value="<?php echo $rs[levelorg]; ?> "><?php echo $rs[orglevelname]; ?></option>
                                                <?php
                                                    $cek=$rs[levelorg];
                                                    $cari="SELECT * FROM organization_level WHERE orglevel != '$cek' ";
                                                    $hasil=  mysql_query($cari);
                                                    WHILE($rs1=  mysql_fetch_array($hasil)){
                                                    $orglevel=$rs1[orglevel];
                                                    $orglevelname=$rs1[orglevelname];
                                                    echo "<option value='$orglevel'>$orglevelname</option>";}
                                                ?>  
                                                
                                            </select>
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Cost Center</label>
                                            <input class="form-control" placeholder="Cost Center" name="txtcostcenter" id="txtcostcenter" value=" <?php echo $rs[costcenter]; ?>">
                                        </div>
                                        
                                     <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom" value="<?php echo $rs[validfrom]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto" value="<?php echo $rs[validto]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
             </section>
            <!-- /.row -->
     
            <?php } ?>
      </div>        