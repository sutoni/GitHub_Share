
<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
     
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Overview Company Office Category
            <small>advanced tables</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-building-o"></i> Home</a></li>
            <li><a href="#">Basic Konfigurasi</a></li>
            <li><a href="?module=view_company">Company</a></li>
            <li class="active">Overview Company Office</li>
          </ol>
        </section>
    
        <br>
            &nbsp;&nbsp;    <!-- /.col-lg-12 -->
                <a href="?module=view_company&act=view_companycat"><button type="submit" class="btn btn-default">Overview Comp Category</button></a>
                
                <a href="?module=view_company&act=view_companygroup"><button type="submit" class="btn btn-default"  >Overview Comp Office Group</button></a>
                
                <a href="?module=view_company&act=view_companyoffdetail"><button type="submit" class="btn btn-default"  >Overview Comp Office Detail</button></a>
                
                
            <!-- /.row -->          
<br><br>
    <?php
    /*
        Overview Organization Level
    */
    
if($_GET['act']=="view_companycat"){
	?>
          <section class="content">
          
          
          
            <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                <!-- <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview Company Category
                        </div>
                         /.panel-heading 
                        <div class="panel-body">
                            <div class="table-responsive">-->
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Company Office Category</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=org_compcat&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div>     
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Company Category</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from company_category";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[Nm_comp_category]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                            <td class="text-center"><a href="?module=org_compcat&act=edit_compcat&id=<?php echo $rsa['Nm_comp_category'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_compcat&id=<?php echo $rsa['Nm_comp_category'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                            
                                            
                                        </tr>

<?php }
?>                                        
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                             <th class="text-center">Company Category</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>



    <?php
    /*
        Overview Company Office Group
    */
if($_GET['act']=="view_companygroup"){
	?>
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                <!-- <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview Company Category
                        </div>
                         /.panel-heading 
                        <div class="panel-body">
                            <div class="table-responsive">-->
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Company Office Group</h3>
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Company Office Group Name</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from company_office_group";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[Nm_comp_group]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                            <td class="text-center"><a href="?module=org_compoffgroup&act=edit_compoffgroup&id=<?php echo $rsa['Nm_comp_group'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_compoffgroup&id=<?php echo $rsa['Nm_comp_group'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                            
                                            
                                        </tr>

<?php }
?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="text-center">Company Office Group Name</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
            
            
            
            
  <?php } ?>

              <?php
    /*
        Overview Company Office Detail
    */
if($_GET['act']=="view_companyoffdetail"){
	?>
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                <!-- <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview Company Category
                        </div>
                         /.panel-heading 
                        <div class="panel-body">
                            <div class="table-responsive">-->
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Company Office Detail</h3>
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Company Office</th>
                                            <th class="text-center">Category</th>
                                            <th class="text-center">Office Group</th>
                                            <th class="text-center">Address</th>
                                            <th class="text-center">Tax No</th>
                                            <th class="text-center">Kantor Pajak</th>
                                            <th class="text-center">Fax</th>
                                            <th class="text-center">Telp</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from company_office_detail";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[Nm_comp_office]";  ?></td>
                                            <td><?php echo"$rsa[Id_comp_category]";  ?></td>
                                            <td><?php echo"$rsa[Id_comp_group]";  ?></td>
                                            <td><?php echo"$rsa[Address]";  ?></td>
                                            <td><?php echo"$rsa[Nomor_npwp]";  ?></td>
                                            <td><?php echo"$rsa[Nm_cabang_pajak]";  ?></td>
                                            <td><?php echo"$rsa[Fax]";  ?></td>
                                            <td><?php echo"$rsa[Tlp]";  ?></td>
                                            <td><?php echo"$rsa[Validfrom]";  ?></td>
                                            <td><?php echo"$rsa[validto]";  ?></td>

                                            <td class="text-center"><a href="?module=org_compoff&act=edit_compoffdetail&id=<?php echo $rsa['Nm_comp_office'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_compoffdetail&id=<?php echo $rsa['Nm_comp_office'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                            
                                            
                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">Company Office</th>
                                            <th class="text-center">Category</th>
                                            <th class="text-center">Office Group</th>
                                            <th class="text-center">Address</th>
                                            <th class="text-center">Tax No</th>
                                            <th class="text-center">Kantor Pajak</th>
                                            <th class="text-center">Fax</th>
                                            <th class="text-center">Telp</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
             <!-- DATA TABES SCRIPT -->
    <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>
            
            
  <?php } ?>