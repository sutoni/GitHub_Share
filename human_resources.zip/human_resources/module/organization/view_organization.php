<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
     
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
       <section class="content-header">
            <h1>
            Overview Organization
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_company">Organization</a></li>
            <li class="active">Organization Struktur</li>
          </ol>
        </section>
                <!-- /.col-lg-12 -->
                <br>
                &nbsp;&nbsp;&nbsp; <a href="?module=view_organization&act=view_orgstruktur"><button type="submit" class="btn btn-default">Overview Organization Struktur</button></a>                
                <a href="?module=view_organization&act=view_org"><button type="submit" class="btn btn-default"  >Overview Organization Level</button></a>
                
            <!-- /.row -->          

    <?php
    /*
        Overview Organization Level
    */
    
if($_GET['act']=="view_orgstruktur"){
	?>
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Organization Struktur</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=orgstruktur&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Organization Level</th>
                                            <th class="text-center">Organizaiton Code</th>
                                            <th class="text-center">Organization Name</th>
                                            <th class="text-center">Parent Org Code</th>
                                            <th class="text-center">Cost Center</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="SELECT a.orgcode, a.org_name, a.parent_orgcode, b.orglevel, a.costcenter,
                a.validfrom, a.validto, b.orglevelname 
                FROM organization_struktur a
                INNER JOIN organization_level b ON b.orglevel=a.levelorg  ";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                             <td><?php echo"$rsa[orglevelname]";  ?></td>
                                            <td><?php echo"$rsa[orgcode]";  ?></td>
                                            <td><?php echo"$rsa[org_name]";  ?></td>
                                            <td><?php echo"$rsa[parent_orgcode]";  ?></td>
                                            <td><?php echo"$rsa[costcenter]";  ?></td>
                                            <td><?php echo"$rsa[validfrom]";  ?></td>
                                            <td class="text-center"><?php echo"$rsa[validto]";  ?></td>
                                        
                                         <td class="text-center"><a href="?module=orgstruktur&act=edit_orgstruktur&id=<?php echo $rsa['orgcode'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                         <a href="?module=simpan&act=hapus_orgstruktur&id=<?php echo $rsa['orgcode'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                            
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                 <tfoot>
                                        <tr>
                                            <th class="text-center">Organization Level</th>
                                            <th class="text-center">Organizaiton Code</th>
                                            <th class="text-center">Organization Name</th>
                                            <th class="text-center">Parent Org Code</th>
                                            <th class="text-center">Cost Center</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                
            
            </div><!-- /.row -->
        </section><!-- /.content -->
           
            <!-- /.row -->
  <?php } ?>



    <?php
    /*
        Overview Organization Level
    */
if($_GET['act']=="view_orglevel"){
	?>
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Organization Level</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=orglevel&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Organization Name</th>
                                            <th class="text-center">Organization Level</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from organization_level";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[orglevelname]";  ?></td>
                                            <td><?php echo"$rsa[orglevel]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                        <td class="text-center"><a href="?module=orglevel&act=edit_orglevel&id=<?php echo $rsa['orglevelname'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                         <a href="?module=simpan&act=hapus_orglevel&id=<?php echo $rsa['orglevelname'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                            
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">Organization Name</th>
                                            <th class="text-center">Organization Level</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
           
            <!-- /.row -->
  <?php } ?>
 </div>