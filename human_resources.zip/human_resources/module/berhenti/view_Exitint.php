<?php

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{
   
    ?>
<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
     
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
         
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Exit Document</a></li>
            <li><a href="?module=view_position&act=view_posstruktur">Overview</a></li>
            <li class="active">Overview Exit Interview</li>
          </ol>
        </section>


   
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                      <br>
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Exit Interview</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=inExitinterview"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center" rowspan="2">No</th>
                                          
                                            <th class="text-center" rowspan="2">Emp Name</th>
                                            <th class="text-center" rowspan="2">Position Title</th>
                                            <th class="text-center" rowspan="2">Org Name</th>
                                            <th class="text-center" rowspan="2">Company Office</th>
                                            <th class="text-center" rowspan="2">Alasan</th>
                                            <th class="text-center" rowspan="2">Bekerja</th>
                                            <th class="text-center" colspan="3">Komben</th>
                                            <th class="text-center" colspan="9">Pengembangan</th>
                                            <th class="text-center" colspan="5">Lingkungan</th>
                                            <th class="text-center" colspan="2">Umum</th>
                                            
                                            <th class="text-center" rowspan="2">Aksi</th>

                                        </tr>
                                        <tr>
                                            <th class="text-center" >1</th>
                                            <th class="text-center" >2</th>
                                            <th class="text-center" >3</th>
                                            
                                            <th class="text-center" >1</th>
                                            <th class="text-center" >2</th>
                                            <th class="text-center" >3</th>
                                            <th class="text-center" >4</th>
                                            <th class="text-center" >5</th>
                                            <th class="text-center" >6</th>
                                            <th class="text-center" >7</th>
                                            <th class="text-center" >8</th>
                                            <th class="text-center" >9</th>
                                            
                                            <th class="text-center" >1</th>
                                            <th class="text-center" >2</th>
                                            <th class="text-center" >3</th>
                                            <th class="text-center" >4</th>
                                            <th class="text-center" >5</th>
                                            
                                            <th class="text-center" >1</th>
                                            <th class="text-center" >2</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
$tahun = date("Y");

	$sql="SELECT  a.empno, b.empname AS nama , a.alasankeluar, 
            a.ket_alasan, a.sdhkerja, a.sebagaiapa,a.kombensatu, ket_kombensatu, a.kombendua, a.ket_kombendua,
            a.kombentiga, a.ket_kombentiga, a.devsatuind, a.devsatutrng, a.devsatukinerja,a.devsatuselflearning, a.devsatuproyek, a.devsatucoaching, a.devsatulain,
           a.devduamemahami, a.devduapersiapan, a.lingsatu, a.lingdua, a.lingtiga, a.lingempat,
           a.linglima,a.umsatu, a.umdua,b.orgname,b.curpostitle, b.curworkloc
           FROM t_hs_exitinterview a
           INNER JOIN i_personnelaction b ON a.empno=b.empno
           WHERE b.patype='Terminate Employee' AND 
           (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' )AND YEAR(b.effdate)='$tahun' ";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	$nomor++;
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$nomor";  ?></td>
                                            
                                            <td><?php echo"$rsa[nama]";  ?></td>
                                            <td><?php echo"$rsa[curpostitle]";  ?></td>
                                            <td><?php echo"$rsa[orgname]";  ?></td>
                                            <td><?php echo"$rsa[curworkloc]";  ?></td>
                                            
                                            <td><?php echo"$rsa[alasankeluar]";  ?></td>
                                            <td><?php echo"$rsa[sdhkerja]";  ?></td>
                                            
                                            <td><?php echo"$rsa[kombensatu]";  ?></td>
                                            <td><?php echo"$rsa[kombendua]";  ?></td>
                                            <td><?php echo"$rsa[kombentiga]";  ?></td>
                                            
                                            <td><?php echo"$rsa[devsatuind]";  ?></td>
                                            <td><?php echo"$rsa[devsatutrng]";  ?></td>
                                            <td><?php echo"$rsa[devsatukinerja]";  ?></td>
                                            <td><?php echo"$rsa[devsatuselflearning]";  ?></td>
                                            <td><?php echo"$rsa[devsatuproyek]";  ?></td>
                                            <td><?php echo"$rsa[devsatucoaching]";  ?></td>
                                            <td><?php echo"$rsa[devsatulain]";  ?></td>
                                            <td><?php echo"$rsa[devduamemahami]";  ?></td>
                                            <td><?php echo"$rsa[devduapersiapan]";  ?></td>
                                            
                                            <td><?php echo"$rsa[lingsatu]";  ?></td>
                                            <td><?php echo"$rsa[lingdua]";  ?></td>
                                            <td><?php echo"$rsa[lingtiga]";  ?></td>
                                            <td><?php echo"$rsa[lingempat]";  ?></td>
                                            <td><?php echo"$rsa[linglima]";  ?></td>
                                           
                                            <td><?php echo"$rsa[umsatu]";  ?></td>
                                            <td><?php echo"$rsa[umdua]";  ?></td>
                                            
                                            
                                            
                                           
                                            
                                            <td class="text-center"><a href="?module=posstruktur&act=edit_posstruktur&id=<?php echo $rsa['id_position'] ?>"><i class="fa fa-edit text-success"></i></a>  
                                            </td>    
                                           
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
              
            
            </div><!-- /.row -->
        </section><!-- /.content -->
           
 



      </div>
      
      <?php } ?>