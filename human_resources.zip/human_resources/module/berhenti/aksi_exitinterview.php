<?php

if (empty($_SESSION[username]) AND empty($_SESSION[passuser])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{

            include 'config/conn.php';
            $id=$_GET[id];
            $module=$_GET[module];
            $empno = $_POST['empno'];
            $alasan = $_POST['txtalasan'];
            $txtbelum = $_POST['txtbelum'];
            $txtjawaban1 = $_POST['txtjawaban1'];
            $txtbelum = $_POST['txtbelum'];
            $txtjawaban2 = $_POST[txtjawaban2];
            $rbkom1 = $_POST[rbkom1];
            $txtkomben1 = $_POST[txtkomben1];
            $rbkom2 = $_POST[rbkom2];
            $txtrbkom2 = $_POST[txtrbkom2];

            $rbkom3 = $_POST[rbkom3];
            $txtrbkom3 = $_POST[txtrbkom3];
            $rbpeng1 = $_POST[rbpeng1];
            $rbpeng2 = $_POST[rbpeng2];
            $rbpeng3 = $_POST[rbpeng3];
            $rbpeng4 = $_POST[rbpeng4];
            $rbpeng5 = $_POST[rbpeng5];
            $rbpeng6 = $_POST[rbpeng6];
            $rbpeng7 = $_POST[rbpeng7];
            $txtrbpeng7 = $_POST[txtrbpeng7];
            $rbpeng8 = $_POST[rbpeng8];

            $rbpeng9 = $_POST[rbpeng9];
            $rbling1 = $_POST[rbling1];
            $rbling2 = $_POST[rbling2];
            $rbling3 = $_POST[rbling3];
            $rbling4 = $_POST[rbling4];
            $rbling5 = $_POST[rbling5];
                
            $rbum1 = $_POST[rbum1];
            $rbum2 = $_POST[rbum2];
            $txtcathrd = $_POST[txtcathrd];
            
            
          
		$sql="select * from t_hs_exitinterview 
				where empno='$id'";
		$qry=mysql_query($sql);  
                echo "$sql";
                if ($row=mysql_fetch_row($qry))
		{
		 Print"<b><Center>Sudah terdaftar <br></b></center>";
			print"<center><b><a href='javascript:history.back(1)'>Kembali</a></b></center>";	
		}	 
		elseif(empty($txtjawaban1) ||empty($txtjawaban2) )
		{
			
			Print"<b><Center>Semua Harus Diisi <br></b></center>";
			print"<center><b><a href='javascript:history.back(1)'>Kembali</a></b></center>";
		}
		else {
			$masuk ="INSERT INTO t_hs_exitinterview VALUES ('$id','$alasan','$txtjawaban1','$txtbelum','$txtjawaban2',
                                '$rbkom1','$txtkomben1','$rbkom2','$txtrbkom2','$rbkom3',
                                '$txtrbkom3','$rbpeng1','$rbpeng2','$rbpeng3','$rbpeng4',
                                '$rbpeng5','$rbpeng6','$rbpeng7', '$txtrbpeng7','$rbpeng8','$rbpeng9',
                                '$rbling1','$rbling2','$rbling3','$rbling4','$rbling5'
                                ,'$rbum1','$rbum2','$txtcathrd')";
			$hasilnya = mysql_query($masuk);	
			
			
                        echo "$masuk";   
                        
                        
			Print"<b><Center>Terima Kasih data Sudah tersimpan <br></b></center>";
			print"<center><b><a href=?module=input>back</a> OR <a href='?module=inExitinterview'>next</a></b></center>";
			
		}
                
           
            
?>



<?php } ?>
