<?php

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{
   
    ?>
        
      <!--  <script type="text/javascript">
        //check all checkbox
        function check_all(val) {
        // Ganti nilai form_data sesuai dengan nama form dan deleted_items[] sesuai dengan nama checkbox
        var checkbox = document.form_data.elements['item[]'];
        if ( checkbox.length > 0 ) {
            for (i = 0; i < checkbox.length; i++) {
                if ( val.checked ) {
                    checkbox[i].checked = true;
                }
                else {
                    checkbox[i].checked = false;
                }
            }
        }
        else {
            if ( val.checked ) {
                checkbox.checked = true;
            }
            else {
                checkbox.checked = false;
            }
        }
        }
        </script> -->
<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
         
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Exit Document</a></li>
            <li><a href="?module=view_position&act=view_posstruktur">Document Resign</a></li>
            <li class="active">Document Resign</li>
          </ol>
        </section>


   
            <br><br>  
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                            
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Tanda Terima Berkas Berhenti</h3>
                                  <div class="pull-right hidden-xs">
                                       
                                      
                                      <a href="?module=pos_struktur&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                   <?php 
                                   echo "<form name='form_data' id='form_data' method='POST' action='?module=simpan&act=ttb_resign' >";
                                           ?>
                                    <button type="submit" value="Save" class="fa fa-save"></button>
                                <table id="example1" class="table table-bordered table-striped">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center" rowspan="2">No</th>
                                            <th class="text-center" rowspan="2">Empno</th>
                                            <th class="text-center" rowspan="2">Emp Name</th>
                                            <th class="text-center" rowspan="2">Position Title</th>
                                            <th class="text-center" rowspan="2">Org Name</th>
                                            <th class="text-center" rowspan="2">Company Office</th>
                                            <th class="text-center" colspan="6">Resign Document</th>
                                            
                                            
                                            <th class="text-center" rowspan="2">
                                                <input type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>
                                                Aksi</th>

                                        </tr>
                                        <tr>
                                            <th class="text-center" >Srt Resign</th>
                                            <th class="text-center" >Tgl Terima Srt Resign</th>
                                            <th class="text-center" >KPHK</th>
                                            <th class="text-center" >Kelengkapan</th><th class="text-center" >Tgl Terima KLK</th>
                                            <th class="text-center" >Url Berkas</th>                                           
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                   
                            <?php
                                
                            include "config/conn.php";
                            $no=1;
                            $tahun = date("Y");

                                    $sql="SELECT
                                            c.empno,
                                            c.empname AS Nama, c.curpostitle, c.curworkloc, c.orgname, 
                                            a.srtresign, a.tglterimasrt, a.kphk, a.klksrhterima, a.klkexitint,
                                            a.tglterimaklk, a.urlberkas, a.sketbht, a.tglkirim, a.istatus, a.remark
                                            FROM i_personnelaction c
                                            LEFT JOIN t_berkasbht a ON c.empno=a.empno                
                                            WHERE c.patype='Terminate Employee' AND (c.istatus='Processed' OR c.istatus='Approved' OR c.istatus='Prepared' ) 
                                            AND YEAR(c.effdate)='$tahun'";
                                    $hasil1=  mysql_query($sql);

                                    while($rsa=  mysql_fetch_object($hasil1)){
                                    $nomor++;
                                    $empno=$rsa->empno;
                            ?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$nomor";  ?></td>
                                            
                                            <?php echo'<td>'.$rsa->empno.'</td>'; echo '<input type="hidden" id="txtempno[]" name="txtempno[]" value="'.$rsa->empno.'" /> '; ?>
                                            <?php echo'<td>'.$rsa->Nama.'</td>';  ?>
                                            <?php echo'<td>'.$rsa->curpostitle.'</td>';  ?>
                                            <?php echo'<td>'.$rsa->orgname.'</td>';  ?>
                                            <?php echo'<td>'.$rsa->curworkloc.'</td>';  ?>
                                            
                                                <?php 
                                                    $srtresign=$rsa->srtresign;
                                                    if($srtresign==''){
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' value='Y' /></td> ";  
                                                    }
                                                    else {
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' checked='true' value='Y'  /></td> ";  
                                                       // echo '<td align="center">'.$rsa->srtresign.'</td>';
                                                       // echo '<input type="hidden" id="cksrtresign[]" name="cksrtresign[]" value="'.$rsa->srtresign.'" /> ';
                                                    }
                                                ?>
                                          
                                                <?php 
                                                    $tglterimasrt=$rsa->tglterimasrt;
                                                    if($tglterimasrt==''){
                                                        echo'<td align="center"><input type="text" id="txttglsrtresign[]" name="txttglsrtresign[]" size="10" value=""> </td>';  
                                                    }
                                                    else {
                                                        echo '<td align="center">'.$rsa->tglterimasrt.'</td>';
                                                        echo '<input type="hidden" id="txttglsrtresign[]" name="txttglsrtresign[]" value="'.$rsa->tglterimasrt.'" /> ';
                                                    }
                                                ?>
                                            
                                                <?php 
                                                $kphk=$rsa->kphk;
                                                if($kphk==''){
                                                        echo"<td align='center'><input type='checkbox' id='txtkphk[]' name='txtkphk[]' value='Y' /></td> ";  
                                                    }
                                                    else {
                                                       // echo '<td align="center">'.$rsa->kphk.'</td>';
                                                         echo"<td align='center'><input type='checkbox' id='txtkphk[]' name='txtkphk[]' checked='true' value='Y' /></td> ";  
                                                    }
                                               
                                                ?>
                                            
                                                <?php 
                                                $klksrhterima=$rsa->klksrhterima;
                                                if($klksrhterima==''){
                                                        echo'<td align="center"><input type="checkbox" id="txtklksrhterima[]" name="txtklksrhterima[]" value="Y" /> </td>';  
                                                    }
                                                    else {
                                                       // echo '<td align="center">'.$rsa->klksrhterima.'</td>';
                                                        echo"<td align='center'><input type='checkbox' id='txtklksrhterima[]' name='txtklksrhterima[]' checked='true' value='Y' /></td> ";  
                                                    }
                                                
                                                ?>
                                           
                                            
                                                 <?php 
                                                    $tglterimaklk=$rsa->tglterimaklk;
                                                    if($tglterimaklk==''){
                                                        echo"<td align='center'><input type='text' id='txttglterimaklk[]' name='txttglterimaklk[]' size='10' value='' /></td>";  
                                                    }
                                                    else {
                                                        echo '<td align="center">'.$rsa->tglterimaklk.'</td>';
                                                        echo '<input type="hidden" id="txttglterimaklk[]" name="txttglterimaklk[]" value="'.$rsa->tglterimaklk.'" /> ';
                                                    }
                                                ?>
                                                       
                                           
                                                <?php 
                                                    $urlberkas=$rsa->urlberkas;
                                                    if($urlberkas==''){
                                                        echo"<td><input type='text' id='txturl[]' name='txturl[]' /></td> ";  
                                                    }
                                                    else {
                                                        echo '<td>'.$rsa->urlberkas.'</td>';
                                                        echo '<input type="hidden" id="txturl[]" name="txturl[]" value="'.$rsa->urlberkas.'" /> ';
                                                    }
                                                 
                                            
                                            
                                            
                                            
                                           
                                            
                                           echo '<td align="center">
                                                    <input type="checkbox" name="item[]" id="item[]" value="'.$rsa->empno.'" />
                                                 </td>';  
                                            ?>  
                                        
                                        </tr>

<?php }
?>                                 
                                    </tbody>
                                
                                </table>
                                    <?php echo "</form>"; ?>
                            </div>
                            <!-- /.table-responsive -->
                        </div> 
                        <!-- /.panel-body -->
                    </div>
              
            
            </div><!-- /.row -->
        </section><!-- /.content -->
           
 



      </div>
      
      <?php } ?>