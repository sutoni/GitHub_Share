<?php
include "config/conn.php";

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";

}
else{
    
?>



<html>
    <head>


        <!-- Latest compiled and minified JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
    <?php
   include "config/conn.php";
				$loguser 	= $_SESSION['username'];
				$CARIUSER="SELECT username	FROM user	
						  WHERE username='$loguser'
							";
				$hasilcari=mysql_query($CARIUSER);
		
				
				while($rec1=mysql_fetch_array($hasilcari))
				{
						$jabatan=$rec1['username']; 
						//$supname=$rec1[supname];
                                                }
				
				 
				if($jabatan=='admin'){
							?>
						<div class="panel panel-default">
					<div class="panel-heading">
						Searching
					</div>
                                                    
                                                    
					 <div class="panel-body">
								<form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
							<table class="table">
							<tr><td>Employee No</td><td>Employee Name</td><td>Org Name</td><td>Position Title</td></tr>
							   <tr>   
								<td><input type="text" name="txtempno"></td>
								<td><input type="text" name="txtempname"></td>
								<td><input type="text" name="txtorgname"></td>
								<td><input type="text" name="txtpostitle"></td>
							 
							 

								
							   <td><input type="submit" name="search" value="Cari"></td>
							   </tr>   
							   </table>

							</form>
						</div>
					</div>	
						<form name="form_data" method="post"  action="?module=aksi_vendor&act=input">
			<div class="panel panel-default">
					<div class="panel-heading">
                                            Overview Personnel Action Karyawan Berhenti &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                           
                                             
					</div>
					 <div class="panel-body">
                                             <table class="table table-hover">
                                                 <tr>
                                                     <td>No</td>
                                                     <td>Employee No</td>
                                                     <td>Employee Name</td>
                                                     <td>Join Date</td>
                                                     <td>Effective Date</td>
                                                     <td>Position Title</td>
                                                     <td>Org Name</td>
                                                     <td>Comp Office</td>
                                                     <td>Atasan</td>
                                                     <td>Termination Type</td>
                                                     <td>Termination Type Group</td>
                                                 </tr>
                                                 
                                                 
                                            
												
								<?php
										include "config/conn.php";
										

										if (isset($_POST['search']))
										{
											$txtempno 		= $_POST['txtempno'];
											$txtempname 		= $_POST['txtempname'];
											$txtorgname 		= $_POST['txtorgname'];										
											$txtpostitle  		= $_POST['txtpostitle'];											
											
											
											
										   
											if (trim($txtempno)<>''){
											 $txtempno = " (empno like '%$txtempno%')";}
											 else { $txtempno = " 1=1 "; } 
											 
											if (trim($txtempname)<>''){
											 $txtempname = " and (empname like '%$txtempname%')";}
											 else { $txtempname = " and 1=1 "; }  
											 
											 if (trim($txtorgname)<>''){
											 $txtorgname = " and (orgname like '%$txtorgname%')";}
											 else { $txtorgname = " and 1=1 "; }  
											
											if (trim($txtpostitle)<>''){
											 $txtpostitle = " and (curpostitle like '%$txtpostitle%')";}
											 else { $txtpostitle = " and 1=1 "; }  	 
											 
										
											
											   
											$bagianWhere = $txtempno.$txtempname.$txtorgname.$txtpostitle;
											
											  $SQL="SELECT  empno, empname, joindate2, effdate, curworkloc,patype,
                                                                                                termtype, termtypegroup, termstatus, curpostitle,curspvname, orgname,termremark
                                                                                                FROM i_personnelaction
                                                                                                        WHERE patype='Terminate Employee' AND (istatus='Processed' OR istatus='Approved' OR istatus='Prepared') AND
                                                                                                        ".$bagianWhere
													;
											$hasil1="$SQL order by  orgname ";		
											$hasil = mysql_query($hasil1);
                                                                                        
                                                                                   
											$jumlah = mysql_num_rows($hasil);
											
											$year=date("Y");
											$month=date("m");
											$day=date("d");
												$today=$year.'-'.$month.'-'.$day;
                                                                                                
                                                                                             
								   if ($jumlah > 0) {
										?>
										Total <?php echo $jumlah;  ?> Data Yang Sesuai. <a href="../dev_sistem/modul/mod_eperformance/laporan_excel_1.php?cari=<?php echo urlencode($bagianWhere);?>"></a> 	
										<?php  	
										while ($res=mysql_fetch_array($hasil))
										{
                                                                                        //$empno1=$res->empno;
                                                                                        
											
                                                                                        $no1++;
												echo "<tr>
												<td align=center>$no1</td>";
												echo"<td align=center><a href='?module=inExitinterview&id=$res[empno]'>$res[empno]</a></td>";
												echo"<td align=center>$res[empname]</td>";										
												echo"<td align=center>$res[joindate2]</td>";
                                                                                                echo"<td align=center>$res[effdate]</td>";
                                                                                                echo"<td align=center>$res[curpostitle]</td>";
                                                                                                echo"<td align=center>$res[orgname]</td>";
                                                                                                echo"<td align=center>$res[curworkloc]</td>";
                                                                                                echo"<td align=center>$res[curspvname]</td>";
                                                                                                echo"<td align=center>$res[termtype]</td>";
                                                                                                echo"<td align=center>$res[termtypegroup]</td>";
                                                                                                
                                                                                                
                                                                                                
											 echo" </tr>
											  ";
										}
									
										}
										}
			?>
						 </table>

					</div>
				</div>	
    
</body>
</html>

<?php
}}
?>