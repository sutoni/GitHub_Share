<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
              
              Dashboard Exit Interview - <?php $unit=$_POST[txtunit]; echo "$unit"; ?> </h1> 
          
         
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Dashboard</a></li>
            <li class="active">Exit Interview</li>
          </ol>
        </section>
        
         <!-- /.col-lg-12 -->
                <br>
                &nbsp;&nbsp;&nbsp; 
                <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myUnit">By Unit</button>
                <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myOrgname">By Orgname</button>              
               <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myPosition" >By Position</button>
               <label class="pull-right">
                    <?php
                include "config/conn.php";
                $tahun = $_POST[txttahununit];
                $sql4= "SELECT COUNT(a.empno)as jumlah2 FROM t_hs_exitinterview a
                        INNER JOIN i_personnelaction b ON a.empno=b.empno
                        INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                        WHERE b.patype='Terminate Employee' AND
                        (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared')
                        AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  ";
                $hasil=mysql_query($sql4);
                WHILE($rsa=mysql_fetch_array($hasil)){
                    $jumlahnya=$rsa['jumlah2'];
                }
                
                $jmltotal="SELECT COUNT(b.empno)AS total 
                            FROM i_personnelaction b 
                            INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                            INNER JOIN position_mapping d ON b.curposid=d.idposition
                            WHERE b.patype='Terminate Employee' AND 
                            (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) AND b.termtype !='Failed Probation' AND b.termtype !='End Of Contract'
                            AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  ";
                 $hasil2=mysql_query($jmltotal);
                 $rs2=mysql_fetch_array($hasil2);
                 $totalresign=$rs2['total'];
                echo "Populasi Mengisi Form adalah : $jumlahnya dari $totalresign";
                ?>       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </label>         
                
                <br><br>
            <!-- /.row -->  
            
            <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Latar Belakang</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Alasan Berhenti</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $tahun=$_POST[txttahununit];
                                        $unit=$_POST[txtunit];
                                        $eduSql="SELECT a.alasankeluar, COUNT(a.empno)AS jmlalasan
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.alasankeluar";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jmlalasan'];
                                            $sql="  SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jmlalasan]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[alasankeluar]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Status pekerjaan ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $no=1;
                                            $sqlmale=" SELECT a.sdhkerja, COUNT(a.empno)AS jml
                                                        FROM t_hs_exitinterview a
                                                        INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                        INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                        WHERE b.patype='Terminate Employee' AND 
                                                        (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                        AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                        GROUP BY a.sdhkerja";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jml'];
                                                $sqlmale="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['total'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rmale[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[sdhkerja]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        
                        <br>
                            
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <!-- Raw Data Applicant Submission -->
               <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Kompensasi Benefit </h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Sistem penggajian DXM cukup bersaing dibandingkan dengan farmasi lain ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.kombensatu, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.kombensatu";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[kombensatu]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">DXM telah memberikan benefit yang bagus bagi karyawan-karyawannya ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.kombendua, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.kombendua
                                                ";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[kombendua]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">DXM telah memberikan fasilitas kerja yang memadai ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.kombentiga, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.kombentiga";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[kombentiga]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                            
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
         
          <!-- Existing -->
          <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Pengembangan Karyawan </h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Mendapat Induksi ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devsatuind, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.devsatuind";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya1=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya1"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devsatuind]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Mendapat Training ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devsatutrng, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.devsatutrng";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devsatutrng]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Mendapat Penilaian Kinerja ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devsatukinerja, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.devsatukinerja";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devsatukinerja]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Melakukan Self Learning ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devsatuselflearning, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.devsatuselflearning";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devsatuselflearning]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>                
                              
                              <!-- Confirm Orientation -->
                              <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Diberikan Proyek/Penugasan ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devsatuproyek, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.devsatuproyek";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devsatuproyek]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                              <!-- Confirm Probation -->
                            <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Mendapatkan Coaching ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devsatucoaching, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit'  
                                                GROUP BY a.devsatucoaching";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devsatucoaching]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                            <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Pengembangan lebih membuat paham ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devduamemahami, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.devduamemahami";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devduamemahami]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                            <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Pengembangan lebih membuat siap ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.devduapersiapan, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.devduapersiapan";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                                $jmlpa=$rspa['jml'];
                                                $sqljmlpa="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                                $hasilsqlpa=  mysql_query($sqljmlpa);
                                                $rd=mysql_fetch_array($hasilsqlpa);
                                                $persennya=round(($jmlpa/$rd['total'])*100,2);

                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <td ><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$jmlpa";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[devduapersiapan]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          
          <!-- Turnover -->
          <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Lingkungan Kerja</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                        <!-- Termination Type -->
                        
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Mendapatkan feedback kinerja ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.lingsatu, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.lingsatu";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[lingsatu]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                    </TBODY>
                        <!--  --> 
                        <BR>
                        <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Komunikasi dengan Manager ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.lingdua, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.lingdua";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[lingdua]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        <br>
                        <!-- -->
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Komunikasi dengan Atasan</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.lingtiga, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.lingtiga";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[lingtiga]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Komunikasi dengan rekan kerja</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.lingempat, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.lingempat";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[lingempat]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Komunikasi dengan BU lain </th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.linglima, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.linglima";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[linglima]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          <!-- Umum -->
          
          <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Umum</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                        <!-- Termination Type -->
                        
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">DXM merupakan tempat yang baik ?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.umsatu, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.umsatu";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[umsatu]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                    </TBODY>
                        <!--  --> 
                        <BR>
                        <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Merasa puas bekerja di DXM?</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $eduSql="SELECT a.umdua, COUNT(a.empno)AS jml
                                                FROM t_hs_exitinterview a
                                                INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                WHERE b.patype='Terminate Employee' AND 
                                                (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' 
                                                GROUP BY a.umdua";
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $jml=$rs['jml'];
                                            $sql="SELECT COUNT(a.empno)AS total 
                                                    FROM t_hs_exitinterview a
                                                    INNER JOIN i_personnelaction b ON a.empno=b.empno 
                                                    INNER JOIN `organization_mapping` c ON b.orgcode=c.orgcode
                                                    WHERE b.patype='Terminate Employee' AND 
                                                    (b.istatus='Processed' OR b.istatus='Approved' OR b.istatus='Prepared' ) 
                                                    AND YEAR(b.effdate)='$tahun' AND c.unit ='$unit' ";
                                            $hasilsql=  mysql_query($sql);
                                            $rd=  mysql_fetch_array($hasilsql);
                                            $persennya=round(($jml/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#6495ED"/></td>
                                                  <td align="center"><i class="fa fa-arrow-up text-center"></i><?php ?></td>
                                                  <td align="center"><?php echo "$rs[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rs[umdua]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        <br>
                        <!-- -->
                           
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <!-- Modal -->
                <div id="myUnit" class="modal fade" role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal by Unit-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Report by Unit</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewunit">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'><a href='?module=rec_budget&act=budgetperiode'>$rsd[tahun]</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   
                                     
                                            
                                        </form>
                                      
                            
                           
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  
                  </div>
                </div>
                       <!--  -->
                  <!-- Modal Position -->
                  <div id="myPosition" class="modal fade "  role="dialog">
                  <div class="modal-dialog">

                    
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Report by Position</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewposition">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'>$rsd[tahun]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   <br><br>
                                                &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                                            <label>Position Level :</label>
                                            <select id="txtposlevel" name="txtposlevel" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT poslevel FROM `position_mapping` GROUP BY poslevel";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[poslevel]'>$rsd[poslevel]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>  
                                            
                                        </form>
                                      
                            
                           
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  
                  </div>
                </div>
                    
                    <!-- End Modal Position -->
                    
        <!-- jQuery 2.1.3 -->
    <script src="../../plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='../../plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- jQuery Knob -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    

    <!-- page script -->
    
