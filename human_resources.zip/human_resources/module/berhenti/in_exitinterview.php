<?php
include "config/conn.php";

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";

}
else{
    
    
?>
<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap.min.js"></script>
<link rel="stylesheet" href="bootstrap-theme.min.css">
<link rel="stylesheet" href="bootstrap.min.css">

<?php

switch($_GET['id']){ default:?> 
            <section class="content-header ">
                    <ol class="breadcrumb  ">
                    <li><a href="?module=home"><i class="fa fa-home"></i> Home</a></li>
                    <li><a href="#">Exit Document</a></li>
                    <li><a href="#">Karyawan Berhenti</a></li>
                    <li class="active">Exit Interview</li>
                </ol>
            </section>
<br><br>
            <div class="panel panel-default">
                <ol class="breadcrumb  ">
                    <li> Exit Kuisoner </li>
                </ol>
                
                <div class="panel-body">
                    <form class="form-inline">
                        <?php
                                $id=$_GET['id'];
                                include 'config/conn.php';
                                $cari="SELECT empno,joindate2, empname, curpostitle, orgname FROM i_personnelaction WHERE empno='$_GET[id]'";
                                $hasil = mysql_query($cari);
                                
                                $rescari=mysql_fetch_array($hasil);
                                
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['empname'];
                                    $currentposition=$rescari['curpostitle'];
                                    $joindate =$rescari['joindate2'];
                                    $currentorgname=$rescari['orgname'];
                                
                        ?>
                        <ul>
                    <div class="form-group">
                        <label control-label > Employee No &nbsp;</label> <input type="text" size="15" class="form-control"  name="txtempno" id="txtempno" value="<?php echo "$empno"; ?>" disabled>
                        <a href="?module=caribht" size="1" class="btn btn-default active" role="button">...</a>
                       
                        <label  control-label> Employee Name &nbsp;&nbsp;</label> <input type="text" size="40" class="form-control" name="txtname" id="txtname" value="<?php echo "$empname"; ?>" disabled>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <label  control-label> Join Date &nbsp;</label> <input type="text" size="10" class="form-control" name="txtname" id="txtname" value="<?php echo "$joindate"; ?>" disabled>
                        <p></p>
                    </div>
                    <div class="form-group">
                        <label control-label > Position Title &nbsp;</label> <input type="text" size="45" class="form-control"  name="txtempno" id="txtempno" value="<?php echo "$currentposition"; ?>" disabled>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <label  control-label> Org Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                        <input type="text" size="80" class="form-control" name="txtname" id="txtname" value="<?php echo "$currentorgname"; ?>" disabled>
                        
                    </div>    
                        </ul>    
                     </form>   
                </div>
            </div>   
             <div class="panel panel-default">    
                <form  method="POST" ACTION="?module=aksiExitinterview&act=input&id=<?php echo$id;?>"  class="form-horizontal"  role="form">
                <div class="panel-heading">
		I. Latar Belakang
                </div>
                    <div class="panel-body">
  
			
                            <div class="form-group">
                            <div class="col-sm-offset-0.1 ">
                                <label control-label><ul>1. Faktor penyebab Karyawan mengundurkan diri</ul></label>
                            <br>
                            </div>
                            </div>
                           <div class="form-group">
                            <input type="hidden" size="15" class="form-control"  name="txtempno" id="txtempno" value="<?php echo "$empno"; ?>" disabled>
                              
                                    
                                 <ul>   <select name="txtalasan" id="txtalasan" class="form-control col-sm-2" value="SELECT">
                                    <option value="">Pilih Jawaban</option>
							<?php  
                                                        include 'config/koneksi.php';
									$carihrbp="SELECT alasanbht FROM t_hs_bhtalasan";
			
									$hasil=mysql_query($carihrbp);
									WHILE($rec1=mysql_fetch_array($hasil))
									{
										$nomer1;
										$nama_hrbp=$rec1[alasanbht];
                                                                                ?>
                                    <option value="<?php echo "$nama_hrbp";  ?>"><?php echo $nama_hrbp; ?></option>
                                                                                <?php
									}
							?>
                                    </select>
                                  
                                        <input type="text" class="form-control col-sm-7" name="txtjawaban1" id="txtjawaban1" placeholder="................................................................................................................................">	
                                     
                                 </ul>
                            
                           </div>
                               <div class="form-group">
                                     <div class="col-sm-offset-0 ">
                                         <label control-label ><ul>2. Mengundurkan diri dengan status pekerjaan ?</ul></label>
                                     </div>
                               </div>
                                        <div class="form-group">
                                       


                                            <ul><select name="txtbelum" id="txtbelum"  class="form-control col-sm-2" >
                                                <option>Pilih Jawaban</option>
                                                           <option value="Belum mendapat kerja">Belum</option>
                                                           <option value="Sudah mendapat kerja">Sudah</option>             
                                                </select>

                                                    <input type="text" class="form-control col-sm-7" name="txtjawaban2" id="txtjawaban2" placeholder="................................................................................................................................">	
                                            </ul>       
                                                        
                                        
                                       </div>
                    </div>
                
                <div class="panel-heading">
		II. Kompensasi Benefit
                </div>
                       <ul><label>1. Menurut Saya, sistem penggajian DXM cukup bersaing dibandingkan dengan farmasi lain ...</label></ul>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                              <input type="radio" aria-label="..." name="rbkom1" id="rbkom1" value="Y"> YA <input type="radio" aria-label="Y" name="rbkom1" id="rbkom1" value="T"> TIDAK
                          </span>
                          <input type="text" name="txtkomben1" id="txtkomben1" class="form-control" aria-label="..." placeholder="................................................................................................................................">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
              </div><!-- /.row -->
              <ul><label>2. Menurut Saya, DXM telah memberikan benefit yang bagus bagi karyawan-karyawannya lain... </label></ul>
              <div class="row">
                  <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                              <input type="radio" aria-label="..." name="rbkom2" id="rbkom2" value="Y"> YA <input type="radio" aria-label="Y" name="rbkom2" id="rbkom2" > TIDAK
                          </span>
                          <input type="text" class="form-control"  name="txtrbkom2" id="txtrbkom2" aria-label="..." placeholder="................................................................................................................................">
                        </div><!-- /input-group -->
                      </div><!-- /.col-lg-6 -->
                     </ul>
              </div><!-- /.row -->
              
               <ul><label>3. Menurut Saya, DXM telah memberikan fasilitas kerja yang memadai ...</label></ul>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbkom3" id="rbkom3"  value="Y"> YA <input type="radio" name="rbkom3" id="rbkom3"  aria-label="T" > TIDAK
                          </span>
                          <input type="text" class="form-control" name="txtrbkom3" id="txtrbkom3" aria-label="..." placeholder="................................................................................................................................">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
              </div><!-- /.row -->
              
              
                <div class="panel-heading">
		III. Pengembangan Karyawan
                </div>
                <ul><label>1. Selama Saya di DXM, pengembangan yang saya dapat adalah : ...</label></ul>    
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpeng1" id="rbpeng1"value="Y"> YA <input type="radio" name="rbpeng1" id="rbpeng1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Induksi Karyawan" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpeng2" id="rbpeng2" value="Y"> YA <input type="radio" name="rbpeng2" id="rbpeng2" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Self Learning (membaca,knowledge sharing, dll)" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                    <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpeng3" id="rbpeng3"  value="Y"> YA <input type="radio" name="rbpeng3" id="rbpeng3"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Training" disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpeng4" id="rbpeng4"  value="Y"> YA <input type="radio" name="rbpeng4" id="rbpeng4"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Proyek / Penugasan lain" disabled="">
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                    
                     <!-- baris ke tiga -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpeng5" id="rbpeng5"  value="Y"> YA <input type="radio" name="rbpeng5" id="rbpeng5"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Pengukuran Kinerja" disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpeng6" id="rbpeng6"  value="Y"> YA <input type="radio" name="rbpeng6" id="rbpeng6"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Coaching / Counseling" disabled="">
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                     
                      <!-- baris ke empat -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpeng7" id="rbpeng7"  value="Y"> YA <input type="radio" name="rbpeng7" id="rbpeng7"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" name="txtrbpeng7" id="txtrbpeng7" aria-label="..." placeholder="Lainnya (sebutkan) ......................................................................................." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                      <!-- baris ke Lima -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpeng8" id="rbpeng8"  value="Y"> YA <input type="radio" name="rbpeng8" id="rbpeng8"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Menurut Saya, pengembangan-pengembangan tersebut membuat saya mememahami perusahaan dan pekerjaan." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                      <!-- baris ke enam -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpeng9" id="rbpeng9"  value="Y"> YA <input type="radio" name="rbpeng9" id="rbpeng9"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Menurut Saya, pengembangan tersebut mempersiapkan saya dalam melaksanakan tugas dengan baik." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
              </div><!-- /.row -->
              
              
                
                <div class="panel-heading">
		IV. Lingkungan Kerja
                </div>
              <p></p>
                    <div class="row">
                          <!-- baris ke empat -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbling1" id="rbling1"  value="Y"> YA <input type="radio" name="rbling1" id="rbling1" aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Saya memperoleh umpan balik secara periodik mengenai kinerja Saya, baik secara lisan maupun tulisan dari atasan." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                      <!-- baris ke Lima -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbling2" id="rbling2"  value="Y"> YA <input type="radio" name="rbling2" id="rbling2" aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Saya memiliki komunikasi yang baik dengan Manager Senior." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                      <!-- baris ke enam -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbling3" id="rbling3" value="Y"> YA <input type="radio" name="rbling3" id="rbling3" aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Saya memiliki komunikasi yang baik dengan Atasan." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                      <!-- baris ke tujuh -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbling4" id="rbling4" value="Y"> YA <input type="radio" name="rbling4" id="rbling4" aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Saya memiliki komunikasi yang baik dengan Rekan Kerja." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                      <!-- baris ke delapan -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbling5" id="rbling5" value="Y"> YA <input type="radio" name="rbling5" id="rbling5" aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Saya memiliki komunikasi yang baik dengan Bisnis Unit lain." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                     </div><!-- /.row -->
                     
                <div class="panel-heading">                    
		V. Umum
                </div>
                
                       <p></p>
                    <div class="row">
                          <!-- baris ke empat -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbum1" id="rbum1" value="Y"> YA <input type="radio" name="rbum1" id="rbum1" aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Saya berpendapat bahwa DXM merupakan tempat yang baik dan layak untuk bekerja." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                      <!-- baris ke Lima -->
                     
                     <ul>
                        <div class="col-lg-12">
                                <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbum2" id="rbum2" value="Y"> YA <input type="radio" name="rbum2" id="rbum2" aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Secara umum Saya merasa puas bekerja di DXM." >


                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                      
                     
                     </div><!-- /.row -->
                   
                     <div class="panel-heading">                    
                        VI. Catatan HRD
                    </div>
                     <ul>
                        <div class="form-group">
                            <label>
                                Comment :
                            </label>
                            <textarea class="form-control col-sm-3" name="txtcathrd" id="txtcathrd" rows="3" cols="3" id="txtcatatanhrd" name="txtcatatanhrd"></textarea>
                        </div>
                     </ul>
                     <p align="center"><br>
                         <input type="submit" name="submit" value="Submit" width="25" height="25" colspan=0 > 
                </form>  
            </div>
      <?php
    }//tag akhir switch
    ?>  



<?php } ?>