<?php

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{
   
    ?>
        
      
<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript">
        $(document).ready(function() {
    var t = $('#example1').DataTable();
    var counter = 1;
 
    $('#addRow').on( 'click', function () {
        t.row.add( [
            counter +'.1',
            counter +'.2',
            counter +'.3',
            counter +'.4',
            counter +'.5'
        ] ).draw( false );
 
        counter++;
    } );
 
    // Automatically add a first row of data
    $('#addRow').click();
} );
    </script>
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
         
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Development</a></li>
            <li><a href="?module=view_performance">Performance Management</a></li>
            <li class="active">Performance Monitoring</li>
          </ol>
        </section>


   
            <br><br>  
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                            
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Performance Monitoring</h3>
                                  <div class="pull-right hidden-xs">
                                       
                                      
                                      <a href=""><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                           <button type="submit" value="addRow" id="addRow" name="addRow" class="fa fa-plus"></button>
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                   <?php 
                                   echo "<form name='form_data' id='form_data' method='POST' action='?module=simpan&act=ttb_resign' >";
                                           ?>
                                    <button type="submit" value="save" id="save" name="save" class="fa fa-save"></button>
                                <table id="example1" class="table table-bordered table-striped">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center" rowspan="2">No</th>
                                            <th class="text-center" rowspan="2">Level Strategi</th>
                                            <th class="text-center" rowspan="2">Perspektif</th>
                                            <th class="text-center" rowspan="2">KPI</th>
                                            <th class="text-center" rowspan="2">Type Periode</th>
                                            <th class="text-center" rowspan="2">Bobot</th>
                                            <th class="text-center" rowspan="2">Target</th>
                                            <th class="text-center" colspan="12">Achievement</th>
                                            <th class="text-center" rowspan="2">Result</th>
                                            <th class="text-center" rowspan="2">%</th>
                                            <th class="text-center" rowspan="2">
                                                <input type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>
                                                Aksi</th>

                                        </tr>
                                        <tr>
                                            <th class="text-center" >Jan</th>
                                            <th class="text-center" >Feb</th>
                                            <th class="text-center" >Mar</th>
                                            <th class="text-center" >Apr</th>
                                            <th class="text-center" >Mei</th>
                                            <th class="text-center" >Jun</th>
                                            <th class="text-center" >Jul</th>
                                            <th class="text-center" >Ags</th>
                                            <th class="text-center" >Sep</th>
                                            <th class="text-center" >Okt</th>
                                            <th class="text-center" >Nov</th>
                                            <th class="text-center" >Des</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                   
                            <?php
                                
                            include "config/conn.php";
                            $no=1;
                            $tahun = date("Y");

                                    $sql="SELECT a.idbaru, d.typeperiodic, b.name AS level_strategic, c.name AS persepektif, a.goaldesc,a.bobot,a.target, 
                                        d.jan, d.feb, d.mar, d.apr, d.mei, d.jun, d.jul, d.ags, d.sep, d.okt, d.nov, d.des, 
                                        (d.jan + d.feb + d.mar + d.apr + d.mei + d.jun + d.jul + d.ags + d.sep + d.okt + d.nov + d.des)as total,
                                        (((d.jan + d.feb + d.mar + d.apr + d.mei + d.jun + d.jul + d.ags + d.sep + d.okt + d.nov + d.des)/(a.target))*100)AS persen
                                        FROM strategic_template a
                                        INNER JOIN strategi_bsc b ON a.idstrategi=b.id
                                        INNER JOIN perspektif_bsc c ON a.idperspektif=c.id
                                        LEFT JOIN persepective_indexresult d ON a.idbaru=d.idindex
                                        WHERE SUBSTR(a.idbaru,1,4)='$tahun'";
                                    $hasil1=  mysql_query($sql);

                                    while($rsa=  mysql_fetch_array($hasil1)){
                                    $nomor++;
                                    $empno=$rsa->empno;
                            ?>       <tr class="odd gradeX">
                                            <td><?php echo"$nomor";  ?></td>
                                            <td><?php echo"$rsa[level_strategic]";  ?></td>
                                            <td><?php echo"$rsa[persepektif]";  ?></td>
                                            <td><?php echo"$rsa[goaldesc]";  ?></td>
                                            <td><?php echo"$rsa[typeperiodic]";  ?></td>
                                            <td><?php echo"$rsa[bobot]";  ?></td>
                                            <td><?php echo"$rsa[target]";  ?></td>
                                            <td><?php echo"$rsa[jan]";  ?></td>
                                            <td><?php echo"$rsa[feb]";  ?></td>
                                            <td><?php echo"$rsa[mar]";  ?></td>
                                            
                                           
                                            <?php echo'<td align="center">'.$rsa->apr.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->mei.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->jun.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->jul.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->ags.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->sep.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->okt.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->nov.'</td>';  ?>
                                            <?php echo'<td align="center">'.$rsa->des.'</td>';  ?>
                                            
                                            <?php 
                                                 
                                                $total=$rsa['total'];
                                                $target=$rsa['target'];
                                                $jan=$rsa['jan'];
                                                $feb=$rsa['feb'];
                                                $mar=$rsa['mar'];
                                                $apr=$rsa['apr'];
                                                $mei=$rsa['mei'];
                                                $jun=$rsa['jun'];
                                                $jul=$rsa['jul'];
                                                $ags=$rsa['ags'];
                                                $sep=$rsa['sep'];
                                                $okt=$rsa['okt'];
                                                $nov=$rsa['nov'];
                                                $des=$rsa['des'];
                                               $jumlahhasil=$jan+$feb+$mar+$apr+$mei+$jun+$jul+$ags+$sep+$okt+$nov+$des; 
                                               $persentaseacv=round($rsa['persen'],2);
                                            ?>
                                               <td align="center"><?php echo"$jumlahhasil";  ?></td>
                                               <td align="center"><?php echo" $persentaseacv%";  ?></td>
                                            
                                            
                                           
                                             <?php
                                           echo '<td align="center">
                                                    <input type="checkbox" name="item[]" id="item[]" value="'.$rsa->empno.'" />
                                                 </td>';  
                                            ?>  
                                        
                                        </tr>

<?php }
?>                                 
                                    </tbody>
                                
                                </table>
                                    <?php echo "</form>"; ?>
                            </div>
                            <!-- /.table-responsive -->
                        </div> 
                        <!-- /.panel-body -->
                    </div>
              
            
            </div><!-- /.row -->
        </section><!-- /.content -->
           
 



      </div>
      
      <?php } ?>