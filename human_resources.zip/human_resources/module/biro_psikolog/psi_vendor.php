<?php
if($_GET['act']=="input"){
	?>
<br><br>
         <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Basic Konfigurasi</a></li>
                    <li><a href="#">Vendor</a></li>
                    <li class="active">Biro Psikologi</li>
                  </ol>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Input Data Vendor Biro Psikologi
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                    <form method="post" role="form" action="?module=simpan&act=input_vendorpsi">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Nama Vendor</label>
                                            <input class="form-control" placeholder="Nama Vendor Biro Psikolog" name="txtvendormcu" id="txtvendormcu">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Kota</label>
                                            <select class="form-control" name="txtkota" id="txtkota">
                                                        <?php 
                                                              $sql=mysql_query("select * from city");
                                                              while($rs=mysql_fetch_array($sql)){
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                         <div class="form-group">
                                            <label>Alamat</label>
                                            <textarea class="form-control" name="txtalamat" id="txtalamat" rows="3"></textarea>
                                            
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Contact Person</label>
                                            <input class="form-control" placeholder="Contact Person" name="txtkontak" id="txtkontak">
                                        </div>
                                        
                                        <div class="form-group ">
                                            <label>Nomer Rekening</label>
                                            <input class="form-control" placeholder="Nomer Rekening" name="txtnorek" id="txtnorek">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>NPWP</label>
                                            <input class="form-control" placeholder="Nomer NPWP" name="txtnpwp" id="txtnpwp">
                                        </div>
                                    
                                        
                                         <div class="form-group col-lg-5">
                                            <label>Fax</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txtfax" id="txtfax">
                                         </div>
                                        <div class="form-group col-lg-5" colspan="0">
                                            <label>Telpon</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txttelpon" id="txttelpon">
                                        </div>
                                    
                                         <div class="form-group col-lg-5">
                                            <label>HP</label>
                                            <input class="form-control" placeholder="+62813-7209510" name="txthp" id="txthp">
                                        </div>
                                    
                                        
                                         <div class="form-group col-lg-7">
                                            <label>Email</label>
                                            <input class="form-control" placeholder="a@usahadong.com" name="txtemail" id="txtemail">
                                        </div>
                                        
                                    <BR>
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                  <p></p>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        
                                    <br>
                                        <button type="submit" class="btn btn-default col-lg-3">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           <?php } ?>
           
          
             