<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
     
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Overview Position
            
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-building-o"></i> Home</a></li>
            <li><a href="#">Basic Konfigurasi</a></li>
            <li><a href="?module=view_position&act=view_posstruktur">Position</a></li>
            <li class="active">Overview Position</li>
          </ol>
        </section>


                <!-- /.col-lg-12 -->
                <a href="?module=view_position&act=view_posstruktur"><button type="submit" class="btn btn-default">Overview Position Struktur</button></a>
                <a href="?module=view_position&act=view_posclass"><button type="submit" class="btn btn-default"  >Overview Position Class</button></a>
                <a href="?module=view_position&act=view_indarea"><button type="submit" class="btn btn-default"  >Overview Industry Area</button></a>
                <a href="?module=view_position&act=view_jobfam"><button type="submit" class="btn btn-default"  >Overview Job Family</button></a>
                <a href="?module=view_position&act=view_funcarea"><button type="submit" class="btn btn-default"  >Overview Functional Area</button></a>
            <!-- /.row -->          
<br><br>
    <?php
    /*
        Overview Position Struktur
    */
    
if($_GET['act']=="view_posstruktur"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Position Struktur</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_struktur&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center">Pos Id</th>
                                            <th class="text-center">Pos Title</th>
                                            <th class="text-center">Pos Summary</th>
                                            <th class="text-center">PC</th>
                                            <th class="text-center">Direct</th>
                                            <th class="text-center">Job Fam</th>
                                            <th class="text-center">Org Code</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from position_struktur";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id_position]";  ?></td>
                                            <td><?php echo"$rsa[position_title]";  ?></td>
                                            <td><?php echo"$rsa[position_summary]";  ?></td>
                                            <td><?php echo"$rsa[position_class]";  ?></td>
                                            <td><?php echo"$rsa[direct_superior]";  ?></td>
                                            <td><?php echo"$rsa[job_id]";  ?></td>
                                            <td><?php echo"$rsa[organization_code]";  ?></td>
                                            <td><?php echo"$rsa[validfrom]";  ?></td>
                                            <td><?php echo"$rsa[validto]";  ?></td>
                                            
                                            <td class="text-center"><a href="?module=posstruktur&act=edit_posstruktur&id=<?php echo $rsa['id_position'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_posstruktur&id=<?php echo $rsa['id_position'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                           
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">Pos Id</th>
                                            <th class="text-center">Pos Title</th>
                                            <th class="text-center">Pos Summary</th>
                                            <th class="text-center">PC</th>
                                            <th class="text-center">Direct</th>
                                            <th class="text-center">Job Fam</th>
                                            <th class="text-center">Org Code</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
              
            
            </div><!-- /.row -->
        </section><!-- /.content -->
           
  <?php } ?>



    <?php
    /*
        Overview Position Class
    */
if($_GET['act']=="view_posclass"){
	?>
              
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Position Class</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_class&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Position Class</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from position_class";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[posclass]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                            <td class="text-center"><a href="?module=pos_class&act=edit_posclass&id=<?php echo $rsa['posclass'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_posclass&id=<?php echo $rsa['posclass'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    

                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                               <tfoot>
                                        <tr>
                                             <th class="text-center">Position Class</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                   </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>



    <?php
    /*
        Overview Industry Area
    */
if($_GET['act']=="view_indarea"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Position Industry Area</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_Industry&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Industry Name</th>                                            
                                            <th class="text-center">Industry Area Name</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from industry_area";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[industry_name]";  ?></td>
                                            <td><?php echo"$rsa[industry_area_name]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                            <td class="text-center"><a href="?module=pos_industry&act=edit_posindustry&id=<?php echo $rsa['industry_name'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_indarea&id=<?php echo $rsa['industry_name'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    

                                      
                                        </tr>

<?php }
?>
                                    </tbody>
                               <tfoot>
                                        <tr>
                                             <th class="text-center">Industry Name</th>                                            
                                            <th class="text-center">Industry Area Name</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                   </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>

            
 <?php
    /*
        Overview  Job Family
    */
if($_GET['act']=="view_jobfam"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Position Job Family</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_jobfam&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Job Id</th>                                            
                                            <th class="text-center">Job Title</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from job_family";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id_job]";  ?></td>
                                            <td><?php echo"$rsa[job_title]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                            <td class="text-center"><a href="?module=pos_jobfam&act=edit_jobfam&id=<?php echo $rsa['id_job'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_jobfam&id=<?php echo $rsa['id_job'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    

                                       
                                        </tr>

<?php }
?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                             <th class="text-center">Job Id</th>                                            
                                            <th class="text-center">Job Title</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                   </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>

      
 <?php
    /*
        Overview  Functional Area
    */
if($_GET['act']=="view_funcarea"){
	?>
              
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Functional Area</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_areajob&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Id functional area</th>                                                                                        
                                            <th class="text-center">Functional area name</th>                                                                                        
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from functional_area";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id_functarea]";  ?></td>
                                            <td><?php echo"$rsa[func_area]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                            <td class="text-center"><a href="?module=pos_areajob&act=edit_jobfunctarea&id=<?php echo $rsa['id_functarea'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                            <a href="?module=simpan&act=hapus_funcarea&id=<?php echo $rsa['id_functarea'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    

                                       
                                        </tr>

<?php }
?>
                                    </tbody>
                               <tfoot>
                                        <tr>
                                            <th class="text-center">Id functional area</th>                                                                                        
                                            <th class="text-center">Functional area name</th>                                                                                        
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                   </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>

      </div>