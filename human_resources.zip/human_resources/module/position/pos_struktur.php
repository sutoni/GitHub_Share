<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Position
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-building-o"></i> Home</a></li>
            <li><a href="?module=view_position&act=view_jobfam">Position</a></li>
            <li class="active">Position Struktur</li>
          </ol>
        </section>
<?php
if($_GET['act']=="input"){
	?>
         <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Position Struktur</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_struktur&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_postruktur">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-lg-0">Position ID</label>
                                            <input class="form-control" placeholder="Position ID" name="txtposid" id="txtposid">
                                        </div>
                                        <div class="form-group">
                                            <label>Position Title</label>
                                            <input class="form-control" placeholder="Position Title" name="txtpostitle" id="txtpostitle">
                                        </div>
                                         <div class="form-group">
                                            <label>Position Summary</label>
                                            <textarea class="form-control" name="txtpossummary" id="txtpossummary" rows="3"></textarea>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Position Class</label>
                                            <select class="form-control" name="txtposclass" id="txtposclass">
                                                        <?php 
                                                              $sql=mysql_query("select * from position_class ");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs[posclass]'>$rs[posclass]</option>";
                                                                  
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                        
                                    
                                        <div class="form-group">
                                            <label>Direct Superior</label>
                                            
                                            <select class="form-control" name="txtposiddir" id="txtposiddir">
                                                <option value="0"></option>
                                                        <?php 
                                                              $sql=mysql_query("select * from position_struktur");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs[posid]'>$rs[position_title]</option>";
                                                                  
                                                      }
                                                      ?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group ">
                                            <label>Job ID</label>
                                             <select class="form-control" name="txtjobid" id="txtjobid">
                                                        <?php 
                                                              $sql=mysql_query("select * from job_family ");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs[jobid]'>$rs[job_title]</option>";
                                                                  
                                                      }
                                                      ?>
                                            </select>
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Organization Name</label>
                                            
                                            <select class="form-control" name="txtorgcode" id="txtorgcode">
                                                        <?php 
                                                              $sql=mysql_query("select * from organization_struktur ");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs[orgcode]'>$rs[org_name]</option>";
                                                                  
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                    
                                     
                                        
                                    <BR>
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                  <p></p>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        
                                    <br>
                                        <button type="submit" class="btn btn-default col-lg-3">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
           <?php } 
           
if($_GET['act']=="edit_posstruktur"){
    $id=$_GET['id'];
	?>
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Position Struktur</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_struktur&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                <form method="post" role="form" action="?module=simpan&act=edit_posstruktur">
                                    <?php
                                            $sql="SELECT * FROM position_struktur WHERE posid='$id'";
                                            $hasil=  mysql_query($sql);
                                            $rs=  mysql_fetch_array($hasil);
                                    ?>
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-lg-0">Position ID</label>
                                            <input class="form-control" placeholder="Position ID" name="txtposid" id="txtposid" value="<?php echo $rs[posid]; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Position Title</label>
                                            <input class="form-control" placeholder="Position Title" name="txtpostitle" id="txtpostitle" value="<?php echo $rs[position_title]; ?>">
                                        </div>
                                         <div class="form-group">
                                            <label>Position Summary</label>
                                            <textarea class="form-control" name="txtpossummary" id="txtpossummary" rows="3"><?php echo $rs[position_summary]; ?></textarea>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Position Class</label>
                                            <select class="form-control" name="txtposclass" id="txtposclass">
                                                        <?php 
                                                                echo " <option value='$rs[pos_class]'>$rs[pos_class]</option>";
                                                              $sql=mysql_query("select * from position_class ");
                                                              while($rs1=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs1[pos_class]'>$rs1[pos_class]</option>";
                                                                  
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                        
                                    
                                        <div class="form-group">
                                            <label>Direct Superior</label>
                                            
                                            <select class="form-control" name="txtposiddir" id="txtposiddir">
                                                        <?php 
                                                              echo " <option value='$rs[position_superior]'>$rs[position_superior]</option>";  
                                                              $position_superior=$rs[position_superior];
                                                              $sql=mysql_query("select * from position_struktur WHERE posid != '$position_superior' ");
                                                              while($rs2=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs2[posid]'>$rs2[position_title]</option>";
                                                                  
                                                      }
                                                      ?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group ">
                                            <label>Job ID</label>
                                             <select class="form-control" name="txtjobid" id="txtjobid">
                                                        <?php 
                                                              $sql=mysql_query("select * from job_family ");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs[jobid]'>$rs[job_title]</option>";
                                                                  
                                                      }
                                                      ?>
                                            </select>
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Organization Name</label>
                                            
                                            <select class="form-control" name="txtorgcode" id="txtorgcode">
                                                        <?php 
                                                              $sql=mysql_query("select * from organization_struktur ");
                                                              while($rs=mysql_fetch_array($sql)){
                                                                   echo " <option value='$rs[orgcode]'>$rs[org_name]</option>";
                                                                  
                                                      }
                                                      ?>
                                          </select>
                                        </div>
                                    
                                     
                                        
                                    <BR>
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                  <p></p>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        
                                    <br>
                                        <button type="submit" class="btn btn-default col-lg-3">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
           <?php } ?>
      </div>          