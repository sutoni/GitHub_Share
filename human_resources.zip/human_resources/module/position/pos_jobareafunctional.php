<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Position
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-building-o"></i> Home</a></li>
            <li><a href="?module=view_position&act=view_funcarea">Position</a></li>
            <li class="active">Functional Area</li>
          </ol>
        </section>
<?php
if($_GET['act']=="input"){
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Functional Area</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_areajob&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_funcarea">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Id Functional Area</label>
                                            <input class="form-control" placeholder="Functional Area" name="txtfidfuncarea" id="txtfidfuncarea">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Functional Area</label>
                                            <input class="form-control" placeholder="Functional Area" name="txtfuncareaname" id="txtfuncareaname">
                                        </div>
                                     
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
           <?php } ?>
           
           
           
           <?php
if($_GET['act']=="edit_jobfunctarea"){
    $id=$_GET['id'];
	?>
              <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Functional Area</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=pos_areajob&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                <form method="post" role="form" action="?module=simpan&act=edit_funcarea">
                                     <?php
                                        $sql="SELECT * FROM functional_area WHERE id_functarea ='$id'";
                                        $hasil=  mysql_query($sql);
                                        $rs=  mysql_fetch_array($hasil);
                                     ?>
                                <div class="col-lg-6">
                                        
                                         <div class="form-group">
                                            <label>Id Functional Area</label>
                                            <input class="form-control" placeholder="ID Functional Area" name="txtfidfuncarea" id="txtfidfuncarea" value="<?php echo $rs[id_functarea]; ?>">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Functional Area</label>
                                            <input class="form-control" placeholder="Functional Area Name" name="txtfuncareaname" id="txtfuncareaname" value="<?php echo $rs[func_area]; ?>">
                                        </div>
                                     
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rs[keterangan]; ?></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                          </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <?php } ?>
      </div>            