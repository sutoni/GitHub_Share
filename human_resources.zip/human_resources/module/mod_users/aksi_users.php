<?php

include 'config/conn.php';

$module=$_GET[module];
$act=$_GET[act];

// Input user
if ($module=='aksi_user' AND $act=='input'){
  $pass=(md5($_POST['password']));
$masuk="INSERT INTO user(idu,username,
                                 passuser,
                                 level,
                                 id,
                                 blokir,
                                 empno,
                                 nama_lengkap,
                                 email,
                                 id_session) 
	                       VALUES('','$_POST[username]',
                                '$pass',
                                'user',
                                '1',
                                'N',
                                 '$_POST[empno]',
                                '$_POST[nama_lengkap]',
                                '$_POST[email]',
                                '$pass')";
  $hasil1=mysql_query($masuk);
  echo "$masuk"; 

  Print"<b><Center>Terima Kasih data Sudah tersimpan <br></b></center>";
  print"<center><b><a href=?module=userpass>back</a> OR <a href=?module=menu>next</a></b></center>";
  
}

// Update user
elseif ($module=='aksi_user' AND $act=='update'){
  if (empty($_POST[password])) {
    $update1="UPDATE users SET nama_lengkap   	 = '$_POST[nama_lengkap]',
                                  email          = '$_POST[email]',
                                  blokir         = '$_POST[blokir]',  
                                  no_telp        = '$_POST[no_telp]'  
                           WHERE  id_session     = '$_POST[id]'";
	$hasilupdate1=mysql_query($update1);
						   
  }
  // Apabila password diubah
  else{
    $pass=md5($_POST[password]);
    $update2="UPDATE users SET password        = '$pass',
                                 nama_lengkap    = '$_POST[nama_lengkap]',
                                 email           = '$_POST[email]',  
                                 blokir          = '$_POST[blokir]',  
                                 no_telp         = '$_POST[no_telp]'  
                           WHERE id_session      = '$_POST[id]'";
	$hasilupdate2= mysql_query($update2);
  }
  Print"<b><Center>Terima Kasih data Sudah tersimpan <br></b></center>";
  print"<center><b><a href=?module=userpass>back</a> OR <a href=?module=menu>next</a></b></center>";
}



// Update user non administrator
elseif ($module=='aksi_user' AND $act=='update1'){
	$nama=$_POST[nama_lengkap];
  if (empty($_POST[password])) {
    $update1="UPDATE users SET nama_lengkap   	 = '$_POST[nama_lengkap]',
                                  email          = '$_POST[email]',                                  
                                  no_telp        = '$_POST[no_telp]'  
                           WHERE  id_session     = '$_POST[id]'";
	$hasilupdate1=mysql_query($update1);
						   
  }
  // Apabila password diubah
  else{
    $pass=md5($_POST[password]);
    $update2="UPDATE users SET password        = '$pass',
                                 nama_lengkap    = '$_POST[nama_lengkap]',
                                 email           = '$_POST[email]',  
                               
                                 no_telp         = '$_POST[no_telp]'  
                           WHERE id_session      = '$_POST[id]'";
	$hasilupdate2= mysql_query($update2);
	
  }
  Print"<b><Center>Terima Kasih $nama data Sudah tersimpan <br></b></center>";
 
}

?>
