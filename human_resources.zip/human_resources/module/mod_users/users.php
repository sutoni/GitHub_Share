<?php

if (!isset($_SESSION['username']) AND !isset($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{
?>


<html> 
<head><title></title></head>

<body>
<style type="text/css">
body { font: 11px Tahoma, sans-serif; margin: 0; padding: 0; }
table { font: 11px Tahoma, sans-serif; margin: 0; padding: 0; border:0;}
a { color: #3150a9; text-decoration: none; }
#content { padding: 10px; margin: 15px; border: 1px solid #ccc; width: 1210px;}
</style>
<?php
  
switch($_GET[act]){
  // Tampil User
   
  default:
      case "input":
          $id=$_GET['act']; 
      $sesi=$_SESSION['username'];
    if ($_SESSION['username']=='admin'){
      $tampil = mysql_query("SELECT * FROM user ORDER BY username");
      echo "<h2>User</h2>
          <input type=button value='Tambah User' onclick=\"window.location.href='?module=userpass&act=tambahuser';\">";
    }
    else{
      
      echo "<h2>$tampil</h2>";
    }
    
    echo "<table>
          <tr><th>no</th><th>username1</th><th>nama lengkap</th><th>email</th><th>Blokir</th><th>aksi</th></tr>"; 
    $no=1;
    include 'config/conn.php';
    $tampil="SELECT * FROM user ";
    $hasil=mysql_query($tampil);   
    WHILE($r=mysql_fetch_array($hasil)){
       echo "<tr><td>$no</td>";
              echo "<td>$r[username]</td>";
              echo "<td>$r[nama_lengkap]</td>";
              echo "<td><a href=mailto:$r[email]>$r[email]</a></td>";
              echo "<td align=center>$r[blokir]</td>";
              echo "<td><a href=?module=userpass&act=edituser&id=$r[id_session]>Edit</a></td></tr>";
      $no++;
    }
    echo "</table>";
    break;
  
  case "tambahuser":
    if ($_SESSION[username]=='admin'){
    echo "<h2>Tambah User</h2>
          <form method=POST action='?module=aksi_user&act=input'>
          <table>
          <tr><td>Username</td>     <td> : <input type=text name='username'></td></tr>
          <tr><td>Password</td>     <td> : <input type=text name='password'></td></tr>
          <tr><td>Empno</td>     <td> : <input type=text name='empno'> *) </td></tr>
          <tr><td>Nama Lengkap</td> <td> : <input type=text name='nama_lengkap' size=30></td></tr>  
          <tr><td>E-mail</td>       <td> : <input type=text name='email' size=30></td></tr>
          
          <tr><td colspan=2><input type=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    }
    else{
      echo "Anda tidak berhak mengakses halaman ini.";
    }
     break;
    
  case "edituser":
    $edit=mysql_query("SELECT * FROM user WHERE id_session='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    if ($_SESSION['username']=='admin'){
    echo "<h2>Edit User</h2>
          <form method=POST action=?module=aksi_user&act=update>
          <input type=hidden name=id value='$r[id_session]'>
          <table>
          <tr><td>Username</td>     <td> : <input type=text name='username' value='$r[username]' disabled> **)</td></tr>
          <tr><td>Password</td>     <td> : <input type=text name='password'> *) </td></tr>
           <tr><td>Empno</td>     <td> : <input type=text name='empno'> *) </td></tr>
          <tr><td>Nama Lengkap</td> <td> : <input type=text name='nama_lengkap' size=30  value='$r[nama_lengkap]'></td></tr>
          <tr><td>E-mail</td>       <td> : <input type=text name='email' size=30 value='$r[email]'></td></tr>
          ";

    if ($r[blokir]=='N'){
      echo "<tr><td>Blokir</td>     <td> : <input type=radio name='blokir' value='Y'> Y   
                                           <input type=radio name='blokir' value='N' checked> N </td></tr>";
    }
    else{
      echo "<tr><td>Blokir</td>     <td> : <input type=radio name='blokir' value='Y' checked> Y  
                                          <input type=radio name='blokir' value='N'> N </td></tr>";
    }
    
    echo "<tr><td colspan=2>*) Apabila password tidak diubah, dikosongkan saja.<br />
                            **) Username tidak bisa diubah.</td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";     
    }
    else{
    echo "<h2>Edit User</h2>
          <form method=POST action=?module=userpass&act=update>
          <input type=hidden name=id value='$r[id_session]'>
          <input type=hidden name=blokir value='$r[blokir]'>
          <table>
          <tr><td>Username</td>     <td> : <input type=text name='username' value='$r[username]' disabled> **)</td></tr>
          <tr><td>Password</td>     <td> : <input type=text name='password'> *) </td></tr>
          <tr><td>Nama Lengkap</td> <td> : <input type=text name='nama_lengkap' size=30  value='$r[nama_lengkap]'></td></tr>
          <tr><td>E-mail</td>       <td> : <input type=text name='email' size=30 value='$r[email]'></td></tr>
          <tr><td>No.Telp/HP</td>   <td> : <input type=text name='no_telp' size=30 value='$r[no_telp]'></td></tr>";    
    echo "<tr><td colspan=2>*) Apabila password tidak diubah, dikosongkan saja.<br />
                            **) Username tidak bisa diubah.</td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";     
    }
  

?>
<?php
}}
?>