<?php
session_start();
if (empty($_SESSION[username]) AND empty($_SESSION[passuser])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{
?>


<html> 
<head><title></title></head>

<body>
<style type="text/css">
body { font: 11px Tahoma, sans-serif; margin: 0; padding: 0; }
table { font: 11px Tahoma, sans-serif; margin: 0; padding: 0; border:0;}
a { color: #3150a9; text-decoration: none; }
#content { padding: 10px; margin: 15px; border: 1px solid #ccc; width: 1210px;}
</style>
<?php
  
switch($_GET[act]){
  // Tampil User
  default:
    if ($_SESSION[leveluser]!='admin'){
     $_SESSION[namauser];
     $usernya=$_SESSION[namauser];
	 
    $edit="SELECT * FROM users WHERE username='$usernya'";
	$hasil=mysql_query($edit);
    $r=mysql_fetch_array($hasil);

   
    echo "<h2>Edit User </h2>
          <form method=POST action=?module=aksi_user&act=update1>
          <input type=hidden name=id value='$r[id_session]'>
          <table>
          <tr><td>Username</td>     <td> : <input type=text name='username' value='$r[username]' disabled> **)</td></tr>
          <tr><td>Password</td>     <td> : <input type=text name='password'> *) </td></tr>
          <tr><td>Nama Lengkap</td> <td> : <input type=text name='nama_lengkap' size=30  value='$r[nama_lengkap]'></td></tr>
          <tr><td>E-mail</td>       <td> : <input type=text name='email' size=30 value='$r[email]'></td></tr>
          <tr><td>No.Telp/HP</td>   <td> : <input type=text name='no_telp' size=30 value='$r[no_telp]'></td></tr>";

  
    
    echo "<tr><td colspan=2>*) Apabila password tidak diubah, dikosongkan saja.<br />
                            **) Username tidak bisa diubah.</td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";     
    } 
}

?>
<?php
}
?>