
<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
     
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Overview Applicant Info
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_company">Applicant Overview</a></li>
            <li class="active">Applicant Information</li>
          </ol>
        </section>
    
   <br>
          
  
              <?php
    /*
        Overview Company Office Detail
    */
if($_GET['act']=="view_appinfo"){
	?>
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                <!-- <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview Company Category
                        </div>
                         /.panel-heading 
                        <div class="panel-body">
                            <div class="table-responsive">-->
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Applicant Info</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=app_screening"><i class="fa fa-filter text-success"></i></a>&nbsp;&nbsp
                                      <a href="?module=app_widget&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Age</th>
                                            <th class="text-center">Telpon</th>                                            
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Majoring</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Psikotest</th>
                                            <th class="text-center">Interview HR</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Details</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";





$no=1;
	$sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, 
                a.tgllahir, a.hp AS komunikasi, a.email,d.statuspsikotest,
                b.leveledukasi,b.jurusan, c.position, a.status,e.resultstatus
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_psikotest d ON a.applicantid=d.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                LEFT JOIN applicant_interviewhr e ON a.applicantid=e.applicantid
                ORDER BY a.applicantid DESC";
        $hasil1=  mysql_query($sql);
	
            
            
        while($rsa=mysql_fetch_array($hasil1)){
            $tgllahir=  $rsa['tgllahir'];
            $tgl = date('Y-m-d', strtotime($tgllahir));
            $umur = round( floor(time() - strtotime($tgl))/(60*60*24*365));
//                 $tglsekarang=  date('Y-m-d');
//                 $date1 = new DateTime(date('Y-m-d', strtotime($tgllahir)));
//                 $date2 = new DateTime(date('Y-m-d'));
//                 $interval = $date1->diff($date2);
//                 $usia=$interval->y ;
             
           // $usia=round(( $birth_date -  $tglsekarang)/360,0);            
                         
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[applicantid]";  ?></td>
                                            <td><?php echo"$rsa[nama]";  ?></td>
                                            <td align="center"><?php echo "$umur";  ?></td>
                                            <td align="center"><?php echo"$rsa[komunikasi]";  ?></td>
                                           
                                            <td align="center"><?php echo"$rsa[leveledukasi]";  ?></td>
                                            <td align="center"><?php echo"$rsa[jurusan]";  ?></td>
                                            <td align="center"><?php echo"$rsa[position]";  ?></td>
                                            <?php 
                                                    $statuspsikotest=$rsa[statuspsikotest];
                                                    if($statuspsikotest=='ok'){
                                                        echo "<td align=center>Disarankan</td>";
                                                    }
                                                    elseif($statuspsikotest=='tidak'){
                                                         echo "<td align=center>Tidak Disarankan</td>";
                                                    }
                                                    else{
                                                        echo "<td align=center>Not Yet</td>";
                                                    }
                                                    
                                                    $resultstatus=$rsa[resultstatus];
                                                    if($resultstatus=='ok'){
                                                        echo "<td align=center>Disarankan</td>";
                                                    }
                                                    elseif($resultstatus=='tidak'){
                                                         echo "<td align=center>Tidak Disarankan</td>";
                                                    }
                                                    elseif($resultstatus=='masih'){
                                                         echo "<td align=center>Masih Disarankan</td>";
                                                    }
                                                    else{
                                                        echo "<td>Not Yet</td>";
                                                    }
                                             ?>
                                            <td align="center"><?php echo"$rsa[status]";  ?></td>
                                        <td class="text-center"><a href="?module=app_widget&act=edit&id=<?php echo $rsa['applicantid'] ?>"><i class="fa fa-edit text-success"></i></a> 
                                               </td>

                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Psikotest</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
             <!-- DATA TABES SCRIPT -->
    <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>
            
            
  <?php } ?>