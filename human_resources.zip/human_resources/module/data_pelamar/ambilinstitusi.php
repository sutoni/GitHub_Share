<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//include 'config/conn.php';
//$idlevel = $_GET['idlevel'];
//$jurusan = "SELECT idlevel, jurusan FROM education_jurusan WHERE idlevel='$idlevel' order by jurusan";
//$hasilambil1=mysql_query($jurusan);
//echo "<option>-- Pilih Jurusan --</option>";
//while($k = mysql_fetch_array($hasilambil1)){
//    echo "<option value=\"".$k['idlevel']."\">".$k['jurusan']."</option>\n";
//}
//adri edit
//coba pak print $_GET['idlevel']
//try{
//if (isset($_GET['option'])) {
//    $option = $_GET['option'];
//    $idlevel=$_GET['idlevel'];
//    echo "$idlevel";
//    if ($option != "" && $option != null) {
//        include 'config/conn.php';        
//        $ORAQRYSTMT = "SELECT idlevel, jurusan FROM education_jurusan WHERE idlevel='$option' order by jurusan";
//        $ORAQRY = mysql_query($ORAQRYSTMT);
//       // oci_execute($ORAQRY);
//        $i = 0;
//        $data = null;
//        while (($ORAROW = mysql_fetch_array ($ORAQRY))) {
//            $data[$i] = $ORAROW['jurusan'];
//            $i = $i + 1;
//        }
//    } else {
//        $data = null;
//    }   
//    $reply = array('data' => $data, 'error' => false);
//} else {
//    $reply = array('error' => true);
//}
//
//$json = json_encode($reply);
//echo $json;
//
//}
//catch(PDOException $e){
//    echo $e->getMessage;
//}


    include "conn.php";
    $idlevelnya=$_POST['insti'];
    $sel_prov="SELECT idinstitusi, idlevel,namainstitusi, alamat FROM education_institusi WHERE idlevel='$idlevelnya' order by namainstitusi";
    $q=mysql_query($sel_prov);
    echo "$sel_prov";
    while($data_prov=mysql_fetch_array($q)){
   
    ?>
<option value="<?php echo $data_prov["idinstitusi"] ?>"><?php echo $data_prov["namainstitusi"];  ?></option><br>
   
    <?php
    }
    ?>

?>

