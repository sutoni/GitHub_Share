
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
        <section class="content-header">
          <h1> Import data Applicant Education </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Import</a></li>
            <li class="active">Applicant Education</li>
          </ol>
        </section>
            <div class="row">
                  <div class="col-xs-12">    
                            
                              <div class="box">
                                <div class="box-header">
                                 
                                </div><!-- /.box-header -->
                                <div class="box col-xs-12">
                                    <br><br>
                            <form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
                            <font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
                            <input type='file' name='filename' size='20'><br>
                            <input type='submit' name='submit' value='Insert'><input type='submit' name='update' value='Update'></form>
                            <br>



                            <?php
                            print "<p>Catatan :  Apabila data yang diimport adalah data Baru silahkan tekan Insert<br>
                                          namun bila data yang diimport sudah ada silahkan tekan tombol Update
                             </p>";

                             include "config/conn.php";   

                            if(isset($_POST['submit']))
                            {
                            $target_path = 'c:\xampp\htdocs\human_resources\test';  

                            $target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

                            if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
                            echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
                            } else{
                            echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
                            } // ini untuk mengupload file CSV ke alamat tadi
                            // ini script untuk mengimport data CSV ke MySQL
                            $filename=$target_path;
                            $handle = fopen("$filename", "r");
                            while (($data = fgetcsv($handle, 30000, ",")) !== FALSE)
                            {
                               $appeduid=$data[0];
                                $querycek="SELECT COUNT(appeduid)as Jumlah
                                           FROM applicant_education
                                          WHERE appeduid='$appeduid'
                                            ";
                                $hasilcek=mysql_query($querycek);
                                 
                                $row=  mysql_fetch_array($hasilcek);
                                
                                    $row1=$row[Jumlah];
                                    
                                    if($row1 > 0){
                                        $appeduid=$data[0];
                                        $applicantid=$data[1];
                                        $leveledukasi=$data[2];
                                        $jurusan=$data[3];
                                        $institusi=$data[4];
                                        $ipk=$data[5];
                                        
                                       
                                        
                                       $updateexist    =" UPDATE applicant_education SET
                                                            applicantid      =   '$applicantid',
                                                            leveledukasi       =   '$leveledukasi',
                                                            jurusan        =   '$jurusan',
                                                            institusi     =   '$institusi',
                                                            ipk        =   '$ipk'
                                                           
                                                            WHERE $appeduid  ='$appeduid'";       
                                                        $masuk=  mysql_query($updateexist); 
                                        
                                    }
                                    else{
                                    $import="INSERT into applicant_education values(
                                             '$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]'
                                            
                                            )";
                                    $masuk=  mysql_query($import);
                                       
                                    }
                            }
                            fclose($handle);
                            echo "<script>window.alert(' Terima kasih yaa, Data Telah Terimport');
                                    window.location=('?module=app_overview&act=view_appinfo')</script>";
                              }
                              


                          

                            ?>  </div>                
                 </div>
                </div>
                </div>

</BODY>
</HTML>
