<!DOCTYPE html>
<html>
     <head>
   
<?php
if($_GET['act']=="input"){
	?>
  <body>
      <br>
        <br>          
        
        
        <div id="step1">
                <ul class="breadcrumb1">
                    <li><a href="#">Applicant Register</a></li>                   
                    <li><a href="#">Step 2</a></li>
                    <li><a href="#">Step 3</a></li>                   
                  </ul>
                <!-- /.col-lg-12 -->
                
            <div class="row">
                <div class="col-lg-12">
					<h3 class="page-header"><strong>Input Data Applicant</strong></h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Personnel Applicant
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                    <form method="post" role="form" action="?module=simpan&act=input_apppersonal">

                                <div class="col-lg-6" id="step1">
                                        <div class="form-group">
                                            <label>First Name</label>
                                            <input class="form-control" placeholder="First Name" name="txtfirstname" id="txtfirstname">
                                        </div>
                                        <div class="form-group">
                                            <label>Last Name</label>
                                            <input class="form-control" placeholder="Last Name" name="txtlastname" id="txtlastname">
                                        </div>
                                         <div class="form-group">
                                            <label>Jenis Kelamin</label>
                                            <select id="txtgender" name="txtgender" class="form-control">
                                                <option value="m">Male</option>
                                                <option value="f">Female</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Tempat Lahir</label>
                                            <input class="form-control" placeholder="Tempat Lahir" name="txttmplahir" id="txttmplahir">
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Lahir </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttgllahir" id="txttgllahir">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                                        
                                         <div class="form-group col-lg-5" colspan="0">
                                            <label>Telpon</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txttelpon" id="txttelpon">
                                        </div>
                                    
                                         <div class="form-group col-lg-5">
                                            <label>HP</label>
                                            <input class="form-control" placeholder="+62813-7209510" name="txthp" id="txthp">
                                        </div>
                                    
                                        
                                         <div class="form-group col-lg-12">
                                            <label>Email</label>
                                            <input class="form-control" placeholder="a@usahadong.com" name="txtemail" id="txtemail">
                                        </div>
                                        <br>
                                        <div class="form-group col-lg-12">
                                            <label>Alamat</label>
                                            <textarea class="form-control" placeholder="Alamat" name="txtalamat" id="txtalamat" rows="3"></textarea>
                                        </div>
                                        <br><br>
                                        <div class="form-group">
                                            <label>Agama</label>
                                            <select id="txtagama" name="txtagama" class="form-control">
                                                <option value="-">-</option>
                                                <option value="Islam">Islam</option>
                                                <option value="Katolik">Katolik</option>
                                                <option value="Protestan">Protestan</option>
                                                <option value="Hindu">Hindu</option>
                                                <option value="Budha">Budha</option>
                                                <option value="other">Others</option>
                                            </select>
                                        </div>
                                         <div class="form-group">
                                            <label>Status Pernikahan</label>
                                            <select id="txtstatusnikah" name="txtstatusnikah" class="form-control">
                                                <option value="single">Single</option>
                                                <option value="merried">Merried</option>
                                                <option value="widower">Widower</option>
                                               
                                            </select>
                                        </div>
                                        <br><br>
                                        <button><a href="step2">Next</a></button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    
                               
                               
                            
                                    
                                    
                                    
                                    </form>
                                  <div class="row">
                                    <div class="col-md-10">
                                      <div class="box box-default collapsed-box">
                                        <div class="box-header with-border">
                                          <h3 class="box-title">Expandable</h3>
                                          <div class="box-tools pull-right">
                                            <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                          </div><!-- /.box-tools -->
                                        </div><!-- /.box-header -->
                                        <div class="box-body">
                                          The body of the box
                                        </div><!-- /.box-body -->
                                      </div><!-- /.box -->
                                    </div><!-- /.col -->
                                </div>
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </div>        
    
          <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
  </body>
</html>
<?php } ?>
           
         