
<!DOCTYPE html>
        <!-- Content Wrapper. Contains page content -->
        <?php
    /*
        Overview Screening Applicant
    */
if($_GET['act']=="input"){
    
    
 
    ?>    
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Application Register
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_organization">Applicant</a></li>
            <li class="active">Applicant Register</li>
          </ol>
        </section>
   
        <!-- Main content -->
        <section class="content">

           <form method="post" role="form" action="?module=simpan&act=input_apppersonal"> 
          <!-- Default box -->
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Applicant Personal</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <!-- Applicant Personal -->
                            <div class="col-lg-6" id="step1">
                                        <div class="form-group">
                                            <label>First Name</label>
                                            <input class="form-control" placeholder="First Name" name="txtfirstname" id="txtfirstname">
                                        </div>
                                        <div class="form-group">
                                            <label>Last Name</label>
                                            <input class="form-control" placeholder="Last Name" name="txtlastname" id="txtlastname">
                                        </div>
                                         <div class="form-group">
                                            <label>Jenis Kelamin</label>
                                            <select id="txtgender" name="txtgender" class="form-control">
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Tempat Lahir</label>
                                            <input class="form-control" placeholder="Tempat Lahir" name="txttmplahir" id="txttmplahir">
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Lahir </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttgllahir" id="txttgllahir">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                            </div>
                             <div class="col-lg-6" id="step1">
                                         <div class="form-group col-lg-5" colspan="0">
                                            <label>Telpon</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txttelpon" id="txttelpon">
                                        </div>
                                    
                                         <div class="form-group col-lg-5">
                                            <label>HP</label>
                                            <input class="form-control" placeholder="+62813-7209510" name="txthp" id="txthp">
                                        </div>
                                    
                                        
                                         <div class="form-group col-lg-12">
                                            <label>Email</label>
                                            <input class="form-control" placeholder="a@usahadong.com" name="txtemail" id="txtemail">
                                        </div>
                                        <br>
                                        <div class="form-group col-lg-12">
                                            <label>Alamat</label>
                                            <textarea class="form-control" placeholder="Alamat" name="txtalamat" id="txtalamat" rows="3"></textarea>
                                        </div>
                                        <br><br>
                                        <div class="form-group">
                                            <label>Agama</label>
                                            <select id="txtagama" name="txtagama" class="form-control">
                                                <option value="-">-</option>
                                                <option value="Islam">Islam</option>
                                                <option value="Katolik">Katolik</option>
                                                <option value="Protestan">Protestan</option>
                                                <option value="Hindu">Hindu</option>
                                                <option value="Budha">Budha</option>
                                                <option value="other">Others</option>
                                            </select>
                                        </div>
                                         <div class="form-group">
                                            <label>Status Pernikahan</label>
                                            <select id="txtstatusnikah" name="txtstatusnikah" class="form-control">
                                                <option value="single">Single</option>
                                                <option value="merried">Merried</option>
                                                <option value="widower">Widower</option>
                                               
                                            </select>
                                        </div>
                                       
                                </div>


            </div><!-- /.box-body -->
           
          </div><!-- /.box -->
          
          
          <!-- Applicant Education -->
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Applicant Education</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <!-- Applicant Personal -->
                            <div class="col-lg-6" id="step1">
                                        
                                         <div class="form-group">
                                            <label>Level Education</label>
                                            <select name="txtedulevel" id="txtedulevel" class="form-control">
                                                <script type="text/javascript" src="../../js/jQuery-2.1.3.min.js"></script>
                                                <?php 
                                                    $sql1="SELECT idlevel FROM education_level ORDER  BY   urutan ";
                                                    $hasil=  mysql_query($sql1);
                                                    WHILE($rs=  mysql_fetch_array($hasil))
                                                    {
                                                        echo "<option value='$rs[idlevel]'>$rs[idlevel]</option>";
                                                        
                                                    }
                                                ?>
                                                
                                            </select>
                                        </div>
                                        <script>

                                                    $("#txtedulevel").change(function(){

                                                        // variabel dari nilai combo box provinsi
                                                        var idlevel = $("#txtedulevel").val();

                                                        // tampilkan image load
                                                        $("#imgLoad").show("");

                                                        // mengirim dan mengambil data
                                                        $.ajax({
                                                            type: "POST",
                                                            dataType: "html",
                                                            url: "education_jurusan.php",
                                                                data: "jur="+idlevel,
                                                            success: function(msg){

                                                                // jika tidak ada data
                                                                if(msg == ''){
                                                                    alert('Tidak ada data Jurusan');
                                                                }

                                                                // jika dapat mengambil data,, tampilkan di combo box kota
                                                                else{
                                                                    $("#txtjurusan").html(msg);                                                     
                                                                }

                                                                // hilangkan image load
                                                                $("#imgLoad").hide();
                                                            }
                                                        });    
                                                    });
                                                </script>
                                         &nbsp;&nbsp;&nbsp;<img src="loader.gif" width="10px" height="10px" id="imgLoad" style="display:none">
    
                                        <div class="form-group">
                                            <label>Jurusan</label>
                                            <select id="txtjurusan" name="txtjurusan" class="form-control">
                                                <option value="Teknik Informasi">Teknik Informasi</option>
                                                <option value="Teknik Informasi">Teknik Industri</option>
                                                <option value="Teknik Informasi">Teknik Elektro</option>
                                                <option value="Teknik Informasi">Teknik Mesin</option>
                                                <option value="Manajemen Bisnis">Manajemen Bisnis</option>
                                                <option value="Teknik Industri">Ekonomi Industri</option>
                                                <option value="Teknik Industri">Ekonomi Bisnis</option>
                                                <option value="Teknik Industri">Akutansi</option>
                                                <option value="Teknik Industri"></option> -->
                                            </select>    
                                                
                                                
                                                
                                              <!--  <option value="Sistem Informasi">Sistem Informasi</option>
                                                <option value="Teknik Informasi">Teknik Informasi</option>
                                                <option value="Teknik Informasi">Teknik Industri</option>
                                                <option value="Teknik Informasi">Teknik Elektro</option>
                                                <option value="Teknik Informasi">Teknik Mesin</option>
                                                <option value="Manajemen Bisnis">Manajemen Bisnis</option>
                                                <option value="Teknik Industri">Ekonomi Industri</option>
                                                <option value="Teknik Industri">Ekonomi Bisnis</option>
                                                <option value="Teknik Industri">Akutansi</option>
                                                <option value="Teknik Industri"></option> -->
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Institusi</label>
                                            <select id="txtinstitusi" name="txtinstitusi" class="form-control">
                                                <option value="Universitas Mercubuana">Universitas Mercubuana</option>
                                                <option value="Universitas Indonesia">Universitas Indonesia</option>
                                                <option value="Universitas Teknologi Bandung">Universitas Teknologi Bandung</option>
                                                <option value="Universitas Teknologi Surabaya">Universitas Teknologi Surabaya</option>
                                                <option value="Universitas Gunadarma">Universitas Gunadarma</option>
                                                <option value="Universitas Budi Luhur">Universitas Budi Luhur</option>
                                                <option value="Universitas Esa Unggul">Universitas Esa Unggul</option>
                                                <option value="Universitas Trisakti">Universitas Trisakti</option>
                                            </select>
                                        </div>
                            </div>
                            <div class="col-lg-6" id="step1">
                                        <div class="form-group">
                                            <label>IPK</label>
                                            <input class="form-control" placeholder="Nilai IPK" name="txtipk" id="txtipk">
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Masuk </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglmasuk" id="txttglmasuk">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Keluar </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglkeluar" id="txttglkeluar">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Apply </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglapply" id="txttglapply">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                            </div><!-- End of Applicant Education -->               
              
              
              
              
              
            </div><!-- /.box-body -->
            </div><!-- /.box -->
            
            <!-- Applicant Experience -->
             <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Applicant Last Experience</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <!-- Applicant Personal -->
                            <div class="col-lg-6" id="step1">
                                        
                                         <div class="form-group">
                                            <label>Industri Area</label>
                                            <select  name="txtindarea" id="txtindarea" class="form-control">
                                                <option value="Farmasi">Farmasi</option>
                                                <option value="Perbankan">Perbankan</option>
                                                <option value="Oil">Oil</option>
                                                <option value="Retail">Retail</option>
                                                <option value="Pendidikan">Pendidikan</option>
                                                <option value="PNS">PNS</option>
                                                <option value="Telekomunikasi">Telekomunikasi</option>
                                                <option value="Teknologi Informasi">Teknologi Informasi</option>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Fungsional Area</label>
                                            <select  name="txtfuncarea" id="txtfuncarea" class="form-control">
                                                <option value="Akademisi">Akademisi</option>
                                                <option value="Pengusaha">Pengusaha</option>
                                                <option value="Marketing">Marketing</option>
                                                <option value="Administrasi">Administrasi</option>
                                                <option value="Keuangan">Keuangan</option>
                                                <option value="Sumber Daya Manusia">Sumber Daya Manusia</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Position</label>
                                            <select  name="txtposition" id="txtposition" class="form-control">
                                                <option value="Medical Representative">Medical Representative</option>
                                                <option value="Officer Finance">Officer Finance</option>
                                                <option value="Officer HRD">Officer HRD</option>
                                                <option value="Others">Others</option>
                                            </select>
                                        </div>
                                        
                            </div>
                            <div class="col-lg-6" id="step1">
                                        <div class="form-group">
                                            <label>Gaji</label>
                                            <input class="form-control" placeholder="Gaji" name="txtgaji" id="txtgaji">
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Masuk </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglmasuk" id="txttglmasuk">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Keluar </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglkeluar" id="txttglkeluar">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                            </div><!-- End of Applicant Experience -->               
              
              
              
              
              
            </div><!-- /.box-body -->
            
          
          </div><!-- /.box -->
          <div> <button type="submit">Submit</button> </div>
          
        
          
        </form>
          
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <?php
        }
        
        if($_GET['act']=="edit"){
            $id=$_GET['id'];
            
        ?>
                 <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Application Register
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_organization">Applicant</a></li>
            <li class="active">Applicant Register</li>
          </ol>
        </section>
   
        <!-- Main content -->
        <section class="content">

           <form method="post" role="form" action="?module=simpan&act=input_apppersonal"> 
          <!-- Default box -->
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Applicant Personal</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <!-- Applicant Personal -->
               <?php
                        $tangkap="SELECT * FROM applicant_personal WHERE applicantid='$id' ";
                        $hasil=  mysql_query($tangkap);
                        $ri=  mysql_fetch_array($hasil);
                        $firsname=$ri[firstname];
                       
              
              ?>
                            <div class="col-lg-6" id="step1">
                                        <div class="form-group">
                                            <label>First Name</label>
                                            <input class="form-control" placeholder="First Name" name="txtfirstname" id="txtfirstname" value="<?php echo $firsname; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Last Name</label>
                                            <input class="form-control" placeholder="Last Name" name="txtlastname" id="txtlastname" value="<?php echo $ri[lastname]; ?>">
                                        </div>
                                         <div class="form-group">
                                            <label>Jenis Kelamin</label>
                                            <select id="txtgender" name="txtgender" class="form-control">
                                                <option value="<?php echo $ri[gender]; ?>"><?php echo $ri[gender]; ?></option>
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Tempat Lahir</label>
                                            <input class="form-control" placeholder="Tempat Lahir" name="txttmplahir" id="txttmplahir" value="<?php echo $ri[tempatlahir]; ?>">
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Lahir </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttgllahir" id="txttgllahir" value="<?php echo $ri[tgllahir]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                            </div>
                             <div class="col-lg-6" id="step1">
                                         <div class="form-group col-lg-5" colspan="0">
                                            <label>Telpon</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txttelpon" id="txttelpon" value="<?php echo $ri[telpon]; ?>">
                                        </div>
                                    
                                         <div class="form-group col-lg-5">
                                            <label>HP</label>
                                            <input class="form-control" placeholder="+62813-7209510" name="txthp" id="txthp" value="<?php echo $ri[hp]; ?>">
                                        </div>
                                    
                                        
                                         <div class="form-group col-lg-12">
                                            <label>Email</label>
                                            <input class="form-control" placeholder="a@usahadong.com" name="txtemail" id="txtemail" value="<?php echo $ri[email]; ?>">
                                        </div>
                                        <br>
                                        <div class="form-group col-lg-12">
                                            <label>Alamat</label>
                                            <textarea class="form-control" placeholder="Alamat" name="txtalamat" id="txtalamat" rows="3"><?php echo $ri[alamat]; ?></textarea>
                                        </div>
                                        <br><br>
                                        <div class="form-group">
                                            <label>Agama</label>
                                            <select id="txtagama" name="txtagama" class="form-control">
                                                <option value="<?php echo $ri[agama]; ?>"><?php echo $ri[agama]; ?></option>
                                                <option value="Islam">Islam</option>
                                                <option value="Katolik">Katolik</option>
                                                <option value="Protestan">Protestan</option>
                                                <option value="Hindu">Hindu</option>
                                                <option value="Budha">Budha</option>
                                                <option value="other">Others</option>
                                            </select>
                                        </div>
                                         <div class="form-group">
                                            <label>Status Pernikahan</label>
                                            <select id="txtstatusnikah" name="txtstatusnikah" class="form-control">
                                                <option value="<?php echo $ri[statusnikah]; ?>"><?php echo $ri[statusnikah]; ?></option>
                                                <option value="single">Single</option>
                                                <option value="merried">Merried</option>
                                                <option value="widower">Widower</option>
                                               
                                            </select>
                                        </div>
                                       
                                </div>


            </div><!-- /.box-body -->
           
          </div><!-- /.box -->
          
          
          <!-- Applicant Education -->
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Applicant Education</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <!-- Applicant Personal -->
                            <div class="col-lg-6" id="step1">
                                
                                   
                                
                                         <div class="form-group">
                                            <label>Level Education</label>
                                            <select name="txtedulevel" id="txtedulevel" class="form-control">
                                                 <?php
                                                 $id=$_GET['id'];
                                                $tangkap2="SELECT * FROM applicant_education WHERE applicantid='$id' ";
                                                $hasil=  mysql_query($tangkap2);
                                                $re=  mysql_fetch_array($hasil);
                                    ?>
                                                 <option value="<?php echo $re[leveledukasi]; ?>"><?php echo $re[leveledukasi]; ?></option>
                                                <option value="SLTA">SLTA</option>
                                                <option value="D1">D1</option>
                                                <option value="D2">D2</option>
                                                <option value="D3">D3</option>
                                                <option value="D4">D4</option>
                                                <option value="S1">S1</option>
                                                <option value="S2">S2</option>
                                                <option value="S3">S3</option>
                                                <option value="PROFESI">PROFESI</option>
                                            </select>
                                        </div>
                                       
                                        <div class="form-group">
                                            <label>Jurusan</label>
                                            <select id="txtjurusan" name="txtjurusan" class="form-control">
                                                <option value="<?php echo $re[jurusan]; ?>"><?php echo $re[jurusan]; ?></option>
                                                <option value="Sistem Informasi">Sistem Informasi</option>
                                                <option value="Teknik Informasi">Teknik Informasi</option>
                                                <option value="Teknik Industri">Teknik Industri</option>
                                                <option value="Teknik Elektro">Teknik Elektro</option>
                                                <option value="Teknik Mesin">Teknik Mesin</option>
                                                <option value="Manajemen Bisnis">Manajemen Bisnis</option>
                                                <option value="Ekonomi Industri">Ekonomi Industri</option>
                                                <option value="Ekonomi Bisnis">Ekonomi Bisnis</option>
                                                <option value="Akutansi">Akutansi</option>
                                                <option value="Design">Design</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Institusi</label>
                                            <select id="txtinstitusi" name="txtinstitusi" class="form-control">
                                                <option value="<?php echo $re[institusi]; ?>"><?php echo $re[institusi]; ?></option>
                                                <option value="Universitas Mercubuana">Universitas Mercubuana</option>
                                                <option value="Universitas Indonesia">Universitas Indonesia</option>
                                                <option value="Universitas Teknologi Bandung">Universitas Teknologi Bandung</option>
                                                <option value="Universitas Teknologi Surabaya">Universitas Teknologi Surabaya</option>
                                                <option value="Universitas Gunadarma">Universitas Gunadarma</option>
                                                <option value="Universitas Budi Luhur">Universitas Budi Luhur</option>
                                                <option value="Universitas Esa Unggul">Universitas Esa Unggul</option>
                                                <option value="Universitas Trisakti">Universitas Trisakti</option>
                                            </select>
                                        </div>
                            </div>
                            <div class="col-lg-6" id="step1">
                                        <div class="form-group">
                                            <label>IPK</label>
                                            <input class="form-control" placeholder="Nilai IPK" name="txtipk" id="txtipk" value="<?php echo $re[ipk]; ?>">
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Masuk </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglmasuk" id="txttglmasuk" value="<?php echo $re[startdate]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Keluar </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglkeluar" id="txttglkeluar" value="<?php echo $re[enddate]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Apply </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglapply" id="txttglapply" value="<?php echo $ri[tglapply]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                            </div><!-- End of Applicant Education -->               
              
              
              
              
              
            </div><!-- /.box-body -->
            </div><!-- /.box -->
            
            <!-- Applicant Experience -->
             <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Applicant Last Experience</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <!-- Applicant Personal -->
                            <div class="col-lg-6" id="step1">
                                        <?php
                                                 $id=$_GET['id'];
                                                $tangkap3="SELECT * FROM applicant_experience WHERE applicantid='$id' ";
                                                $hasil=  mysql_query($tangkap3);
                                                $rw=  mysql_fetch_array($hasil);
                                                echo "";
                                        ?>
                                         <div class="form-group">
                                            <label>Industri Area</label>
                                            <select  name="txtindarea" id="txtindarea" class="form-control">
                                                <option  value="<?php echo $rw[industryarea]; ?>"><?php echo $rw[industryarea]; ?></option>
                                                <option value="Farmasi">Farmasi</option>
                                                <option value="Perbankan">Perbankan</option>
                                                <option value="Oil">Oil</option>
                                                <option value="Retail">Retail</option>
                                                <option value="Pendidikan">Pendidikan</option>
                                                <option value="PNS">PNS</option>
                                                <option value="Telekomunikasi">Telekomunikasi</option>
                                                <option value="Teknologi Informasi">Teknologi Informasi</option>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Fungsional Area</label>
                                            <select  name="txtfuncarea" id="txtfuncarea" class="form-control">
                                               
                                                <option  value="<?php echo $rw[functionalarea]; ?>"><?php echo $rw[functionalarea]; ?></option>
                                                <option value="Akademisi">Akademisi</option>
                                                <option value="Pengusaha">Pengusaha</option>
                                                <option value="Marketing">Marketing</option>
                                                <option value="Administrasi">Administrasi</option>
                                                <option value="Keuangan">Keuangan</option>
                                                <option value="Sumber Daya Manusia">Sumber Daya Manusia</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Position</label>
                                            <select  name="txtposition" id="txtposition" class="form-control">
                                                <option  value="<?php echo $rw[position]; ?>"><?php echo $rw[position]; ?></option>
                                                <option value="Medical Representative">Medical Representative</option>
                                                <option value="Officer Finance">Officer Finance</option>
                                                <option value="Officer HRD">Officer HRD</option>
                                                <option value="Others">Others</option>
                                            </select>
                                        </div>
                                        
                            </div>
                            <div class="col-lg-6" id="step1">
                                        <div class="form-group">
                                            <label>Gaji</label>
                                            <input class="form-control" placeholder="Gaji" name="txtgaji" id="txtgaji" value="<?php echo $rw[gaji]; ?>">
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Masuk </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglmasuk" id="txttglmasuk" value="<?php echo $rw[startdate]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <div class="form-group"> 
                                        <label class="control-label"> Tanggal Keluar </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglkeluar" id="txttglkeluar" value="<?php echo $rw[enddate]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                            </div><!-- End of Applicant Experience -->               
              
              
              
              
              
            </div><!-- /.box-body -->
            
          
          </div><!-- /.box -->
          <div> <button type="submit">Submit</button> </div>
          
        
          
        </form>
          
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
    <?php        
        }
    ?> 