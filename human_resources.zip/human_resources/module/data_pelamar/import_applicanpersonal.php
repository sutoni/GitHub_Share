
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
        <section class="content-header">
          <h1> Import data Applicant Personal </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Import</a></li>
            <li class="active">Applicant Personal</li>
          </ol>
        </section>
            <div class="row">
                  <div class="col-xs-12">    
                            
                              <div class="box">
                                <div class="box-header">
                                 
                                </div><!-- /.box-header -->
                                <div class="box col-xs-12">
                                    <br><br>
                            <form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
                            <font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
                            <input type='file' name='filename' size='20'><br>
                            <input type='submit' name='submit' value='Insert'><input type='submit' name='update' value='Update'></form>
                            <br>



                            <?php
                            print "<p>Catatan :  Apabila data yang diimport adalah data Baru silahkan tekan Insert<br>
                                          namun bila data yang diimport sudah ada silahkan tekan tombol Update
                             </p>";

                             include "config/conn.php";   

                            if(isset($_POST['submit']))
                            {
                            $target_path = 'c:\xampp\htdocs\human_resources\test';  

                            $target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

                            if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
                            echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
                            } else{
                            echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
                            } // ini untuk mengupload file CSV ke alamat tadi
                            // ini script untuk mengimport data CSV ke MySQL
                            $filename=$target_path;
                            $handle = fopen("$filename", "r");
                            while (($data = fgetcsv($handle, 30000, ",")) !== FALSE)
                            {
                               $applicantid=$data[0];
                                $querycek="SELECT COUNT(applicantid)as Jumlah
                                           FROM applicant_personal
                                          WHERE applicantid='$applicantid'
                                            ";
                                $hasilcek=mysql_query($querycek);
                                 
                                $row=  mysql_fetch_array($hasilcek);
                                
                                    $row1=$row[Jumlah];
                                    
                                    if($row1 > 0){
                                        $applicantid=$data[0];
                                        $firstname=$data[1];
                                        $lastname=$data[2];
                                        $gender=$data[3];
                                        $tempatlahir=$data[4];
                                        $tgllahir=$data[5];
                                        $telpon=$data[6];
                                        $hp=$data[7];
                                        $email=$data[8];
                                        $alamat=$data[9];
                                        $statusnikah=$data[10];
                                        $status=$data[11];
                                        $statuspull=$data[12];
                                        $tglinterviewhr=$data[13];
                                        $statusinterviewhr=$data[14];
                                        $tglinterviewuser1=$data[15];
                                        $statusinterviewuser1=$data[16];
                                        $tglinterviewuser2=$data[17];
                                        $statusinterviewuser2=$data[18];
                                        $tglpsikotest=$data[19];
                                        $statuspsikotest=$data[20];
                                        $tglapply=$data[21];
                                        $recmethod=$data[22];
                                        $recevent=$data[23];
                                       
                                        
                                       $updateexist    =" UPDATE applicant_personal SET
                                                            firstname      =   '$firstname',
                                                            lastname       =   '$lastname',
                                                            gender        =   '$gender',
                                                            tempatlahir     =   '$tempatlahir',
                                                            tgllahir        =   '$tgllahir',
                                                            telpon       =   '$telpon',
                                                            hp      =   '$hp',
                                                            email            =   '$email',
                                                            alamat          =   '$alamat',
                                                            statusnikah         =   '$statusnikah',
                                                            recmethod    =   '$recmethod',
                                                            recevent       =   '$recevent'
                                                            WHERE applicantid  ='$applicantid'";       
                                                        $masuk=  mysql_query($updateexist); 
                                        
                                    }
                                    else{
                                    $import="INSERT into applicant_personal values(
                                             '$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]',
                                            '$data[7]','$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]',
                                            '$data[14]','$data[15]','$data[16]','$data[17]','$data[18]','$data[19]','$data[20]',
                                            '$data[21]','$data[22]','$data[23]'
                                            )";
                                    $masuk=  mysql_query($import);
                                       
                                    }
                            }
                            fclose($handle);
                            echo "<script>window.alert(' Terima kasih yaa, Data Telah Terimport');
                                    window.location=('?module=app_overview&act=view_appinfo')</script>";
                              }
                              


                          

                            ?>  </div>                
                 </div>
                </div>
                </div>

</BODY>
</HTML>
