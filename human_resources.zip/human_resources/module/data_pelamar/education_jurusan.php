<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    include "config/conn.php";
   
    $sel_jur="select * from education_jurusan where idjurusan='".$_POST["jur"]."'";
    $q=mysql_query($sel_jur);
    
    echo "$sel_jur";
    while($rs=mysql_fetch_array($q)){
    ?>
        <option value="<?php echo $rs["idjurusan"] ?>"><?php echo $rs["jurusan"] ?></option><br>
    <?php
    }
    ?>