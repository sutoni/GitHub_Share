<!DOCTYPE html>
<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script type="text/javascript">
    //check all checkbox
            function check_all(val) {
                // Ganti nilai form_data sesuai dengan nama form 
                var checkbox = document.form_data.elements['item[]'];
                if ( checkbox.length > 0 ) {
                    for (i = 0; i < checkbox.length; i++) {
                        if ( val.checked ) {
                            checkbox[i].checked = true;
                        }
                        else {
                            checkbox[i].checked = false;
                        }
                    }
                }
                else {
                    if ( val.checked ) {
                        checkbox.checked = true;
                    }
                    else {
                        checkbox.checked = false;
                    }
                }
            }
    </script>
    
     
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Applicant Screening Process
          </h1>
          <ol class="breadcrumb">
            <li><a href="?module=home"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=app_screening&act=view_screening">Applicant Overview</a></li>
            <li class="active">Applicant Information</li>
          </ol>
        </section>
    
   <br>
       
                                <div class=" pull-right hidden-xs">
                                       
                                    
                                    <a href="?module=app_screening&act=view_screeningpull">
                                        Pull
                                        <span class="badge" >
                                            <?php
                                                 include "config/conn.php";
                                                 $hitunghasil="SELECT  COUNT(applicantid)as jmlall FROM applicant_personal WHERE statuspull='step1' ";
                                                 $hasilhitung=  mysql_query($hitunghasil);
                                                 $rshitung=mysql_fetch_array($hasilhitung);
                                                 $jml=$rshitung['jmlall']; 
                                                 echo "$jml";       
                                                 
                                            ?>
                                        </span> 
                                         
                                      </a>
                                      |
                                       <a href="?module=app_screening&act=view_psikotest">
                                        Psikotest
                                        <span class="badge" >
                                            <?php
                                                 $hitungpull="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE 
                                                         statuspull='ok' AND statusinterviewhr='belum' AND statusinterviewuser1='belum' AND statuspsikotest='ok'";
                                                 $hasilpull=  mysql_query($hitungpull);
                                                 $rspull=  mysql_fetch_array($hasilpull);
                                                

                                                 echo "$rspull[jml]";
                                            ?>
                                        </span> 
                                         
                                      </a> |
                                       
                                      <a href="?module=app_screening&act=view_interviewhr">
                                        Interview HR
                                        <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE 
                                                         statuspull='ok' AND statusinterviewhr='ok' AND statusinterviewuser1='belum' AND statuspsikotest='ok'
                                                          ";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               

                                                 echo "$rs[jml]";
                                            ?>
                                        </span> 
                                         
                                      </a>|
                                      <a href="?module=app_screening&act=view_interviewuser">
                                        Interview User
                                        <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE 
                                                         statuspull='ok' AND statusinterviewhr='ok' AND statusinterviewuser1='ok' AND statuspsikotest='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 

                                                 echo "$rs[jml]";
                                            ?>
                                        </span> 
                                         
                                      </a> |
                                     <a href="?module=app_screening&act=view_mcu">
                                        MCU
                                        <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step5' ";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               

                                                 echo "$rs[jml]";
                                            ?>
                                        </span> 
                                         
                                      </a> |
                                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                  </div>
   <br> 
                                  <!-- Test buat folder -->
                                  
                                  
  
              <?php
    /*
        Overview Screening Applicant
    */
if($_GET['act']=="view_screening"){
    
         echo "<form method='POST' name='form_data' action='?module=simpan&act=update_appscreening'  onSubmit='return confirm('Anda ingin ubah status?')'>";
	?>
        
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                  <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Applicant Info</h3>
                                  <div class="pull-right hidden-xs">
                                        Select All &nbsp;<input class="fa fa-check-circle" type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>&nbsp;
                                      | Screening 
                                          <button type="submit" name="btnsubmit" class="btn " value="tolakscreening" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                include "config/conn.php";
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statuspull='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                        </span> 
                                          </button>
                                      
                                          <button type="submit" name="btnsubmit" class="btn " value="terimascreening" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml1 FROM applicant_personal WHERE  statuspull='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml1]";
                                            ?>
                                        </span> 
                                          </button>
                                      
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi </th>
                                                
                                        </tr>
                                    </thead>
                                    <tbody>

<?php

include "config/conn.php";
$no=1;
	$sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.gender, a.tgllahir, 
                CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.status
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                WHERE a.status='polled'";
        $hasil1=  mysql_query($sql);
	
        
        while($rsa= mysql_fetch_array($hasil1)){
                                   
?>                                        <tr class="odd gradeX">
                                            <?php 
                                                echo "<td> $rsa[applicantid]</td>";
                                                echo "<td> $rsa[nama]</td>";
                                                echo "<td> $rsa[tgllahir]</td>";
                                                echo "<td> $rsa[komunikasi]</td>";
                                                echo "<td> $rsa[email]</td>";
                                                echo "<td> $rsa[leveledukasi]</td>";
                                                echo "<td> $rsa[jurusan]</td>";
                                                echo "<td> $rsa[position]</td>";
                                                echo "<td> $rsa[functionalarea]</td>";
                                              echo "<td>$rsa[status]</td>";
                                        
                                         echo "<td align=center><input type='checkbox' name='item[]' id='item[]' value='$rsa[applicantid]' /></td>";?>
                                         
</tr>

<?php }
                                        
?>

                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      
      </div>
    
            
      <!-- Screening Panggil  -->      
  <?php
  
   echo '</form>';
                                            } 
      
      
      if($_GET['act']=="view_screeningpull"){
    
          echo "<form method='post' name='form_data' action='?module=simpan&act=update_appspull' onSubmit='return confirm('Anda ingin Mapping Produk terChoice')'>";
	?>
        
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                  <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Applicant Info</h3>
                                  <div class="pull-right hidden-xs">
                                        Select All &nbsp;<input class="fa fa-check-circle" type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>&nbsp;
<!--                                      | Interview HR 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statuspull='step2' AND statusinterviewhr='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statuspull='step2' AND statusinterviewhr='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 $jml=$rs[jml];
                                                 echo "$jml";
                                            ?>
                                            </span> 
                                        </button>
                                      | Interview User 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolakuser" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step3' AND statusinterviewuser='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terimauser" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step3' AND statusinterviewuser='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 $jml=$rs[jml];
                                                 echo "$jml";
                                            ?>
                                            </span> 
                                        </button>-->
                                      | Psikotest 1
                                      <button type="submit" name="btnsubmit" class="btn " value="tolakpsi" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE 
                                                         status='step2' AND statuspsikotest='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button name="btnsubmit"  value="terimapsi" class="btn btn-default" data-toggle="modal" data-target="myPsiOk" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statuspull='step1' AND statuspsikotest='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                            
                                            
                                        </button>
                                      &nbsp;&nbsp;
                                      <!-- Interview HR Ok -->
                                      
                                      | Interview HR 
                                      <button type="submit" name="btnsubmit" class="btn " value="tolakpsi" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE 
                                                         status='step2' AND statuspsikotest='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terimapsi" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step1' AND statuspsikotest='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      &nbsp;&nbsp;
                                      
                                      <!-- Interview User -->
                                      
                                      | Interview User 1 
                                      <button type="submit" name="btnsubmit" class="btn " value="tolakpsi" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE 
                                                         status='step2' AND statuspsikotest='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button  name="btnsubmit" class="btn " value="terimapsi" data-toggle="modal" data-target="#myPsiOk"  >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statuspull='step1' AND statuspsikotest='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      &nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Date Event</th>
                                            <th class="text-center">Screening CV</th>
                                            <th class="text-center">Psikotest</th>
                                            <th class="text-center">Inteview HR</th>
                                            <th class="text-center">Inteview User</th>
                                            <th class="text-center">Aksi </th>
                                                
                                        </tr>
                                    </thead>
                                    <tbody>

<?php

include "config/conn.php";
$no=1;
	$sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.gender, a.tgllahir, 
                CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.status
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                WHERE a.status='Inproses' AND a.statuspull='ok'";
        $hasil1=  mysql_query($sql);
	
        while($rsa= mysql_fetch_object($hasil1)){
                                        
?>                                        <tr class="odd gradeX">
                                            <?php 
                                                /*
                                                echo "<td> $rsa[applicantid]</td>";
                                                echo "<td> $rsa[nama]</td>";
                                                echo "<td> $rsa[tgllahir]</td>";
                                                echo "<td> $rsa[komunikasi]</td>";
                                                echo "<td> $rsa[email]</td>";
                                                echo "<td> $rsa[leveledukasi]</td>";
                                                echo "<td> $rsa[jurusan]</td>";
                                                echo "<td> $rsa[position]</td>";
                                                echo "<td> $rsa[functionalarea]</td>";
                                                //echo "<td> $rsa[status]</td>";
                                               */

                                            $appid=$rsa->applicantid;
                                            echo '<td><a data-toggle="modal" href="#myPsiOk">'.$rsa->applicantid.'<input type="hidden" name="txtempno[]" id="txtempno[]" size="6" value="'.$rsa->applicantid.'"></a></td>';
                                            echo'<td>'.$rsa->nama.'</td>';
                                            echo'<td>'.$rsa->tgllahir.'</td>';
                                            echo'<td>'.$rsa->komunikasi.'</td>'; 
                                            echo'<td>'.$rsa->email.'</td>';
                                            echo'<td>'.$rsa->leveledukasi.'</td>';
                                            echo'<td>'.$rsa->jurusan.'</td>';
                                            echo'<td>'.$rsa->position.'</td>';
                                            echo'<td><input type="text" name="txttgl[]" id="txttgl[]" size="6" value=""></td>';
                                            echo'<td align=center>'.$rsa->statuspull.'</td>';
                                            echo'<td align=center>'.$rsa->statuspsikotest.'</td>';
                                            echo'<td align=center>'.$rsa->statusinterviewhr.'</td>';
                                            echo'<td align=center>'.$rsa->statusinterviewuser.'</td>';
                                            
//                                           $status=$rsa->status;
//                                           $sd =$rsa->applicantid;
//                                            if($status='Step2'){
//                                                
//                                                echo ' <td><a href="?module=simpan&act=updatescreening&od=tolak&id=$sd"><i class="fa fa-thumbs-down text-success"></i></a>
//                                                    <a href="?module=simpan&act=updatescreening&od=poolled"><i class="fa fa-thumbs-up text-success"></i></a></td>';
//                                            }
//                                            else{
//                                                echo '<td>$status</td>';
//                                                
//                                            }
//                                                
                                            
                                          
                                         echo '<td align=center><input type="checkbox" name="item[]" id="item[]" value="'.$rsa->applicantid.'" /></td>';?>
                                         <!-- <td><input class="checkbox" type="checkbox" name="item[]" id="item[]" value=""></td> -->
</tr>

<?php }
?>

                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Screening CV</th>
                                             <th class="text-center">Psikotest</th>
                                             <th class="text-center">Inteview HR</th>
                                            <th class="text-center">Inteview User</th>
                                           
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </form>
      </div>
    
            
            
  <?php } 
      
      
      // Overview Screening Interview HR-->
      
       if($_GET['act']=="view_interviewhr"){
    
          echo "<form method='post' name='form_data' action='?module=simpan&act=update_appsinthr' onSubmit='return confirm('Anda ingin Mapping Produk terChoice')'>";
	?>
        
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                  <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Applicant Info</h3>
                                  <div class="pull-right hidden-xs">
                                        Select All &nbsp;<input class="fa fa-check-circle" type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>&nbsp;
<!--                                      | Interview HR 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep2'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step3'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>-->
                                      | Interview User 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolakinterviewuser" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statusinterviewuser='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terimainterviewuser" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statusinterviewuser='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
<!--                                      | Psikotest 
                                      <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep4'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step5'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>-->
                                      &nbsp;&nbsp;
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Psikotest</th>
                                            <th class="text-center">Interview HR</th>
                                            <th class="text-center">Aksi </th>
                                                
                                        </tr>
                                    </thead>
                                    <tbody>

<?php

include "config/conn.php";
$no=1;
	$sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.tgllahir, CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.statuspsikotest, a.statusinterviewhr
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                WHERE a.statusinterviewhr='ok' AND a.statusinterviewuser='belum'";
        $hasil1=  mysql_query($sql);
	
        while($rsa= mysql_fetch_object($hasil1)){
                                        
?>                                        <tr class="odd gradeX">
                                            <?php 
                                                /*
                                                echo "<td> $rsa[applicantid]</td>";
                                                echo "<td> $rsa[nama]</td>";
                                                echo "<td> $rsa[tgllahir]</td>";
                                                echo "<td> $rsa[komunikasi]</td>";
                                                echo "<td> $rsa[email]</td>";
                                                echo "<td> $rsa[leveledukasi]</td>";
                                                echo "<td> $rsa[jurusan]</td>";
                                                echo "<td> $rsa[position]</td>";
                                                echo "<td> $rsa[functionalarea]</td>";
                                                //echo "<td> $rsa[status]</td>";
                                               */

                                            
                                            echo '<td>'.$rsa->applicantid.'</td>';
                                            echo'<td>'.$rsa->nama.'</td>';
                                            echo'<td>'.$rsa->tgllahir.'</td>';
                                            echo'<td>'.$rsa->komunikasi.'</td>'; 
                                            echo'<td>'.$rsa->email.'</td>';
                                            echo'<td>'.$rsa->leveledukasi.'</td>';
                                            echo'<td>'.$rsa->jurusan.'</td>';
                                            echo'<td>'.$rsa->position.'</td>';
                                            echo'<td>'.$rsa->functionalarea.'</td>';
                                            echo'<td align=center>'.$rsa->statuspsikotest.'</td>';
                                            echo'<td align=center>'.$rsa->statusinterviewhr.'</td>';
                                            //echo'<td>'.$rsa->status.'</td>';
//                                           $status=$rsa->status;
//                                           $sd =$rsa->applicantid;
//                                            if($status='Step2'){
//                                                
//                                                echo ' <td><a href="?module=simpan&act=updatescreening&od=tolak&id=$sd"><i class="fa fa-thumbs-down text-success"></i></a>
//                                                    <a href="?module=simpan&act=updatescreening&od=poolled"><i class="fa fa-thumbs-up text-success"></i></a></td>';
//                                            }
//                                            else{
//                                                echo '<td>$status</td>';
//                                                
//                                            }
//                                                
                                            
                                          
                                         echo '<td align=center><input type="checkbox" name="item[]" id="item[]" value="'.$rsa->applicantid.'" /></td>';?>
                                         <!-- <td><input class="checkbox" type="checkbox" name="item[]" id="item[]" value=""></td> -->
</tr>

<?php }
?>

                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Psikotest</th>
                                            <th class="text-center">Interview HR</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </form>
      </div>
    
            
            
  <?php } ?>
      
      
      
      
      
      <!-- End Overview Screening Interview HR -->
      
      
      
        <?php 
        //interview User
        
        if($_GET['act']=="view_interviewuser"){
    
          echo "<form method='post' name='form_data' action='?module=app_screening&act=reg_mcu' onSubmit='return confirm('Anda ingin Mapping Produk terChoice')'>";
	?>
        
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                  <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Applicant Info</h3>
                                  <div class="pull-right hidden-xs">
                                        Select All &nbsp;<input class="fa fa-check-circle" type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>&nbsp;
                                      | Test Kesehatan 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-sign-in"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep2'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
<!--                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-signal"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step3'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                             
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      | Interview User 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep3'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                 
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step4'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      | Psikotest 
                                      <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep4'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step5'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>-->
                                      &nbsp;&nbsp;
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Psikotest</th>
                                            <th class="text-center">Interview HR</th>
                                            <th class="text-center">Interview User</th>
                                            <th class="text-center">Aksi </th>
                                                
                                        </tr>
                                    </thead>
                                    <tbody>

<?php

include "config/conn.php";
$no=1;
	$sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.tgllahir, CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.status, a.statuspull, a.statusinterviewuser, a.statusinterviewhr, a.statuspsikotest
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                WHERE a.statusinterviewuser='ok'";
        $hasil1=  mysql_query($sql);
	
        while($rsa= mysql_fetch_object($hasil1)){
                                        
?>                                        <tr class="odd gradeX">
                                            <?php 
                                                /*
                                                echo "<td> $rsa[applicantid]</td>";
                                                echo "<td> $rsa[nama]</td>";
                                                echo "<td> $rsa[tgllahir]</td>";
                                                echo "<td> $rsa[komunikasi]</td>";
                                                echo "<td> $rsa[email]</td>";
                                                echo "<td> $rsa[leveledukasi]</td>";
                                                echo "<td> $rsa[jurusan]</td>";
                                                echo "<td> $rsa[position]</td>";
                                                echo "<td> $rsa[functionalarea]</td>";
                                                //echo "<td> $rsa[status]</td>";
                                               */

                                            
                                            echo '<td>'.$rsa->applicantid.'</td>';
                                            echo'<td>'.$rsa->nama.'</td>';
                                            echo'<td>'.$rsa->tgllahir.'</td>';
                                            echo'<td>'.$rsa->komunikasi.'</td>'; 
                                            echo'<td>'.$rsa->email.'</td>';
                                            echo'<td>'.$rsa->leveledukasi.'</td>';
                                            echo'<td>'.$rsa->jurusan.'</td>';
                                            echo'<td>'.$rsa->position.'</td>';
                                            echo'<td>'.$rsa->functionalarea.'</td>';
                                            echo'<td align=center>'.$rsa->statuspsikotest.'</td>';
                                            echo'<td align=center>'.$rsa->statusinterviewhr.'</td>';
                                            echo'<td align=center>'.$rsa->statusinterviewuser.'</td>';
                                           
                                          
                                         echo '<td align=center><input type="checkbox" name="item[]" id="item[]" value="'.$rsa->applicantid.'" /></td>';?>
                                         <!-- <td><input class="checkbox" type="checkbox" name="item[]" id="item[]" value=""></td> -->
</tr>

<?php }
?>

                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Psikotest</th>
                                            <th class="text-center">Interview HR</th>
                                            <th class="text-center">Interview User</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </form>
      </div>
    
            
            
  <?php } 
       // end interview user -->
        
       // psikotest
        if($_GET['act']=="view_psikotest"){
    
          echo "<form method='post' name='form_data' action='?module=simpan&act=update_appspsi' onSubmit='return confirm('Anda ingin Mapping Produk terChoice')'>";
	?>
        
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                  <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Applicant Info</h3>
                                  <div class="pull-right hidden-xs">
                                        Select All &nbsp;<input class="fa fa-check-circle" type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>&nbsp;
                                      | Interview HR 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolakinthr" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statusinterviewhr='tolak'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terimainthr" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE statusinterviewhr='ok'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
<!--                                  | Interview User 
                                    <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                        <i class="fa fa-thumbs-down"></i> 
                                        <span class="badge" >
                                        <?php
                                             $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep3'";
                                             $hasil1=  mysql_query($hitung);
                                             $rs=  mysql_fetch_array($hasil1);
                                           
                                             echo "$rs[jml]";
                                        ?>
                                        </span> 
                                    </button>

                                    <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                        <i class="fa fa-thumbs-up"></i> 
                                        <span class="badge" >
                                        <?php
                                             $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step4'";
                                             $hasil1=  mysql_query($hitung);
                                             $rs=  mysql_fetch_array($hasil1);
                                         
                                             echo "$rs[jml]";
                                        ?>
                                        </span> 
                                    </button>-->
<!--                                      | Psikotest 
                                      <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep4'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                                
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>-->
                                      
<!--                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step5'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                              
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>-->
                                      &nbsp;&nbsp;
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status Psikotest</th>
                                            <th class="text-center">Aksi </th>
                                                
                                        </tr>
                                    </thead>
                                    <tbody>

<?php

include "config/conn.php";
$no=1;
	$sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.tgllahir, CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.status, a.statusinterviewhr, a.statusinterviewuser, a.statuspsikotest 
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                WHERE a.statuspull='ok' AND statuspsikotest='ok' AND statusinterviewhr='belum'";
        $hasil1=  mysql_query($sql);
	
        while($rsa= mysql_fetch_object($hasil1)){
                                        
?>                                        <tr class="odd gradeX">
                                            <?php 
                                                /*
                                                echo "<td> $rsa[applicantid]</td>";
                                                echo "<td> $rsa[nama]</td>";
                                                echo "<td> $rsa[tgllahir]</td>";
                                                echo "<td> $rsa[komunikasi]</td>";
                                                echo "<td> $rsa[email]</td>";
                                                echo "<td> $rsa[leveledukasi]</td>";
                                                echo "<td> $rsa[jurusan]</td>";
                                                echo "<td> $rsa[position]</td>";
                                                echo "<td> $rsa[functionalarea]</td>";
                                                //echo "<td> $rsa[status]</td>";
                                               */

                                            
                                            echo '<td>'.$rsa->applicantid.'</td>';
                                            echo'<td>'.$rsa->nama.'</td>';
                                            echo'<td>'.$rsa->tgllahir.'</td>';
                                            echo'<td>'.$rsa->komunikasi.'</td>'; 
                                            echo'<td>'.$rsa->email.'</td>';
                                            echo'<td>'.$rsa->leveledukasi.'</td>';
                                            echo'<td>'.$rsa->jurusan.'</td>';
                                            echo'<td>'.$rsa->position.'</td>';
                                            echo'<td>'.$rsa->functionalarea.'</td>';
                                            echo'<td align=center>'.$rsa->statuspsikotest.'</td>';
                                            //echo'<td>'.$rsa->status.'</td>';
//                                           $status=$rsa->status;
//                                           $sd =$rsa->applicantid;
//                                            if($status='Step2'){
//                                                
//                                                echo ' <td><a href="?module=simpan&act=updatescreening&od=tolak&id=$sd"><i class="fa fa-thumbs-down text-success"></i></a>
//                                                    <a href="?module=simpan&act=updatescreening&od=poolled"><i class="fa fa-thumbs-up text-success"></i></a></td>';
//                                            }
//                                            else{
//                                                echo '<td>$status</td>';
//                                                
//                                            }
//                                                
                                            
                                          
                                         echo '<td align=center><input type="checkbox" name="item[]" id="item[]" value="'.$rsa->applicantid.'" /></td>';?>
                                         <!-- <td><input class="checkbox" type="checkbox" name="item[]" id="item[]" value=""></td> -->
</tr>

<?php }
?>

                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status Psikotest</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </form>
      </div>
    
            
            
  <?php } 
  
  
       //end psikotest
  
    /*
        Overview Screening Applicant
    */
if($_GET['act']=="view_screeningpanggil"){
    
	?>
        
              <form method='post' name='form_data' action='?module=simpan&act=update_appscreening' onSubmit='return confirm('Anda ingin Mapping Produk terChoice')'>
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                  <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Applicant Info</h3>
                                  <div class="pull-right hidden-xs">
                                        Select All &nbsp;<input class="fa fa-check-circle" type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>&nbsp;
                                      | Screening <a href="?module=simpan&act=update_appscreening&od='tolak'"><i class="fa fa-thumbs-down text-success"></i></a>
                                      <a href="?module=simpan&act=input_appscreening"><i class="fa fa-thumbs-up text-success"></i></a>
                                      | Interview <a href="?module=simpan&act=input_appscreening"><i class="fa fa-thumbs-down text-success"></i></a>
                                      <a href="?module=simpan&act=input_appscreening"><i class="fa fa-thumbs-up text-success"></i></a>
                                      | Psikotest <a href="?module=simpan&act=input_appscreening"><i class="fa fa-thumbs-down text-success"></i></a>
                                      <a href="?module=simpan&act=input_appscreening"><i class="fa fa-thumbs-up text-success"></i></a>
                                      |<a href="?module=app_widget"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi </th>
                                                
                                        </tr>
                                    </thead>
                                    <tbody>

<?php

include "config/conn.php";
$no=1;
	$sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.tgllahir, CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.status
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                WHERE a.status='step3'";
        $hasil1=  mysql_query($sql);
	
        while($rsa= mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <?php 
                                                echo "<td> $rsa[applicantid]</td>";
                                                echo "<td> $rsa[nama]</td>";
                                                echo "<td> $rsa[tgllahir]</td>";
                                                echo "<td> $rsa[komunikasi]</td>";
                                                echo "<td> $rsa[email]</td>";
                                                echo "<td> $rsa[leveledukasi]</td>";
                                                echo "<td> $rsa[jurusan]</td>";
                                                echo "<td> $rsa[position]</td>";
                                                echo "<td> $rsa[functionalarea]</td>";
                                                //echo "<td> $rsa[status]</td>";
                                               

                                            
                                            //echo '<td>'.$rsa->applicantid.'</td>';
                                            //echo'<td>'.$rsa->nama.'</td>';
                                            //echo'<td>'.$rsa->tgllahir.'</td>';
                                            //echo'<td>'.$rsa->komunikasi.'</td>'; 
                                            //echo'<td>'.$rsa->email.'</td>';
                                            //echo'<td>'.$rsa->leveledukasi.'</td>';
                                            //echo'<td>'.$rsa->jurusan.'</td>';
                                            //echo'<td>'.$rsa->position.'</td>';
                                            //echo'<td>'.$rsa->functionalarea.'</td>';
                                            //echo'<td>'.$rsa->status.'</td>';
                                           $status=$rsa[status];
                                           $sd =$rsa[applicantid];
                                            if($status='Step1'){
                                                
                                                echo ' <td><a href="?module=simpan&act=updatescreening&od=tolak&id=$sd"><i class="fa fa-thumbs-down text-success"></i></a>
                                                    <a href="?module=simpan&act=updatescreening&od=poolled"><i class="fa fa-thumbs-up text-success"></i></a></td>';
                                            }
                                            else{
                                                echo '<td>$status</td>';
                                                
                                            }
                                                
                                            
                                          
                                         //echo '<td align=center><input type="chepckbox" name="item[]" id="item[]" value="'.$rsa->applicantid.'" /></td>';?>
                                         <td><input class="checkbox" type="checkbox" name="item[]" id="item[]" value="<?php echo $rsa[applicantid]; ?>"></td>
</tr>

<?php }
?>

                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </form>
      </div>
      <?php }
      if($_GET['act']=="reg_mcu"){
        $ad=$_POST["item"];
        
        $jumlah = count($_POST["item"]);
        
        $pw=md5($_POST['pass']);
        $status=$_POST['btnsubmit'];
      
          echo "<form method='post' name='form_data' action='?module=simpan&act=daftar_mcu' onSubmit='return confirm('Anda ingin Mapping Produk terChoice')'>";
	?>
        
              
          <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
                  <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Medical Check Up Register</h3>
                                  <div class="pull-right hidden-xs">
                                        Select All &nbsp;<input class="fa fa-check-circle" type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>&nbsp;
                                      |  
                                         <button type="submit" name="btnsubmit" class="btn " value="prepare" >
                                           Save
                                            <span class="badge" >
                                                 <i class="fa fa-save"></i> 
                                            </span> 
                                       </button>&nbsp;&nbsp;&nbsp;&nbsp;
                                      
<!--                                        <button type="submit" name="btnsubmit" class="btn " value="prepare" >
                                            <i class="fa fa-signal"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step3'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      | Interview User 
                                        <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep3'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                             
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step4'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                             
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      | Psikotest 
                                      <button type="submit" name="btnsubmit" class="btn " value="tolak" >
                                            <i class="fa fa-thumbs-down"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='tolakstep4'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                             
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>
                                      
                                        <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                            <i class="fa fa-thumbs-up"></i> 
                                            <span class="badge" >
                                            <?php
                                                 $hitung="SELECT  COUNT(applicantid)as jml FROM applicant_personal WHERE status='step5'";
                                                 $hasil1=  mysql_query($hitung);
                                                 $rs=  mysql_fetch_array($hasil1);
                                               
                                                 echo "$rs[jml]";
                                            ?>
                                            </span> 
                                        </button>-->
                                      &nbsp;&nbsp;
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Tgl MCU</th>
                                            <th class="text-center">Vendor</th>
                                            <th class="text-center">Remark</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi </th>
                                                
                                        </tr>
                                    </thead>
                                    <tbody>

<?php
        
        
         for($i=0; $i < $jumlah; $i++) 
            {
                $id=$_POST["item"][$i];

               $sql1 ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.tgllahir, CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.status
                FROM applicant_personal a
                LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid
                       where a.applicantid = '$id'";
                            $hasil = mysql_query($sql1);
                            WHILE($rsa= mysql_fetch_object($hasil))
                            {
                            
                                        
?>                                        <tr class="odd gradeX">
                                            <?php 
                                                /*
                                                echo "<td> $rsa[applicantid]</td>";
                                                echo "<td> $rsa[nama]</td>";
                                                echo "<td> $rsa[tgllahir]</td>";
                                                echo "<td> $rsa[komunikasi]</td>";
                                                echo "<td> $rsa[email]</td>";
                                                echo "<td> $rsa[leveledukasi]</td>";
                                                echo "<td> $rsa[jurusan]</td>";
                                                echo "<td> $rsa[position]</td>";
                                                echo "<td> $rsa[functionalarea]</td>";
                                                //echo "<td> $rsa[status]</td>";
                                               */

                                            
                                            echo '<td>'.$rsa->applicantid.'</td>';
                                            echo'<td>'.$rsa->nama.'</td>';
                                            echo'<td>'.$rsa->tgllahir.'</td>';
                                            echo'<td>'.$rsa->komunikasi.'</td>'; 
                                            echo'<td>'.$rsa->email.'</td>';
                                            echo"<td><input class='form-control' type='text' name='txttglmcu[]' id='txttglmcu[]'>
                                                </td>";
                                           
                                           echo '<td><SELECT name="txtvendor[]" id="txtvendor[]">';
                                             $carivendor="SELECT id_vendor, namavendor, cabang FROM t_vendormcu WHERE validto > now() ";
                                            $hasilcari=  mysql_query($carivendor);
                                            while ($rsi= mysql_fetch_object($hasilcari)){
                                                       echo'<OPTION VALUE='.$rsi->id_vendor.'>'.$rsi->namavendor.'-'.$rsi->cabang.'</OPTION>';
                                                    }
                                            echo'</SELECT></td><td><input type=text name="txtremark[]" id="txtremark[]"> </td>';
                                           
                                            echo'<td>prepare</td>';
                                             
                                            
                                          
                                         echo '<td align=center><input type="checkbox" name="item[]" id="item[]" value="'.$rsa->applicantid.'" /></td>';
                           }
                                         ?>
                                         <!-- <td><input class="checkbox" type="checkbox" name="item[]" id="item[]" value=""></td> -->
</tr>

<?php } 
?>

                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Tgl Mcu</th>
                                            <th class="text-center">Vendor</th>
                                            <th class="text-center">Remark</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
      </form>
      </div>
    
            
            
  <?php } ?>
       
    <!-- Modal Terima psi -->
                  <div id="myPsiOk" class="modal fade " role="dialog">
                  <div class="modal-dialog modal-lg">

                    
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Details Psikotest</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewposition">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'>$rsd[tahun]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   <br><br>
                                                &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                                            <label>Position Level :</label>
                                            <select id="txtposlevel" name="txtposlevel" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT poslevel FROM `position_mapping` GROUP BY poslevel";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[poslevel]'>$rsd[poslevel]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>  
                                            
                                        </form>
                                      
                            
                           
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  
                  </div>
                </div>
                    
                    <!-- End Modal Position -->  

      <!-- DATA TABES SCRIPT -->
    <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>
    
    
</BODY>
</HTML>
