<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include "conn.php";
$idnya=$_GET['q'];
$idactivity=$_GET[txteventmethod];

$jurusan = "SELECT idrec_activity, eventid, tempat, kontakperson,kontakno, startdate, enddate, pic, keterangan, istatus "
                                                                    . " FROM recruitment_activity WHERE idrec_activity='$idnya' ORDER BY startdate";
        
$hasilambil1=mysql_query($jurusan);

echo "<table border='0' cellspading='2' rospading='5'>"
. "";
while($k = mysql_fetch_array($hasilambil1)){
    echo "<tr><td>&nbsp Tempat  </td><td>:</td> <td>&nbsp".$k['tempat']."&nbsp</td></tr>";
    
    echo "<tr><td>&nbsp Start Date &nbsp </td><td>:</td><td>&nbsp".$k['startdate']."&nbsp</td></tr>";
    echo "<tr><td>&nbsp End Date </td><td>:</td><td>&nbsp".$k['enddate']."&nbsp</td></tr>";
    echo "<tr><td>&nbsp PIC </td><td>:</td><td>&nbsp".$k['pic']."&nbsp</td></tr>";
    echo "<tr><td>&nbsp Status </td><td>:</td><td>&nbsp".$k['istatus']."&nbsp</td></tr>";
}