<?php
include "config/conn.php";

if($_GET['act']=="input_user"){
$pw=md5($_POST['pass']);
mysql_query("INSERT INTO user(nama,pass,level,id) 
VALUES(
'$_POST[nama]',
'$pw',
'admin_guru','$_POST[sekolah]')");
echo "<script>window.alert('Data Tersimpan');
        window.location=('../media.php?module=user')</script>";

}

//Simpan Organization Level
if($_GET['act']=="input_orglevel"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO organization_level(orglevelname,orglevel,keterangan) 
        VALUES(
        '$_POST[txtorglevelname]',
            '$_POST[txtorglevel]',
         '$_POST[txtketerangan]')");
        echo "<script>window.alert('Data Tersimpan');
                window.location=('?module=orglevel&act=input')</script>";

}

//Update Organization Level
if($_GET['act']=="edit_orglevel"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        $updateorglevel =" UPDATE organization_level SET
                        orglevelname = '$_POST[txtorglevelname]',
                        orglevel = '$_POST[txtorglevel]',       
                        keterangan = '$_POST[txtketerangan]'";
        $masuk=  mysql_query($updateorglevel);
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_organization&act=view_organization/&id=$id')</script>";

}

//Hapus Organization Level
if($_GET['act']=="hapus_orglevel"){
mysql_query("delete from organization_level where orglevelname='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_organization')</script>";
}

//Simpan Organization Struktur
if($_GET['act']=="input_orgstruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        mysql_query("INSERT INTO organization_struktur(orgcode, org_name, parent_orgcode, costcenter, validfrom, validto) 
        VALUES(
        '$_POST[txtorgcode]',
             '$_POST[txtorgname]',
             '$_POST[txtparentorgcode]',
             '$_POST[txtcostcenter]',
             '$_POST[txtvalidfrom]',
         '$_POST[txtvalidto]')");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=orgstruktur&act=view&id=$id')</script>";

}

//Update Organization Struktur
if($_GET['act']=="edit_orgstruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        $org_name = $_POST[txtorgname];
        $parent_orgcode = $_POST[txtparentorgcode];
        $costcenter = $_POST[txtcostcenter];    
        $validfrom = $_POST[txtvalidfrom];    
        $validto = $_POST[txtvalidto];
        
        $updateorgstruktur ="UPDATE organization_struktur SET
                        org_name = '$_POST[txtorgname]',
                        parent_orgcode = '$_POST[txtparentorgcode]',       
                        costcenter = '$_POST[txtcostcenter]',    
                        validfrom = '$_POST[txtvalidfrom]',    
                        validto = '$_POST[txtvalidto]' WHERE orgcode='$id'";
        $masuk=  mysql_query($updateorgstruktur);
        
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
        window.location=('?module=view_organization&act=view_orgstruktur')</script>";

}

//Hapus Organization Struktur
if($_GET['act']=="hapus_orgstruktur"){
mysql_query("delete from organization_struktur where orgcode='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_organization&act=view_orgstruktur')</script>";
}

//Simpan Company Category

if($_GET['act']=="input_compcat"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        mysql_query("INSERT INTO company_category(Nm_comp_category, keterangan) 
        VALUES(
        '$_POST[txtcompcat]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_company&act=view_companycat&id=$id')</script>";

}


//Hapus Company Category
if($_GET['act']=="hapus_compcat"){
mysql_query("delete from company_category where Nm_comp_category='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_company&act=view_companycat')</script>";
}




//Update Company Category

if($_GET['act']=="edit_compcat"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        $updatecompcat =" UPDATE company_category SET
                        Nm_comp_category = '$_POST[txtcompcat]',
                        keterangan = '$_POST[txtketerangan]'";       
                        $masuk=  mysql_query($updatecompcat);
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_company&act=view_companycat')</script>";

}

//Simpan Company Office Group

if($_GET['act']=="input_compoffgroup"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffgroup];
        mysql_query("INSERT INTO company_office_group(Nm_comp_group, keterangan) 
        VALUES(
        '$_POST[txtcompoffgroup]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_company&act=view_companygroup&id=$id')</script>";

}

//Update Company Office Group

if($_GET['act']=="edit_compoffgroup"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffgroup];
        $updatecompoffgroup =" UPDATE company_office_group SET
                        Nm_comp_group = '$_POST[txtcompoffgroup]',
                        keterangan = '$_POST[txtketerangan]'";       
                        $masuk=  mysql_query($updatecompoffgroup);
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_company&act=view_companygroup')</script>";

}


//Hapus Company Office Group
if($_GET['act']=="hapus_compoffgroup"){
mysql_query("delete from company_office_group where Nm_comp_group='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_company&act=view_companygroup')</script>";
}


//Simpan Company Office Details

if($_GET['act']=="input_compoffdetail"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffgroup];
        mysql_query("INSERT INTO company_office_detail(Nm_comp_office,Id_comp_category,Id_comp_group,Address,Nomor_npwp,Nm_cabang_pajak,Fax,Tlp,Validfrom,validto) 
        VALUES(
                '$_POST[txtcompoffname]',
                '$_POST[txtcompoffcat]',
                '$_POST[txtcompoffgroup]',
                '$_POST[txtaddress]',
                '$_POST[txtnpwp]',
                '$_POST[txtkantorpajak]',
                '$_POST[txtfax]',
                '$_POST[txttelpon]',
                '$_POST[txtvalidfrom]',
                '$_POST[txtvalidto]'    
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_company&act=view_companyoffdetail&ilid=$id')</script>";

}

//Update Company Office Detil

if($_GET['act']=="edit_compoffdetail"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtcompoffname];
        $updatecompoffdetail =" UPDATE company_office_detail SET
                                Nm_comp_office      =   '$_POST[txtcompoffname]',
                                Id_comp_category    =   '$_POST[txtcompoffcat]',
                                Id_comp_group       =   '$_POST[txtcompoffgroup]',
                                Address             =   '$_POST[txtaddress]',
                                Nomor_npwp          =   '$_POST[txtnpwp]',
                                Nm_cabang_pajak     =   '$_POST[txtkantorpajak]',
                                Fax                 =   '$_POST[txtfax]',
                                Tlp                 =   '$_POST[txttelpon]',
                                Validfrom           =   '$_POST[txtvalidfrom]',
                                validto             =   '$_POST[txtvalidto]'";       
                            $masuk=  mysql_query($updatecompoffdetail);
                            echo "<br><br> $updatecompoffdetail";            
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_company&act=view_companyoffdetail')</script>";

}
//Hapus Company Office Detail
if($_GET['act']=="hapus_compoffdetail"){
mysql_query("delete from company_office_detail where Nm_comp_office='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_company&act=view_companyoffdetail')</script>";
}






//Simpan Vendor MCU

if($_GET['act']=="input_vendorpsi"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO t_vendorbiropsi(id_vendor,namavendor,cabang, alamat, kontakperson, telpon, hp, email, fax, npwp, norek, validfrom, validto) 
        VALUES('',
        '$_POST[txtcostitem]',            
         '$_POST[txtketerangan]')");
        echo " <script>window.alert('Terima kasih, Data telah Tersimpan');
                window.location=('?module=psi_vendor&act=input')</script>";

}


//input job family
if($_GET['act']=="input_jobfam"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        mysql_query("INSERT INTO job_family(id_job, job_title, keterangan) 
        VALUES(
        '$_POST[txtjobid]','$_POST[txtjobtitle]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_jobfam&id=$id')</script>";

}

//edit job family
if($_GET['act']=="edit_jobfam"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtjobid];
        $txtjobtitle=$_POST[txtjobtitle];
        $txtketerangan=$_POST[txtketerangan];
        $updatejobfam =" UPDATE job_family SET
                                id_job              =   '$id',
                                job_title           =   '$txtjobtitle',
                                keterangan       =   '$txtketerangan'";       
                            $masuk=  mysql_query($updatejobfam);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_jobfam')</script>";
}
//hapus job family
if($_GET['act']=="hapus_jobfam"){
mysql_query("delete from job_family where id_job='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_jobfam')</script>";
}

//input Functional Area
if($_GET['act']=="input_funcarea"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtfidfuncarea];
        $txtfuncareaname=$_POST[txtfuncareaname];
        $txtketerangan=$_POST[txtketerangan];
        $sql="INSERT INTO functional_area(id_functarea, func_area, keterangan) 
        VALUES(
        '$id','$txtfuncareaname',
             '$txtketerangan'
            )";
        $hasil=mysql_query($sql);
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_funcarea&id=$id')</script>";
}
//edit Functional Area
if($_GET['act']=="edit_funcarea"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtfidfuncarea];
        $txtfuncareaname=$_POST[txtfuncareaname];
        $txtketerangan=$_POST[txtketerangan];
        $updatefuncarea =" UPDATE functional_area SET
                                id_functarea     =   '$id',
                                func_area              =   '$txtfuncareaname',
                                keterangan       =   '$txtketerangan'";       
                            $masuk=  mysql_query($updatefuncarea);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_funcarea')</script>";
}
//hapus Functional Area
if($_GET['act']=="hapus_funcarea"){
mysql_query("delete from functional_area where id_functarea='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_funcarea')</script>";
}

//input Industry Area
if($_GET['act']=="input_posind"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtindname];
        $txtindareaname=$_POST[txtindareaname];
        $txtketerangan=$_POST[txtketerangan];
        $sql="INSERT INTO industry_area(industry_name, industry_area_name, keterangan) 
        VALUES(
        '$id','$txtindareaname',
             '$txtketerangan'
            )";
        $hasil=mysql_query($sql);
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_indarea&id=$id')</script>";
}
//edit Industry Area
if($_GET['act']=="edit_posind"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtindname];
        $txtindareaname=$_POST[txtindareaname];
        $txtketerangan=$_POST[txtketerangan];
        $updateindarea =" UPDATE industry_area SET
                                industry_name       =   '$id',
                                industry_area_name  =   '$txtindareaname',
                                keterangan          =   '$txtketerangan'";       
                            $masuk=  mysql_query($updateindarea);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_indarea')</script>";
}
//hapus Industry Area
if($_GET['act']=="hapus_indarea"){
mysql_query("delete from industry_area where industry_name='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_indarea')</script>";
}




//input Position Struktur

if($_GET['act']=="input_postruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtorgcode];
        mysql_query("INSERT INTO position_sturktur(id_position, position_title, position_summary,position_class,direct_superior,job_id,organization_code,validfrom,validto) 
        VALUES(
        '$_POST[txtposid]','$_POST[txtpostitle]','$_POST[txtpossummary]','$_POST[txtposclass]','$_POST[txtposiddir]',
         '$_POST[txtjobid]','$_POST[txtorgcode]','$_POST[txtvalidfrom]','$_POST[txtvalidto]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_posstruktur&id=$id')</script>";

}
//edit Position Struktur
if($_GET['act']=="edit_postruktur"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtposid];
        $updatepostruktur =" UPDATE position_struktur SET
                                id_position              =   '$_POST[txtposid]',
                                position_title           =   '$_POST[txtpostitle]',
                                position_summary              =   '$_POST[txtpossummary]',
                                position_class              =   '$_POST[txtposclass]',
                                direct_superior           =   '$_POST[txtposiddir]',
                                job_id              =   '$_POST[txtjobid]',
                                organization_code           =   '$_POST[txtorgcode]',
                                validfrom           =   '$_POST[txtvalidfrom]',
                                validto       =   '$_POST[txtvalidto]'";       
                            $masuk=  mysql_query($updatepostruktur);
                           
                            
        echo "<script>window.alert('Terima kasih, Data Telah Terupdate');
                window.location=('?module=view_position&act=view_posstruktur')</script>";

}
//hapus Position Struktur
if($_GET['act']=="hapus_postruktur"){
mysql_query("delete from position_struktur where id_position='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_posstruktur')</script>";
}

//input Position Class
if($_GET['act']=="input_posclass"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtposclass];
        mysql_query("INSERT INTO position_class(posclass, keterangan) 
        VALUES(
        '$_POST[txtposclass]',
             '$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih, Data Telah Tersimpan');
                window.location=('?module=view_position&act=view_posclass&id=$id')</script>";

}

//edit Position Class
if($_GET['act']=="edit_posclass"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtposclass];
        $id2=$_POST[txtketerangan];
        
        $updateposclass =" UPDATE position_class SET
                                posclass         =   '$_POST[txtposclass]',
                                keterangan       =   '$id2'";       
                            $masuk=  mysql_query($updateposclass);
                            
        
       echo "$updateposclass <script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_position&act=view_posclass')</script>";
}
//hapus Position Class
if($_GET['act']=="hapus_posclass"){
mysql_query("delete from position_class where posclass='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_position&act=view_posclass')</script>";
}

//Simpan Recruitment Cost Item

if($_GET['act']=="input_costitem"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO t_rec_costitem(id,costitem,keterangan) 
        VALUES('',
        '$_POST[txtvendormcu]','$_POST[txtkota]','$_POST[txtalamat]','$_POST[txtkontak]','$_POST[txttelpon]','$_POST[txthp]','$_POST[txtemail]',
            '$_POST[txtfax]','$_POST[txtnpwp]','$_POST[txtnorek]','$_POST[txtvalidfrom]','$_POST[txtvalidto]'
         )");
        echo " <script>window.alert('Terima kasih, Data telah Tersimpan');
                window.location=('?module=mcu_vendor&act=input')</script>";

}

//input Recruitment Base Event
if($_GET['act']=="input_recevent"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txteventid];
        mysql_query("INSERT INTO recruitment_event(idevent,namaevent,keterangan, validfrom, validto) 
        VALUES(
        '$_POST[txteventid]','$_POST[txtnamaevent]',
             '$_POST[txtketerangan]','$_POST[txtvalidfrom]','$_POST[txtvalidto]'
            )");
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_recbase&act=view_recevent&id=$id')</script>";
}
//edit Recruitment Base Event
if($_GET['act']=="edit_recevent"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txteventid];
        $txtnamaevent=$_POST[txtnamaevent];
        $txtketerangan=$_POST[txtketerangan];
        $txtvalidfrom=$_POST[txtvalidfrom];
        $txtvalidto=$_POST[txtvalidto];
        
        $updaterecevent =" UPDATE recruitment_event SET
                                namaevent         =   '$txtnamaevent',
                                keterangan         =   '$txtketerangan',
                                validfrom         =   '$txtvalidfrom',
                                validto         =   '$txtvalidto'    
                                WHERE idevent  =   '$id'";       
                            $masuk=  mysql_query($updaterecevent);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_recevent')</script>";
}
//hapus Recruitment Base Event
if($_GET['act']=="hapus_recevent"){
mysql_query("delete from recruitment_event where idevent='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_recevent')</script>";
}

//input Recruitment Base Method
if($_GET['act']=="input_recmethod"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txteventid];
        mysql_query("INSERT INTO recruitment_method(idrecmethod,recmethodname,recmethodgroup, keterangan) 
        VALUES(
        '$_POST[txtidrecmethod]','$_POST[txtrecmethodname]',
             '$_POST[txtrecmethodgroup]','$_POST[txtketerangan]'
            )");
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_recbase&act=view_recmethod&id=$id')</script>";
}
//edit Recruitment Base Method
if($_GET['act']=="edit_recmethod"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtidrecmethod];
        $txtnamaevent=$_POST[txtrecmethodname];
        $txtrecmethodgroup=$_POST[txtrecmethodgroup];
        $txtketerangan=$_POST[txtketerangan];
        $updaterecmethod =" UPDATE recruitment_method SET
                                recmethodname    =   '$txtnamaevent',
                                recmethodgroup   =   '$txtrecmethodgroup',
                                keterangan   =   '$txtketerangan' 
                                WHERE idrecmethod  =   '$id'";       
                            $masuk=  mysql_query($updaterecmethod);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_recmethod')</script>";
}
//hapus Recruitment Base Method
if($_GET['act']=="hapus_recmethod"){
mysql_query("delete from recruitment_method where idrecmethod='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_recmethod')</script>";
}
//input Recruitment Base Periode
if($_GET['act']=="input_recperiode"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtrecperiode];
        mysql_query("INSERT INTO recruitment_periode(recperiode,periode,validfrom, validto) 
        VALUES(
        '$_POST[txtrecperiode]','$_POST[txtperiode]',
             '$_POST[txtvalidfrom]','$_POST[txtvalidto]'
            )");
        echo "<script>window.alert('Terima kasih yaa, Data Telah Tersimpan');
                window.location=('?module=view_recbase&act=view_recperiode&id=$id')</script>";
}
//edit Recruitment Base Periode
if($_GET['act']=="edit_recperiode"){
        $pw=md5($_POST['pass']);
        $id=$_POST[txtrecperiode];
        $txtperiode=$_POST[txtperiode];
        $txtvalidfrom=$_POST[txtvalidfrom];
        $txtvalidto=$_POST[txtvalidto];
        $updaterecperiode =" UPDATE recruitment_periode SET
                                periode    =   '$txtperiode',
                                validfrom   =   '$txtvalidfrom',
                                validto   =   '$txtvalidto' 
                                WHERE recperiode  =   '$id'";       
                            $masuk=  mysql_query($updaterecperiode);
                            
        
       echo "<script>window.alert(' Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_recbase&act=view_recperiode')</script>";
}
//hapus Recruitment Base Periode
if($_GET['act']=="hapus_recperiode"){
mysql_query("delete from recruitment_periode where recperiode='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_recbase&act=view_recperiode')</script>";
}
//Input Vendor MCU

if($_GET['act']=="input_vendormcu"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO t_vendormcu(id_vendor,namavendor,cabang, alamat, telpon, email, fax, norek, validfrom, validto) 
        VALUES('',
        '$_POST[txtvendormcu]',  
        '$_POST[txtkota]',  
        '$_POST[txtalamat]',          
        '$_POST[txttelpon]',  
        '$_POST[txtemail]',  
        '$_POST[txtfax]',          
        '$_POST[txtnorek]',
        '$_POST[txtvalidfrom]',
        '$_POST[txtvalidto]')");
        echo " <script>window.alert('Terima kasih, Data telah Tersimpan');
                window.location=('?module=view_vendor&act=view_medcheckup')</script>";

}


//edit MCU 
if($_GET['act']=="edit_vendormcu"){
        $pw=md5($_POST['pass']);
        
        $id=$_POST[txtidvendormcu];
        $txtvendormcu=$_POST[txtvendormcu];
        $txtkota=$_POST[txtkota];  
        $txtalamat=$_POST[txtalamat];          
        $txttelpon=$_POST[txttelpon];  
        $txtemail=$_POST[txtemail];  
        $txtfax=$_POST[txtfax];          
        $txtnorek=$_POST[txtnorek];
        $txtvalidfrom=$_POST[txtvalidfrom];
        $txtvalidto=$_POST[txtvalidto];
        $updatemcuvendor =" UPDATE t_vendormcu SET
                                namavendor    =   '$txtvendormcu',
                                cabang   =   '$txtkota',
                                alamat   =   '$txtalamat', 
                                telpon   =   '$txttelpon', 
                                email   =   '$txtemail', 
                                fax   =   '$txtfax', 
                                norek   =   '$txtnorek', 
                                validfrom   =   '$txtvalidfrom', 
                                validto   =   '$txtvalidto' 
                                WHERE id_vendor  =   '$id'";       
                            $masuk=  mysql_query($updatemcuvendor);
                            
        
       echo "<script>window.alert('Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_vendor&act=view_medcheckup')</script>";
}
//hapus mcu
if($_GET['act']=="hapus_mcuvendor"){
mysql_query("delete from t_vendormcu where id_vendor='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_vendor&act=view_medcheckup')</script>";
}


//Input psikologi

if($_GET['act']=="input_vendorpsi"){
        $pw=md5($_POST['pass']);
        mysql_query("INSERT INTO t_vendorbiropsi(id_vendor,namavendor,cabang, alamat, telpon, email, fax, norek, validfrom, validto) 
        VALUES('',
        '$_POST[txtvendormcu]',  
        '$_POST[txtkota]',  
        '$_POST[txtalamat]',          
        '$_POST[txttelpon]',  
        '$_POST[txtemail]',  
        '$_POST[txtfax]',          
        '$_POST[txtnorek]',
        '$_POST[txtvalidfrom]',
        '$_POST[txtvalidto]')");
        echo " <script>window.alert('Terima kasih, Data telah Tersimpan');
                window.location=('?module=view_vendor&act=view_biropsi')</script>";

}


//edit psikologi
if($_GET['act']=="edit_vendorpsi"){
        $pw=md5($_POST['pass']);
        
        $id=$_POST[txtidvendormcu];
        $txtvendormcu=$_POST[txtvendormcu];
        $txtkota=$_POST[txtkota];  
        $txtalamat=$_POST[txtalamat];          
        $txttelpon=$_POST[txttelpon];  
        $txtemail=$_POST[txtemail];  
        $txtfax=$_POST[txtfax];          
        $txtnorek=$_POST[txtnorek];
        $txtvalidfrom=$_POST[txtvalidfrom];
        $txtvalidto=$_POST[txtvalidto];
        $updatemcuvendor =" UPDATE t_vendormcu SET
                                namavendor    =   '$txtvendormcu',
                                cabang   =   '$txtkota',
                                alamat   =   '$txtalamat', 
                                telpon   =   '$txttelpon', 
                                email   =   '$txtemail', 
                                fax   =   '$txtfax', 
                                norek   =   '$txtnorek', 
                                validfrom   =   '$txtvalidfrom', 
                                validto   =   '$txtvalidto' 
                                WHERE id_vendor  =   '$id'";       
                            $masuk=  mysql_query($updatemcuvendor);
                            
        
       echo "<script>window.alert('Terima kasih yaa, Data Telah Terupdate');
             window.location=('?module=view_vendor&act=view_medcheckup')</script>";
}
//hapus psikologi
if($_GET['act']=="hapus_vendorpsi"){
mysql_query("delete from t_vendormcu where id_vendor='$_GET[id]'");
echo "<script>window.alert('Data Terhapus');
        window.location=('?module=view_vendor&act=view_medcheckup')</script>";
}

?>
