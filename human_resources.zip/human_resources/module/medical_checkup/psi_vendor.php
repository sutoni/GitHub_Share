 <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Biro Psikology
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_vendor">Vendor</a></li>
            <li class="active">Psikotest</li>
          </ol>
        </section>

<?php
if($_GET['act']=="input"){
	?>
         <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Biro Psikotest</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=psi_vendor&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_vendorpsi">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Nama Vendor</label>
                                            <input class="form-control" placeholder="Nama Vendor Biro Psikolog" name="txtvendormcu" id="txtvendormcu">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Kota</label>
                                            <select class="form-control" name="txtkota" id="txtkota">
                                                <option value="<?php echo $rs[cabang]; ?>"><?php echo $rs[cabang]; ?></option>
                                                <option value="Jakarta">Jakarta</option>
                                                <option value="Bogor">Bogor</option>
                                                <option value="Bekasi">Bekasi</option>
                                                <option value="Depok">Depok</option>
                                                <option value="Tangerang">Tangerang</option>
                                       
                                          </select>
                                        </div>
                                         <div class="form-group">
                                            <label>Alamat</label>
                                            <textarea class="form-control" name="txtalamat" id="txtalamat" rows="3"></textarea>
                                            
                                        </div>
                                    
                                       
                                        
                                        <div class="form-group ">
                                            <label>Nomer Rekening</label>
                                            <input class="form-control" placeholder="Nomer Rekening" name="txtnorek" id="txtnorek">
                                        </div>
                                    
                                 
                                         <div class="form-group col-lg-5">
                                            <label>Fax</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txtfax" id="txtfax">
                                         </div>
                                        <div class="form-group col-lg-5" colspan="0">
                                            <label>Telpon</label>
                                            <input class="form-control" placeholder="+6221-7209510" name="txttelpon" id="txttelpon">
                                        </div>
                                    
                                       
                                    
                                        
                                         <div class="form-group col-lg-10">
                                            <label>Email</label>
                                            <input class="form-control" placeholder="a@usahadong.com" name="txtemail" id="txtemail">
                                        </div>
                                        
                                    <BR>
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                    
                                    <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidto" id="txtvalidto">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                    </div>
                                  <p></p>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        
                                    <br>
                                        <button type="submit" class="btn btn-default col-lg-3">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                           </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
           <?php } ?>
           
      </div>
             