<br><br>
<ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Basic Konfigurasi</a></li>
                    <li><a href="?module=view_vendor&act=view_medcheckup">Vendor</a></li>
                    <li class="active">Overview Vendor</li>
                  </ol>
                <!-- /.col-lg-12 -->
                <a href="?module=view_vendor&act=view_medcheckup"><button type="submit" class="btn btn-default">Overview Medical Checkup</button></a>
                <a href="?module=view_vendor&act=view_biropsi"><button type="submit" class="btn btn-default"  >Overview Biro Psikotest</button></a>

            <!-- /.row -->          
<br><br>
    <?php
    /*
        Overview Position Struktur
    */
    
if($_GET['act']=="view_medcheckup"){
	?>
              
           <div class="row">
                
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview Medical Checkup &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="?module=mcu_vendor&act=input"><button type="submit" class="btn btn-info text-right"  >Add</button></a>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            
                            <div class="table-responsive">
                                
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center">Id Vendor</th>
                                            <th class="text-center">Nama Vendor</th>
                                            <th class="text-center">Cabang</th>
                                            <th class="text-center">Alamat</th>
                                        
                                            <th class="text-center">Telepon</th>
                                        
                                            <th class="text-center">E-mail</th>
                                            <th class="text-center">Fax</th>
                                          
                                            <th class="text-center">No Rekening</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from t_vendormcu";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id_vendor]";  ?></td>
                                            <td><?php echo"$rsa[namavendor]";  ?></td>
                                            <td><?php echo"$rsa[cabang]";  ?></td>
                                            <td><?php echo"$rsa[alamat]";  ?></td>
                                      
                                            <td><?php echo"$rsa[telpon]";  ?></td>
                                         
                                            <td><?php echo"$rsa[email]";  ?></td>
                                            <td><?php echo"$rsa[fax]";  ?></td>
                                            
                                            <td><?php echo"$rsa[norek]";  ?></td>
                                            <td><?php echo"$rsa[validfrom]";  ?></td>
                                            <td><?php echo"$rsa[validto]";  ?></td>
                                           
                                            

                                        <td class="text-center"><a href="?module=mcu_vendor&act=edit&id=<?php echo $rsa['id_vendor'] ?>"><button type="button" class="btn btn-info">Edit</button> 
                                                <a href="?module=simpan&act=hapus_mcuvendor&id=<?php echo $rsa['id_vendor'] ?>"><button type="button" class="btn btn-danger">Hapus</button></a></td>

                                        </tr>

<?php }
?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
  <?php } 

    
if($_GET['act']=="view_biropsi"){
	?>
              
           <div class="row">
                
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview Biro Psikotest &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="?module=psi_vendor&act=input"><button type="submit" class="btn btn-info text-right"  >Add</button></a>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            
                            <div class="table-responsive">
                                
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center">Id Vendor</th>
                                            <th class="text-center">Nama Vendor</th>
                                            <th class="text-center">Cabang</th>
                                            <th class="text-center">Alamat</th>
                                        
                                            <th class="text-center">Telepon</th>
                                        
                                            <th class="text-center">E-mail</th>
                                            <th class="text-center">Fax</th>
                                          
                                            <th class="text-center">No Rekening</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from t_vendorbiropsi";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id_vendor]";  ?></td>
                                            <td><?php echo"$rsa[namavendor]";  ?></td>
                                            <td><?php echo"$rsa[cabang]";  ?></td>
                                            <td><?php echo"$rsa[alamat]";  ?></td>
                                      
                                            <td><?php echo"$rsa[telpon]";  ?></td>
                                         
                                            <td><?php echo"$rsa[email]";  ?></td>
                                            <td><?php echo"$rsa[fax]";  ?></td>
                                            
                                            <td><?php echo"$rsa[norek]";  ?></td>
                                            <td><?php echo"$rsa[validfrom]";  ?></td>
                                            <td><?php echo"$rsa[validto]";  ?></td>
                                           
                                            

                                        <td class="text-center"><a href="?module=psi_vendor&act=edit&id=<?php echo $rsa['id_vendor'] ?>"><button type="button" class="btn btn-info">Edit</button> 
                                                <a href="?module=simpan&act=hapus_vendorpsi&id=<?php echo $rsa['id_vendor'] ?>"><button type="button" class="btn btn-danger">Hapus</button></a></td>

                                        </tr>

<?php }
?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
  <?php } ?>


  

   