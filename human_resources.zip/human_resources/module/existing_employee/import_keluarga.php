
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
        <section class="content-header">
          <h1> Import data Family Employee </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Import</a></li>
            <li class="active">Family Employee</li>
          </ol>
        </section>
            <div class="row">
                  <div class="col-xs-12">    
                            
                              <div class="box">
                                <div class="box-header">
                                 
                                </div><!-- /.box-header -->
                                <div class="box col-xs-12">
                                    <br><br>
                            <form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
                            <font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
                            <input type='file' name='filename' size='20'><br>
                            <input type='submit' name='submit' value='Insert'></form>
                            <br>



                            <?php
                            print "<p>Catatan :  Apabila data yang diimport adalah data Baru silahkan tekan Insert<br>
                                          namun bila data yang diimport sudah ada silahkan tekan tombol Update
                             </p>";

                             include "config/conn.php";   

                            if(isset($_POST['submit']))
                            {
                            $target_path = 'c:\xampp\htdocs\human_resources\test\..';  

                            $target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

                            if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
                            echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
                            } else{
                            echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
                            } // ini untuk mengupload file CSV ke alamat tadi
                            // ini script untuk mengimport data CSV ke MySQL
                            $filename=$target_path;
                            $handle = fopen("$filename", "r");
                            while (($data = fgetcsv($handle, 10000, ",")) !== FALSE)
                            {
                                include "config/conn.php";   
                                $tgllahir=$data[24];
                                $empno=$data[0];
                                $relativname=$data[18];
                                $idbaru=$empno.$tgllahir.$relativname;
                                $querycek="SELECT COUNT(idrelative)as Jumlah
                                           FROM keluarga
                                           WHERE idrelative='$idbaru'
                                            ";
                                $hasilcek=mysql_query($querycek);
                                
                                $row=  mysql_fetch_array($hasilcek);

                                    $row1=$row[Jumlah];
                                    if($row1 > 0){
                                        
                                        $relativename=$data[18];
                                        $relphone=$data[19];
                                        $reltype=$data[20];
                                        $relgender=$data[21];
                                        $relstatus=$data[22];
                                        $relbirthplace=$data[23];
                                        $reldatebirth=$data[24];
                                        
                                       $updateexist    =" UPDATE keluarga SET
                                                            relativename      =   '$relativename',
                                                            relphone       =   '$relphone',
                                                            reltype           =   '$reltype',
                                                            relgender     =   '$relgender',
                                                            relstatus        =   '$relstatus',
                                                            relbirthplace       =   '$relbirthplace',
                                                            reldatebirth      =   '$reldatebirth',
                                                            
                                                            WHERE idrelative  =   '$idbaru'";       
                                                        $masuk=  mysql_query($updateexist); 
                                        
                                    }
                                    else{
                                    $import="INSERT into keluarga values(
                                             '$idbaru','$data[18]','$data[19]','$data[20]','$data[21]','$data[22]','$data[23]',
                                            '$data[24]')";
                                    $masuk=  mysql_query($import);
                                    
                                    }
                            }
                            
                            fclose($handle);
                           echo "<script>window.alert(' Terima kasih yaa, Data Telah Terimport')";
                                   // window.location=('?module=dashboard-front')</script>";
                            }


                            else
                            {

                            print "";
                            }

                            ?>  </div>                
                 </div>
                </div>
                </div>

</BODY>
</HTML>
