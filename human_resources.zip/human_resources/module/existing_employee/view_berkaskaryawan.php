<?php
 session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{
  
    ?>
       
     
<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
   
      <!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
         <h3 class="box-title">Berkas Karyawan Baru</h3>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Exit Document</a></li>
            <li><a href="?module=view_position&act=view_posstruktur">Document Resign</a></li>
            <li class="active">Document Resign</li>
          </ol>
        </section>
  
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">   
                           
                              <div class="box">
                                <div class="box-header">
                                    
                                  <div class="pull-right hidden-xs">
                                      
                                     
                                      <a href="?module=pos_struktur&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                     
                                  </div>
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                   <?php
                                   echo "<form name='form_data' id='form_data' method='POST' action='?module=simpan&act=berkas_karyawan' >";
                                           ?>
                                    <button type="submit" value="Save" class="fa fa-save"></button>
                                <table id="example1" class="table table-bordered table-striped">
                                   
                                    <thead>
                                        <tr>
                                           
                                            <th class="text-center" rowspan="2">No</th>
                                            <th class="text-center" rowspan="2">Empno</th>
                                            <th class="text-center" rowspan="2">Emp Name</th>
                                            <th class="text-center" rowspan="2">Posid</th>
                                            <th class="text-center" rowspan="2">Org Code</th>
                                            <th class="text-center" colspan="9">Dokumen</th>
                                            <th class="text-center" rowspan="2">Status</th>
                                           
                                            <th class="text-center" rowspan="2">
                                                <input type="checkbox" name="allbox" value="item" onclick="check_all(this);"/>
                                                Aksi</th>
 
                                        </tr>
                                        <tr>
                                            <th class="text-center" >Tgl Terima</th>
                                            <th class="text-center" >PKWT</th>
                                            <th class="text-center" >Form Pajak</th>
                                            <th class="text-center" >Perj Keraha siaan</th>
                                            <th class="text-center" >Pernyataan Penempatan</th>
                                            <th class="text-center" >Kode Etik</th>                                          
                                            <th class="text-center" >Pendaftaran Asuransi</th>
                                            <th class="text-center" >Data Pelamar</th>
                                            <th class="text-center" >Photo</th>
                                        
                                        </tr>
                                    </thead>
                                    <tbody>
                                  
                            <?php
                               
                            include "config/conn.php";
                            $no=1;
                            $tahun = date("Y");
 
                                    $sql="SELECT DISTINCT a.empno,CONCAT(a.firstname,' ', a.lastname)AS Nama, a.joindate,a.posid, a.orgcode, 
                                            a.compoffice
                                            FROM exist_employee a 
                                            LEFT JOIN berkas_employeefile b ON a.empno=b.empno
                                            ORDER BY a.joindate DESC
";
                                    $hasil1=  mysql_query($sql);
                                    
                                    while($rsa=  mysql_fetch_object($hasil1)){
                                    $nomor++;
                                    $empno=$rsa->empno;
                            ?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$nomor";  ?></td>
                                           
                                            <?php echo'<td><a href="?module=details_berkas&id='.$rsa->empno.'">'.$rsa->empno.'<a/></td>'; 
                                            echo '<input type="hidden" id="txtempno[]" name="txtempno[]" value="'.$rsa->empno.'" /> '; ?>
                                            <?php echo'<td>'.$rsa->Nama.'</td>';  ?>
                                            <?php echo'<td>'.$rsa->posid.'</td>';  ?>
                                            <?php echo'<td>'.$rsa->orgcode.'</td>';  ?>
                                                    
                                                  <?php
                                                    $urlberkas=$rsa->urlberkas;
                                                    if($urlberkas==''){
                                                        echo"<td><input type='text' id='txturl[]' name='txturl[]' size='8'/></td> "; 
                                                    }
                                                    else {  
                                                        $target_path = 'file:///c:/Users/USER/Documents/'.$rsa->urlberkas; 
                                                        $target_path1 = $target_path . basename( $_FILES[$urlberkas]);
                                                       
                                                        
                                                        ?> 
                                            <td class="open">
                                                            <a href="file:///c:\Users\USER\Documents\<?php echo urlencode($urlberkas);?>" target="_blank"> <?php echo $urlberkas; ?> </a> <?php
                                                         echo '</td>';
                                                        //test
                                                        echo '<input type="hidden" id="txturl[]" name="txturl[]" value="'.$rsa->urlberkas.'" /> ';
                                                    }?>  
                                           
                                                <?php
                                                    $datatujuh=$rsa->tglterimaberkas;
                                                    if($datatujuh==''){
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' value='Y' /></td> "; 
                                                    }
                                                    else {
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' checked='true' value='Y'  /></td> "; 
                                                       // echo '<td align="center">'.$rsa->srtresign.'</td>';
                                                       // echo '<input type="hidden" id="cksrtresign[]" name="cksrtresign[]" value="'.$rsa->srtresign.'" /> ';
                                                    }
                                                ?>
                                         
                                                 <?php
                                                    $kartukel=$rsa->pkwt;
                                                    if($kartukel==''){
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' value='Y' /></td> "; 
                                                    }
                                                    else {
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' checked='true' value='Y'  /></td> "; 
                                                       // echo '<td align="center">'.$rsa->srtresign.'</td>';
                                                       // echo '<input type="hidden" id="cksrtresign[]" name="cksrtresign[]" value="'.$rsa->srtresign.'" /> ';
                                                    }
                                                ?>
                                           
                                                 <?php
                                                    $kartukel=$rsa->pajak;
                                                    if($kartukel==''){
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' value='Y' /></td> "; 
                                                    }
                                                    else {
                                                        echo"<td align='center'><input type='checkbox' id='cksrtresign[]' name='cksrtresign[]' checked='true' value='Y'  /></td> "; 
                                                       // echo '<td align="center">'.$rsa->srtresign.'</td>';
                                                       // echo '<input type="hidden" id="cksrtresign[]" name="cksrtresign[]" value="'.$rsa->srtresign.'" /> ';
                                                    }
                                                ?>
                                                            
                                                <?php
                                                $ktp=$rsa->kerahasiaan;
                                                if($ktp==''){
                                                        echo"<td align='center'><input type='checkbox' id='txtkphk[]' name='txtkphk[]' value='Y' /></td> "; 
                                                    }
                                                    else {
                                                       // echo '<td align="center">'.$rsa->kphk.'</td>';
                                                         echo"<td align='center'><input type='checkbox' id='txtkphk[]' name='txtkphk[]' checked='true' value='Y' /></td> "; 
                                                    }
                                              
                                                ?>
                                           
                                                <?php
                                                $srtrefrensi=$rsa->kodeetik;
                                                if($srtrefrensi==''){
                                                        echo'<td align="center"><input type="checkbox" id="txtklksrhterima[]" name="txtklksrhterima[]" value="Y" /> </td>'; 
                                                    }
                                                    else {
                                                       // echo '<td align="center">'.$rsa->klksrhterima.'</td>';
                                                        echo"<td align='center'><input type='checkbox' id='txtklksrhterima[]' name='txtklksrhterima[]' checked='true' value='Y' /></td> "; 
                                                    }
                                               
                                                ?>
                                          
                                           
                                              <?php
                                                $copyijazah=$rsa->pendasuransi;
                                                if($copyijazah==''){
                                                        echo'<td align="center"><input type="checkbox" id="txtklksrhterima[]" name="txtklksrhterima[]" value="Y" /> </td>'; 
                                                    }
                                                    else {
                                                       // echo '<td align="center">'.$rsa->klksrhterima.'</td>';
                                                        echo"<td align='center'><input type='checkbox' id='txtklksrhterima[]' name='txtklksrhterima[]' checked='true' value='Y' /></td> "; 
                                                    }
                                               
                                                ?>
                                            
                                                <?php
                                                $copytranskrip=$rsa->tujuhlembar;
                                                if($copytranskrip==''){
                                                        echo'<td align="center"><input type="checkbox" id="txtklksrhterima[]" name="txtklksrhterima[]" value="Y" /> </td>'; 
                                                    }
                                                    else {
                                                       // echo '<td align="center">'.$rsa->klksrhterima.'</td>';
                                                        echo"<td align='center'><input type='checkbox' id='txtklksrhterima[]' name='txtklksrhterima[]' checked='true' value='Y' /></td> "; 
                                                    }
                                               
                                                ?>
                                          
                                                <?php
                                                $scan=$rsa->photo;
                                                if($scan==''){
                                                        echo'<td align="center"><input type="checkbox" id="txtklksrhterima[]" name="txtklksrhterima[]" value="Y" /> </td>'; 
                                                    }
                                                    else {
                                                       // echo '<td align="center">'.$rsa->klksrhterima.'</td>';
                                                        echo"<td align='center'><input type='checkbox' id='txtklksrhterima[]' name='txtklksrhterima[]' checked='true' value='Y' /></td> "; 
                                                    }
                                               
                                               
                                               
                                               
                                                
                                                
                                                     $istatus=$rsa->istatus;
                                                        echo '<td align="center">'.$rsa->istatus.'</td>';
                                          
                                          
                                           if($srtresign==''){
                                               echo '<td align="center">
                                                    <input type="checkbox" name="item[]" id="item[]" value="'.$rsa->empno.'" />
                                                 </td>'; 
                                           }
                                           else{
                                               
                                                     echo '<td align="center">
                                                            <a href="?module=home&id=$empno">';?> 
                                                            <i class="fa fa-edit text-success"></i>
                                                       <?php echo '</a>
                                                 </td>'; 
                                            
                                           }
                                           
                                            ?> 
                                       
                                        </tr>
 
<?php }
?>                                
                                    </tbody>
                               
                                </table>
                                    <?php echo "</form>"; ?>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
             
           
            </div><!-- /.row -->
        </section><!-- /.content -->
          
 
 
 
 
      </div>
     
      <?php } ?>