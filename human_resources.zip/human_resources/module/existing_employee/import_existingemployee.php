
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
        <section class="content-header">
          <h1> Import data Existing Employee </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Import</a></li>
            <li class="active">Existing Employee</li>
          </ol>
        </section>
            <div class="row">
                  <div class="col-xs-12">    
                            
                              <div class="box">
                                <div class="box-header">
                                 
                                </div><!-- /.box-header -->
                                <div class="box col-xs-12">
                                    <br><br>
                            <form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
                            <font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
                            <input type='file' name='filename' size='20'><br>
                            <input type='submit' name='submit' value='Insert'><input type='submit' name='update' value='Update'></form>
                            <br>



                            <?php
                            print "<p>Catatan :  Apabila data yang diimport adalah data Baru silahkan tekan Insert<br>
                                          namun bila data yang diimport sudah ada silahkan tekan tombol Update
                             </p>";

                             include "config/conn.php";   

                            if(isset($_POST['submit']))
                            {
                            $target_path = 'c:\xampp\htdocs\human_resources\test';  

                            $target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

                            if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
                            echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
                            } else{
                            echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
                            } // ini untuk mengupload file CSV ke alamat tadi
                            // ini script untuk mengimport data CSV ke MySQL
                            $filename=$target_path;
                            $handle = fopen("$filename", "r");
                            while (($data = fgetcsv($handle, 30000, ",")) !== FALSE)
                            {
                                $idbaru=$data[0];
                                $empno=$data[1];
                                $effdate=$data[11];
                                //$idbaru=$empno.$effdate;
                                $querycek="SELECT COUNT(idempno1)as Jumlah
                                           FROM exist_employee
                                           WHERE idempno1='$idbaru'
                                            ";
                                $hasilcek=mysql_query($querycek);
                                 
                                $row=  mysql_fetch_array($hasilcek);

                                    $row1=$row[Jumlah];
                                    if($row1 > 0){
                                        
                                        $firstname=$data[3];
                                        $lastname=$data[4];
                                        $init=$data[5];
                                        $salutation=$data[6];
                                        $prename=$data[7];
                                        $pretitle=$data[8];
                                        $jamsostek=$data[9];
                                        $placebirth=$data[10];
                                        $datebirth=$data[11];
                                        $maritalstatus=$data[13];
                                        $religion=$data[14];
                                        $blood=$data[15];
                                        $hcild=$data[17];
                                        $addressid=$data[18];
                                        $addressline1=$data[19];
                                        $addressline2=$data[20];
                                        $city=$data[21];
                                        $zipcode=$data[22];
                                        $bagian=$data[23];
                                        $country=$data[24];
                                        $phone=$data[25];
                                        $mobile=$data[26];
                                        $email=$data[27];
                                        $privateemail=$data[28];
                                        $posemail=$data[29];
                                        $iterkom=$data[30];
                                        $ktp=$data[31];
                                        $edulevel=$data[32];
                                        $edufield=$data[33];
                                        $eduinstitution=$data[34];
                                        $terminationdate=$data[36];
                                        $emptype=$data[42];
                                        $excontrac=$data[43];
                                        $empstatus=$data[44];
                                        $probation=$data[45];
                                        $indclass=$data[46];
                                        $compoffice=$data[48];
                                        $compoffgroup=$data[49];
                                        $posid=$data[54];
                                        $postitle=$data[55];
                                        $posclass=$data[56];
                                        $jobid=$data[57];
                                        $jobtitle=$data[58];
                                        $orgcode=$data[59];
                                        $orgname=$data[60];
                                        $costcenter=$data[61];
                                        $supid=$data[62];
                                        $supname=$data[63];
                                        $supostid=$data[64];
                                        $supostitle=$data[65];
                                        $suporgcode=$data[66];
                                        $suprogname=$data[67];
                                        
                                       $updateexist    =" UPDATE exist_employee SET
                                                            firstname      =   '$firstname',
                                                            lastname       =   '$lastname',
                                                            init           =   '$init',
                                                            salutation     =   '$salutation',
                                                            prename        =   '$prename',
                                                            pretitle       =   '$pretitle',
                                                            jamsostek      =   '$jamsostek',
                                                            placebirth            =   '$placebirth',
                                                            datebirth          =   '$datebirth',
                                                            maritalstatus         =   '$maritalstatus',
                                                            religion    =   '$religion',
                                                            blood       =   '$blood',
                                                            hcild       =   '$hcild',
                                                                
                                                            addressid       =   '$addressid',
                                                            addressline1       =   '$addressline1',
                                                            addressline2       =   '$addressline2',
                                                            city       =   '$city',
                                                            zipcode       =   '$zipcode',
                                                            bagian       =   '$bagian',
                                                            country       =   '$country',
                                                            phone       =   '$phone',
                                                            mobile       =   '$mobile',
                                                            email       =   '$email',
                                                            privateemail       =   '$privateemail',
                                                            posemail       =   '$posemail',
                                                            iterkom       =   '$iterkom',
                                                            ktp       =   '$ktp',
                                                            edulevel       =   '$edulevel',
                                                            edufield       =   '$edufield',
                                                            eduinstitution       =   '$eduinstitution',
                                                            terminationdate       =   '$terminationdate',
                                                            emptype       =   '$emptype',
                                                            excontrac       =   '$excontrac',
                                                            empstatus       =   '$empstatus',
                                                            probation       =   '$probation',
                                                            indclass       =   '$indclass',
                                                            compoffice       =   '$compoffice',
                                                            
                                                            compoffgroup       =   '$compoffgroup',
                                                            posid       =   '$posid',
                                                            postitle       =   '$postitle',
                                                            posclass       =   '$posclass',
                                                            jobid       =   '$jobid',
                                                            jobtitle       =   '$jobtitle',
                                                            orgcode       =   '$orgcode',
                                                            orgname       =   '$orgname',
                                                            costcenter       =   '$costcenter',
                                                            supid       =   '$supid',
                                                            supname       =   '$supname',
                                                            supostid       =   '$supostid',
                                                            supostitle       =   '$supostitle',
                                                            suporgcode       =   '$suporgcode',
                                                            suprogname       =   '$suprogname'    




                                                            WHERE idempno1  =   '$idbaru'";       
                                                        $masuk=  mysql_query($updateexist); 
                                        
                                    }
                                    else{
                                    $import="INSERT into exist_employee values(
                                             '$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]',
                                            '$data[7]','$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]',
                                            '$data[14]','$data[15]','$data[16]','$data[17]','$data[18]','$data[19]','$data[20]',
                                            '$data[21]','$data[22]','$data[23]','$data[24]','$data[25]','$data[26]','$data[27]',
                                            '$data[28]','$data[29]','$data[30]','$data[31]','$data[32]','$data[33]','$data[34]',
                                            '$data[35]','$data[36]','$data[37]','$data[38]','$data[39]','$data[40]','$data[41]',
                                            '$data[42]','$data[43]','$data[44]','$data[45]','$data[46]','$data[47]','$data[48]',
                                            '$data[49]','$data[50]','$data[51]','$data[52]','$data[53]','$data[54]','$data[55]',
                                            '$data[56]','$data[57]','$data[58]','$data[59]','$data[60]','$data[61]','$data[62]',
                                            '$data[63]','$data[64]','$data[65]','$data[66]','$data[67]')";
                                    $masuk=  mysql_query($import);
                                       
                                    }
                            }
                            fclose($handle);
                           echo "<script>window.alert(' Terima kasih yaa, Data Telah Terimport');
                                    window.location=('?module=dashboard-front')</script>";
                               
                            }


                            else
                            {

                            print "gak bisa";
                            }

                            ?>  </div>                
                 </div>
                </div>
                </div>

</BODY>
</HTML>
