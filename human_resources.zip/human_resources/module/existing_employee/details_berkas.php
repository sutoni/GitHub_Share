<?php
include "config/conn.php";

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";

}
else{
    
    
?>
<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap.min.js"></script>
<link rel="stylesheet" href="bootstrap-theme.min.css">
<link rel="stylesheet" href="bootstrap.min.css">

<?php 
include "config/conn.php";
$txtempno=$_GET['id'];
$caridouble="SELECT * FROM berkas_employeefile WHERE empno='$txtempno'";
                $hasilcari=mysql_query($caridouble);
   if ($rownya=mysql_num_rows($hasilcari))
   { ?>
         <section class="content-header ">
                    <ol class="breadcrumb  ">
                    <li><a href="?module=home"><i class="fa fa-home"></i> Home</a></li>
                    <li><a href="#">Employee File</a></li>
                    <li class="active">Berkas Karyawan </li>
                </ol>
            </section>
<br><br> <?php
                                $id=$_GET['id']; ?>
        <form  method="POST" ACTION="?module=simpan&act=ttb_berkaskaryawan&id=<?php  echo "$id";   ?>"  class="form-horizontal"  role="form">             
            <div class="panel panel-default">
                <ol class="breadcrumb  ">
                    <li> Update Checklist Berkas Karyawan </li>
                </ol>
                
                <div class="panel-body">
                    <form class="form-inline">
                        <?php
                                $id=$_GET['id'];
                                include 'config/conn.php';
                                $tahunsekarang=date('Y');
                                $bulan=date('m');
                                $cari="
                                    SELECT a.empno, CONCAT(b.firstname,' ',b.lastname)AS name, b.joindate,b.postitle, b.orgname, b.compoffgroup, b.empstatus, 
                                        a.tglterimaberkas
                                        FROM berkas_employeefile a 
                                        INNER JOIN exist_employee b ON a.empno=b.empno 
                                        WHERE SUBSTR(b.idempno1,1,4)='$tahunsekarang' AND SUBSTR(b.idempno1,5,2)='$bulan' AND a.empno='$_GET[id]'";
                                $hasil = mysql_query($cari);
                               
                                $rescari=mysql_fetch_array($hasil);
                                
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['name'];
                                    $currentposition=$rescari['postitle'];
                                    $joindate =$rescari['joindate'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    
                                    $tglterimaberkas=$rescari['tglterimaberkas'];
                                    
                                    
                                    
                                    
                                    
                                   
                                    
                        ?>          
                        
                        <ul>
                    <div class="form-group">
                        <div class="col-lg-4">
                            <div class="form-group">
                                    <label control-label > Employee No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                    <input type="text" size="15" class="form-control"  name="txtempno" id="txtempno" value="<?php echo "$empno"; ?>" disabled>
                            </div>   
                            <div class="form-group">
                                 <label  control-label> Employee Name &nbsp;&nbsp;&nbsp;</label> 
                                 <input type="text" size="25" class="form-control" name="txtname" id="txtname" value="<?php echo "$empname"; ?>" disabled>   
                            </div>    
                            <div class="form-group">
                                  
                                  <label  control-label> Join Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                  </label> <input type="text" size="10" class="form-control" name="txtname" id="txtname" value="<?php echo "$joindate"; ?>" disabled>
                                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <br>
                             
                            
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label control-label > Position Title &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                <input type="text" size="45" class="form-control"  name="txtcurposition" id="txtcurposition" value="<?php echo "$currentposition"; ?>" disabled>
                            </div>    
                            <div class="form-group">
                                    <label  control-label> Organization Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                    <input type="text" size="45" class="form-control" name="txtname" id="txtname" value="<?php echo "$currentorgname"; ?>" disabled>
                            </div>
                            <div class="form-group">
                                    <label  control-label> Company Office Group&nbsp;&nbsp;&nbsp;</label> 
                                    <input type="text" size="45" class="form-control" name="txtname" id="txtname" value="<?php echo "$compoffgroup"; ?>" disabled>
                            </div>
                    </div>
                        
                        <div class="col-lg-2">
                             <div class="form-group">
                                 <label  control-label> Status &nbsp;</label> 
                                  <input type="text" size="8" class="form-control" name="txtname" id="txtname" value="<?php echo "$empstatus"; ?>" disabled>
                            </div>
                        </div>
               
                   <div class="col-lg-12">
                       
                       <div class="form-group"> 
                           <label class="control-label"> Tanggal Terima &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                                <input class="form-control" type="text" name="txttglberkas" id="txttglberkas" value="<?php echo "$tglterimaberkas"; ?>">
                                                
                                            </div>
                                        </div>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>

                                      
                        </div>
                       
                   </div>
                        </ul>    
                      
                </div>
            </div>   
             <div class="panel panel-default">    
                <?php 
                                include "config/conn.php"; 
                                $caricentang="SELECT  *
                                        FROM berkas_employeefile WHERE empno='$_GET[id]'";
                                $hasilcentang = mysql_query($caricentang);
                               
                               
                                    $rescentang=mysql_fetch_array($hasilcentang);
                                    $srtlamaran=$rescentang['srtlamaran'];
                                    $srtcv=$rescentang['srtcv'];
                                    $photo=$rescentang['photo'];
                                    $dtpelamar=$rescari['dtpelamar'];
                                    $srtrefrensi=$rescari['srtrefrensi'];
                                    $transkripnilai=$rescari['transkripnilai'];
                                    $ijzhama=$rescari['ijzhama'];
                                    $ijzhdiploma=$rescari['ijzhdiploma'];
                                    
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['name'];
                                    $currentposition=$rescari['postitle'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['name'];
                                    $currentposition=$rescari['postitle'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['name'];
                                    $currentposition=$rescari['postitle'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['name'];
                                    $currentposition=$rescari['postitle'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['name'];
                                    $currentposition=$rescari['postitle'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                                    
                ?>
                <div class="panel-heading">
		I. Form Dokumen Lamaran Update
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                              <?php IF($srtlamaran=Y){ 
                             ?>
                                 <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbsrtlam1" id="rbsrtlam1" value="Y"  checked> YA <input type="radio" name="rbsrtlam1" id="rbsrtlam1"  value="T" > TIDAK 
                                 </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Surat Lamaran Kerja"  disabled="">
                             <?php } else{?>
                                 <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbsrtlam1" id="rbsrtlam1" value="Y" > YA <input type="radio" name="rbsrtlam1" id="rbsrtlam1" value="T" checked> TIDAK  
                                 </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Surat Lamaran Kerja"  disabled="">
                              <?php } ?>
                               
                              <?php IF($srtcv=Y){ 
                              ?>      
                                <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbcurvit1" id="rbcurvit1" value="Y" checked> YA <input type="radio" name="rbcurvit1" id="rbcurvit1"  value="T"> TIDAK
                                </span>
                                <input type="text" class="form-control" aria-label="..." placeholder="Curicullum Vitae" disabled="">
                                <?php } else{?>
                                <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbcurvit1" id="rbcurvit1" value="Y" > YA <input type="radio" name="rbcurvit1" id="rbcurvit1"  value="T" checked> TIDAK
                                </span>
                                <input type="text" class="form-control" aria-label="..." placeholder="Curicullum Vitae" disabled="">
                                 <?php } ?>
                                
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbphoto1" id="rbphoto1" value="Y"  > YA <input type="radio" name="rbphoto1" id="rbphoto1"  value="T" checked> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Photo" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbdpel1" id="rbdpel1"  value="Y"> YA <input type="radio" name="rbdpel1" id="rbdpel1"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Data Pelamar " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbref1" id="rbref1"  value="Y"> YA <input type="radio" name="rbref1" id="rbref1"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Surat Referensi Kerja" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbtranskrip1" id="rbtranskrip1"  value="Y"> YA <input type="radio" name="rbtranskrip1" id="rbtranskrip1"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Transkrip Nilai" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbijzsmu1" id="rbijzsmu1"  value="Y"> YA <input type="radio" name="rbijzsmu1" id="rbijzsmu1"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Ijazah SLTA/SMA/SMK" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbijzdiploma1" id="rbijzdiploma1"  value="Y"> YA <input type="radio" name="rbijzdiploma1" id="rbijzdiploma1"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Ijazah Diploma/S1" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbstrata2" id="rbstrata2"  value="Y"> YA <input type="radio" name="rbstrata2" id="rbstrata2"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Ijazah S2/S3" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
              
                <div class="panel-heading">
		II. Form Identitas
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbktp1" id="rbktp1"value="Y"> YA <input type="radio" name="rbktp1" id="rbktp1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Kartu Tanda Penduduk" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbsim1" id="rbsim1" value="Y"> YA <input type="radio" name="rbsim1" id="rbsim1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Ijin Mengemudi" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbaktelahir" id="rbaktelahir" value="Y"> YA <input type="radio" name="rbaktelahir" id="rbaktelahir" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Akte Lahir" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkk" id="rbkk"  value="Y"> YA <input type="radio" name="rbkk" id="rbkk"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Kartu Keluarga " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbnpwp1" id="rbnpwp1"  value="Y"> YA <input type="radio" name="rbnpwp1" id="rbnpwp1"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Nomor Pokok Wajib Pajak" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpassport" id="rbpassport"  value="Y"> YA <input type="radio" name="rbpassport" id="rbpassport"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Pasport" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkitas" id="rbkitas"  value="Y"> YA <input type="radio" name="rbkitas" id="rbkitas"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="KITAS" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbaktenikah" id="rbaktenikah"  value="Y"> YA <input type="radio" name="rbaktenikah" id="rbaktenikah"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Akte Nikah" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbaktecerai" id="rbaktecerai"  value="Y"> YA <input type="radio" name="rbaktecerai" id="rbaktecerai"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Akte Cerai" disabled="">
                                    
                                </div><!-- /input-group -->
                                
                             <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbstnk" id="rbstnk"  value="Y"> YA <input type="radio" name="rbstnk" id="rbstnk"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="STNK" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbjamsostek" id="rbjamsostek"  value="Y"> YA <input type="radio" name="rbjamsostek" id="rbjamsostek"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Kartu Jamsostek" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
                
             <div class="panel-heading">
		III. Form Keluarga
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbktppas" id="rbktppas"value="Y"> YA <input type="radio" name="rbktppas" id="rbktppas" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Kartu Tanda Penduduk (Istri/Suami)" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbaktelhrpass" id="rbaktelhrpass" value="Y"> YA <input type="radio" name="rbaktelhrpass" id="rbaktelhrpass" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Akte Lahir (Istri/Suami)" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbaktelhranak" id="rbaktelhranak" value="Y"> YA <input type="radio" name="rbaktelhranak" id="rbaktelhranak" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Akte Lahir Anak" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                
            </div><!-- /.row -->
            
             <div class="panel-heading">
		IV. Form Perjanjian
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbspk" id="rbspk"value="Y"> YA <input type="radio" name="rbspk" id="rbspk" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Perjanjian Kerja" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpajak" id="rbpajak" value="Y"> YA <input type="radio" name="rbpajak" id="rbpajak" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Pernyataan Pajak" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbkerahasiaan" id="rbkerahasiaan" value="Y"> YA <input type="radio" name="rbkerahasiaan" id="rbkerahasiaan" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Perjanjian Kerahasiaan" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkodeetik" id="rbkodeetik"  value="Y"> YA <input type="radio" name="rbkodeetik" id="rbkodeetik"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Pernyataan Kode Etik " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpenempatan" id="rbpenempatan"  value="Y"> YA <input type="radio" name="rbpenempatan" id="rbpenempatan"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Pernyataan Penempatan" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpersonnelaction" id="rbpersonnelaction"  value="Y"> YA <input type="radio" name="rbpersonnelaction" id="rbpersonnelaction"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Personnel Action" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbikatandinas" id="rbikatandinas"  value="Y"> YA <input type="radio" name="rbikatandinas" id="rbikatandinas"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Perjanjian Ikatan Dinas" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkomitmen" id="rbkomitmen"  value="Y"> YA <input type="radio" name="rbkomitmen" id="rbkomitmen"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Surat Komitmen" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->   
            
             <div class="panel-heading">
		V. Form Pendaftaran
                </div>
                <div class="row">
                    <ul>
                    <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbasuransi" id="rbasuransi"value="Y"> YA <input type="radio" name="rbasuransi" id="rbasuransi" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Pendaftaran Asuransi" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpendjamsostek" id="rbpendjamsostek" value="Y"> YA <input type="radio" name="rbpendjamsostek" id="rbpendjamsostek" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Pendaftaran BPJS Ketenagakerjaan" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbbpjspensiun" id="rbbpjspensiun" value="Y"> YA <input type="radio" name="rbbpjspensiun" id="rbbpjspensiun" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text"  class="form-control" aria-label="..." placeholder="Pendaftaran BPJS Pensiun " disabled="">
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                    </ul>
                
                    <ul>
                    <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                              No Rekening &nbsp;&nbsp;
                          </span>
                            <input type="text" name="txtnorek" id="txtnorek" class="form-control" aria-label="..." placeholder="Isi Nomer Rekening" >
                            
                            
                             <span class="input-group-addon">
                            Nama Bank &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          </span>
                            <input type="text" name="txtnamabank" id="txtnamabank" class="form-control" aria-label="..." placeholder="Isi Nama Bank" >
                            
                            <span class="input-group-addon">
                            Cabang &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          </span>
                            <input type="text"  name="txtcabangbank" id="txtcabangbank"  class="form-control" aria-label="..." placeholder="Isi Cabang Bank " >
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
            
            <div class="panel-heading">
		VI. Form HR
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpauli" id="rbpauli"value="Y"> YA <input type="radio" name="rbpauli" id="rbpauli" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Hasil Test Pauli" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbbeta3" id="rbbeta3" value="Y"> YA <input type="radio" name="rbbeta3" id="rbbeta3" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Beta 3" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbwpt" id="rbwpt" value="Y"> YA <input type="radio" name="rbwpt" id="rbwpt" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="WPT" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpsikorecruitment" id="rbpsikorecruitment"  value="Y"> YA <input type="radio" name="rbpsikorecruitment" id="rbpsikorecruitment"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Psikogram Recruitment " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbwarteg" id="rbwarteg"  value="Y"> YA <input type="radio" name="rbwarteg" id="rbwarteg"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Warteg" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbdisc" id="rbdisc"  value="Y"> YA <input type="radio" name="rbdisc" id="rbdisc"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="DISC" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbwwcruser" id="rbwwcruser"  value="Y"> YA <input type="radio" name="rbwwcruser" id="rbwwcruser"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Wawancara User" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbwwcrhr" id="rbwwcrhr"  value="Y"> YA <input type="radio" name="rbwwcrhr" id="rbwwcrhr"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Wawancara HR" disabled="">
                                    
                                    <span class="input-group-addon">
                                         <input type="radio" aria-label="..." name="rbtestkesehatan" id="rbtestkesehatan"  value="Y"> YA <input type="radio" name="rbtestkesehatan" id="rbtestkesehatan"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Hasil Test Kesehatan" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                     
                     <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpsikoassessment" id="rbpsikoassessment"  value="Y"> YA <input type="radio" name="rbpsikoassessment" id="rbpsikoassessment"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Psikogram Assessment" disabled="">


                                    <span class="input-group-addon">
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->  
                    <!-- document filling -->
                    <div class="panel-heading">
		V. Penyimpanan Dokumen
                </div>
                <div class="row">
                    <ul>
                    <div class="col-lg-12">
                        <div class="input-group">
                            <span class="input-group-addon "> <select class="form-control"  id="txtsimpandmana" id="txtsimpandmana">
                                        <option value="-">-</option>
                                        <option value="sementara">Temporary</option>
                                        <option value="rollopek">Lemari File</option>
                                        <option value="vendor">Vendor </option>
                                </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </span>   
                             <input type="text" class="form-control" name="txtsimpanhardcopy" id="txtsimpanhardcopy" aria-label="..." placeholder="Lokasi Simpan File Hard" enabled="">
                             
                             <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbelo" id="rbelo"  value="Y"> YA <input type="radio" name="rbpsikoassessment" id="rbpsikoassessment"  aria-label="Y" value="T"> TIDAK
                                  </span>
                             <input type="text" class="form-control" size="20" aria-label="..." placeholder="Scan ELO" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
                     <div class="panel-heading">                    
                        VI. Catatan HRD
                    </div>
                     <ul>
                        <div class="form-group">
                            <label>
                                Comment :
                            </label>
                            <textarea class="form-control col-sm-3" name="txtcathrd" id="txtcathrd" rows="3" cols="3" id="txtcatatanhrd" name="txtcatatanhrd"></textarea>
                        </div>
                     </ul>
                     <p align="center"><br>
                         <input type="submit" name="submit" value="Submit" width="25" height="25" colspan=0 > 
                
            </div>
            </form>  
      <?php
        
    }
   else
    { ?> 
 
            <section class="content-header ">
                    <ol class="breadcrumb  ">
                    <li><a href="?module=home"><i class="fa fa-home"></i> Home</a></li>
                    <li><a href="#">Employee File</a></li>
                    <li class="active">Berkas Karyawan </li>
                </ol>
            </section>
<br><br> <?php
                                $id=$_GET['id']; ?>
        <form  method="POST" ACTION="?module=simpan&act=ttb_berkaskaryawan&id=<?php  echo "$id";   ?>"  class="form-horizontal"  role="form">             
            <div class="panel panel-default">
                <ol class="breadcrumb  ">
                    <li> Checklist Berkas Karyawan </li>
                </ol>
                
                <div class="panel-body">
                    <form class="form-inline">
                        <?php
                                $id=$_GET['id'];
                                include 'config/conn.php';
                                $cari="SELECT empno, CONCAT(firstname,' ',lastname)AS name, joindate,postitle, orgname, compoffgroup, empstatus "
                                        . "FROM exist_employee WHERE empno='$_GET[id]'";
                                $hasil = mysql_query($cari);
                                
                                $rescari=mysql_fetch_array($hasil);
                                
                                    $empno=$rescari['empno'];
                                    $empname=$rescari['name'];
                                    $currentposition=$rescari['postitle'];
                                    $joindate =$rescari['joindate'];
                                    $currentorgname=$rescari['orgname'];
                                    $compoffgroup=$rescari['compoffgroup'];
                                    $empstatus=$rescari['empstatus'];
                        ?>          
                        
                        <ul>
                    <div class="form-group">
                        <div class="col-lg-4">
                            <div class="form-group">
                                    <label control-label > Employee No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                    <input type="text" size="15" class="form-control"  name="txtempno" id="txtempno" value="<?php echo "$empno"; ?>" disabled>
                            </div>   
                            <div class="form-group">
                                 <label  control-label> Employee Name 2 &nbsp;&nbsp;&nbsp;</label> 
                                 <input type="text" size="25" class="form-control" name="txtname" id="txtname" value="<?php echo "$empname"; ?>" disabled>   
                            </div>    
                            <div class="form-group">
                                  
                                  <label  control-label> Join Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                  </label> <input type="text" size="10" class="form-control" name="txtname" id="txtname" value="<?php echo "$joindate"; ?>" disabled>
                                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <br>
                             
                            
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label control-label > Position Title &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                <input type="text" size="45" class="form-control"  name="txtcurposition" id="txtcurposition" value="<?php echo "$currentposition"; ?>" disabled>
                            </div>    
                            <div class="form-group">
                                    <label  control-label> Organization Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                    <input type="text" size="45" class="form-control" name="txtname" id="txtname" value="<?php echo "$currentorgname"; ?>" disabled>
                            </div>
                            <div class="form-group">
                                    <label  control-label> Company Office Group&nbsp;&nbsp;&nbsp;</label> 
                                    <input type="text" size="45" class="form-control" name="txtname" id="txtname" value="<?php echo "$compoffgroup"; ?>" disabled>
                            </div>
                    </div>
                        
                        <div class="col-lg-2">
                             <div class="form-group">
                                 <label  control-label> Status &nbsp;</label> 
                                  <input type="text" size="8" class="form-control" name="txtname" id="txtname" value="<?php echo "$empstatus"; ?>" disabled>
                            </div>
                        </div>
               
                   <div class="col-lg-12"><br><br>
                       
                       <div class="form-group"> 
                           <label class="control-label"> Tanggal Terima &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                                <input class="form-control" type="text" name="txttglberkas" id="txttglberkas">
                                                
                                            </div>
                                        </div>
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>

                                      
                        </div>
                       
                   </div>
                        </ul>    
                      
                </div>
            </div>   
             <div class="panel panel-default">    
                
                <div class="panel-heading">
		I. Form Dokumen Lamaran
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbsrtlam1" id="rbsrtlam1"value="Y"> YA <input type="radio" name="rbsrtlam1" id="rbsrtlam1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Lamaran Kerja" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbcurvit1" id="rbcurvit1" value="Y"> YA <input type="radio" name="rbcurvit1" id="rbcurvit1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Curicullum Vitae" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbphoto1" id="rbphoto1" value="Y"> YA <input type="radio" name="rbphoto1" id="rbphoto1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Photo" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbdpel1" id="rbdpel1"  value="Y"> YA <input type="radio" name="rbdpel1" id="rbdpel1"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Data Pelamar " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbref1" id="rbref1"  value="Y"> YA <input type="radio" name="rbref1" id="rbref1"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Surat Referensi Kerja" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbtranskrip1" id="rbtranskrip1"  value="Y"> YA <input type="radio" name="rbtranskrip1" id="rbtranskrip1"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Transkrip Nilai" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbijzsmu1" id="rbijzsmu1"  value="Y"> YA <input type="radio" name="rbijzsmu1" id="rbijzsmu1"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Ijazah SLTA/SMA/SMK" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbijzdiploma1" id="rbijzdiploma1"  value="Y"> YA <input type="radio" name="rbijzdiploma1" id="rbijzdiploma1"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Ijazah Diploma/S1" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbstrata2" id="rbstrata2"  value="Y"> YA <input type="radio" name="rbstrata2" id="rbstrata2"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Ijazah S2/S3" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
              
                <div class="panel-heading">
		II. Form Identitas
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbktp1" id="rbktp1"value="Y"> YA <input type="radio" name="rbktp1" id="rbktp1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Kartu Tanda Penduduk" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbsim1" id="rbsim1" value="Y"> YA <input type="radio" name="rbsim1" id="rbsim1" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Ijin Mengemudi" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbaktelahir" id="rbaktelahir" value="Y"> YA <input type="radio" name="rbaktelahir" id="rbaktelahir" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Akte Lahir" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkk" id="rbkk"  value="Y"> YA <input type="radio" name="rbkk" id="rbkk"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Kartu Keluarga " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbnpwp1" id="rbnpwp1"  value="Y"> YA <input type="radio" name="rbnpwp1" id="rbnpwp1"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Nomor Pokok Wajib Pajak" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpassport" id="rbpassport"  value="Y"> YA <input type="radio" name="rbpassport" id="rbpassport"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Pasport" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkitas" id="rbkitas"  value="Y"> YA <input type="radio" name="rbkitas" id="rbkitas"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="KITAS" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbaktenikah" id="rbaktenikah"  value="Y"> YA <input type="radio" name="rbaktenikah" id="rbaktenikah"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Akte Nikah" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbaktecerai" id="rbaktecerai"  value="Y"> YA <input type="radio" name="rbaktecerai" id="rbaktecerai"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Akte Cerai" disabled="">
                                    
                                </div><!-- /input-group -->
                                
                             <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbstnk" id="rbstnk"  value="Y"> YA <input type="radio" name="rbstnk" id="rbstnk"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="STNK" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbjamsostek" id="rbjamsostek"  value="Y"> YA <input type="radio" name="rbjamsostek" id="rbjamsostek"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Kartu Jamsostek" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
                
             <div class="panel-heading">
		III. Form Keluarga
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbktppas" id="rbktppas"value="Y"> YA <input type="radio" name="rbktppas" id="rbktppas" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Kartu Tanda Penduduk (Istri/Suami)" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbaktelhrpass" id="rbaktelhrpass" value="Y"> YA <input type="radio" name="rbaktelhrpass" id="rbaktelhrpass" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Akte Lahir (Istri/Suami)" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbaktelhranak" id="rbaktelhranak" value="Y"> YA <input type="radio" name="rbaktelhranak" id="rbaktelhranak" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Akte Lahir Anak" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                
            </div><!-- /.row -->
            
             <div class="panel-heading">
		IV. Form Perjanjian
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbspk" id="rbspk"value="Y"> YA <input type="radio" name="rbspk" id="rbspk" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Perjanjian Kerja" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpajak" id="rbpajak" value="Y"> YA <input type="radio" name="rbpajak" id="rbpajak" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Pernyataan Pajak" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbkerahasiaan" id="rbkerahasiaan" value="Y"> YA <input type="radio" name="rbkerahasiaan" id="rbkerahasiaan" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Surat Perjanjian Kerahasiaan" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkodeetik" id="rbkodeetik"  value="Y"> YA <input type="radio" name="rbkodeetik" id="rbkodeetik"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Pernyataan Kode Etik " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpenempatan" id="rbpenempatan"  value="Y"> YA <input type="radio" name="rbpenempatan" id="rbpenempatan"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Pernyataan Penempatan" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpersonnelaction" id="rbpersonnelaction"  value="Y"> YA <input type="radio" name="rbpersonnelaction" id="rbpersonnelaction"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Personnel Action" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbikatandinas" id="rbikatandinas"  value="Y"> YA <input type="radio" name="rbikatandinas" id="rbikatandinas"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Perjanjian Ikatan Dinas" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbkomitmen" id="rbkomitmen"  value="Y"> YA <input type="radio" name="rbkomitmen" id="rbkomitmen"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Surat Komitmen" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->   
            
             <div class="panel-heading">
		V. Form Pendaftaran
                </div>
                <div class="row">
                    <ul>
                    <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbasuransi" id="rbasuransi"value="Y"> YA <input type="radio" name="rbasuransi" id="rbasuransi" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Pendaftaran Asuransi" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpendjamsostek" id="rbpendjamsostek" value="Y"> YA <input type="radio" name="rbpendjamsostek" id="rbpendjamsostek" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Pendaftaran BPJS Ketenagakerjaan" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbbpjspensiun" id="rbbpjspensiun" value="Y"> YA <input type="radio" name="rbbpjspensiun" id="rbbpjspensiun" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text"  class="form-control" aria-label="..." placeholder="Pendaftaran BPJS Pensiun " disabled="">
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                    </ul>
                
                    <ul>
                    <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                              No Rekening &nbsp;&nbsp;
                          </span>
                            <input type="text" name="txtnorek" id="txtnorek" class="form-control" aria-label="..." placeholder="Isi Nomer Rekening" >
                            
                            
                             <span class="input-group-addon">
                            Nama Bank &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          </span>
                            <input type="text" name="txtnamabank" id="txtnamabank" class="form-control" aria-label="..." placeholder="Isi Nama Bank" >
                            
                            <span class="input-group-addon">
                            Cabang &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          </span>
                            <input type="text"  name="txtcabangbank" id="txtcabangbank"  class="form-control" aria-label="..." placeholder="Isi Cabang Bank " >
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
            
            <div class="panel-heading">
		VI. Form HR
                </div>
                <div class="row">
                    <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                          <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbpauli" id="rbpauli"value="Y"> YA <input type="radio" name="rbpauli" id="rbpauli" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Hasil Test Pauli" disabled="">
                            
                            
                             <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbbeta3" id="rbbeta3" value="Y"> YA <input type="radio" name="rbbeta3" id="rbbeta3" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="Beta 3" disabled="">
                            
                            <span class="input-group-addon">
                            <input type="radio" aria-label="..." name="rbwpt" id="rbwpt" value="Y"> YA <input type="radio" name="rbwpt" id="rbwpt" aria-label="Y" value="T"> TIDAK
                          </span>
                            <input type="text" class="form-control" aria-label="..." placeholder="WPT" disabled="">
                        </div><!-- /input-group -->
                </div><!-- /.col-lg-6 --></ul>
                     
                    <!-- baris ke dua -->
                <ul>
                <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpsikorecruitment" id="rbpsikorecruitment"  value="Y"> YA <input type="radio" name="rbpsikorecruitment" id="rbpsikorecruitment"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Psikogram Recruitment " disabled="">


                                     <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbwarteg" id="rbwarteg"  value="Y"> YA <input type="radio" name="rbwarteg" id="rbwarteg"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Warteg" disabled="">
                                    
                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbdisc" id="rbdisc"  value="Y"> YA <input type="radio" name="rbdisc" id="rbdisc"  aria-label="Y" value="T"> TIDAK
                                     </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="DISC" disabled="">
                      </div><!-- /input-group -->
                                
                                    
                 </div><!-- /.col-lg-6 -->
                 </ul>
                    
                     <!-- baris ke tiga -->
                     
                <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbwwcruser" id="rbwwcruser"  value="Y"> YA <input type="radio" name="rbwwcruser" id="rbwwcruser"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Wawancara User" disabled="">


                                    <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbwwcrhr" id="rbwwcrhr"  value="Y"> YA <input type="radio" name="rbwwcrhr" id="rbwwcrhr"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Wawancara HR" disabled="">
                                    
                                    <span class="input-group-addon">
                                         <input type="radio" aria-label="..." name="rbtestkesehatan" id="rbtestkesehatan"  value="Y"> YA <input type="radio" name="rbtestkesehatan" id="rbtestkesehatan"  aria-label="Y" value="T"> TIDAK
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Hasil Test Kesehatan" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
                     
                     <ul>
                   <div class="col-lg-12">
                        <div class="input-group">
                                  <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbpsikoassessment" id="rbpsikoassessment"  value="Y"> YA <input type="radio" name="rbpsikoassessment" id="rbpsikoassessment"  aria-label="Y" value="T"> TIDAK
                                  </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="Psikogram Assessment" disabled="">


                                    <span class="input-group-addon">
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                                    
                                </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->  
                    <!-- document filling -->
                    <div class="panel-heading">
		V. Penyimpanan Dokumen
                </div>
                <div class="row">
                    <ul>
                    <div class="col-lg-12">
                        <div class="input-group">
                            <span class="input-group-addon "> <select class="form-control"  id="txtsimpandmana" id="txtsimpandmana">
                                        <option value="-">-</option>
                                        <option value="sementara">Temporary</option>
                                        <option value="rollopek">Lemari File</option>
                                        <option value="vendor">Vendor </option>
                                </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </span>   
                             <input type="text" class="form-control" name="txtsimpanhardcopy" id="txtsimpanhardcopy" aria-label="..." placeholder="Lokasi Simpan File Hard" enabled="">
                             
                             <span class="input-group-addon">
                                    <input type="radio" aria-label="..." name="rbelo" id="rbelo"  value="Y"> YA <input type="radio" name="rbpsikoassessment" id="rbpsikoassessment"  aria-label="Y" value="T"> TIDAK
                                  </span>
                             <input type="text" class="form-control" size="20" aria-label="..." placeholder="Scan ELO" disabled="">
                                    
                                    <span class="input-group-addon">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </span>
                                    <input type="text" class="form-control" aria-label="..." placeholder="" disabled="">
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                    </ul>
            </div><!-- /.row -->
                     <div class="panel-heading">                    
                        VI. Catatan HRD
                    </div>
                     <ul>
                        <div class="form-group">
                            <label>
                                Comment :
                            </label>
                            <textarea class="form-control col-sm-3" name="txtcathrd" id="txtcathrd" rows="3" cols="3" id="txtcatatanhrd" name="txtcatatanhrd"></textarea>
                        </div>
                     </ul>
                     <p align="center"><br>
                         <input type="submit" name="submit" value="Submit" width="25" height="25" colspan=0 > 
                
            </div>
            </form>  
      <?php
    }             
}
?>