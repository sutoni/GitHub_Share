/*
Navicat MySQL Data Transfer
Source Host     : localhost:3306
Source Database : recruitment_center
Target Host     : localhost:3306
Target Database : recruitment_center
Date: 2015-10-12 07:27:35
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for berkas_employeefile
-- ----------------------------
DROP TABLE IF EXISTS `berkas_employeefile`;
CREATE TABLE `berkas_employeefile` (
  `empno` varchar(11) NOT NULL DEFAULT '',
  `tglterimaberkas` date DEFAULT NULL,
  `srtlamaran` enum('Y','T') DEFAULT NULL,
  `dtpelamar` enum('Y','T') DEFAULT NULL,
  `ijzhama` enum('T','Y') DEFAULT NULL,
  `ijzhdiploma` enum('Y','T') DEFAULT NULL,
  `ijzhsdua` enum('Y','T') DEFAULT NULL,
  `srtcv` enum('Y','T') DEFAULT NULL,
  `srtrefrensi` enum('Y','T') DEFAULT NULL,
  `photo` enum('Y','T') DEFAULT NULL,
  `transkripnilai` enum('Y','T') DEFAULT NULL,
  `ktp` enum('Y','T') DEFAULT NULL,
  `kk` enum('Y','T') DEFAULT NULL,
  `kitas` enum('Y','T') DEFAULT NULL,
  `stnk` enum('Y','T') DEFAULT NULL,
  `sim` enum('Y','T') DEFAULT NULL,
  `npwp` enum('Y','T') DEFAULT NULL,
  `aktenikah` enum('Y','T') DEFAULT NULL,
  `kartujamsostek` enum('Y','T') DEFAULT NULL,
  `aktelahir` enum('Y','T') DEFAULT NULL,
  `passport` enum('Y','T') DEFAULT NULL,
  `aktecerai` enum('Y','T') DEFAULT NULL,
  `ktppasangan` enum('Y','T') DEFAULT NULL,
  `aktelahirpasangan` enum('Y','T') DEFAULT NULL,
  `aktelahiranak` enum('Y','T') DEFAULT NULL,
  `spk` enum('Y','T') DEFAULT NULL,
  `kodeetik` enum('Y','T') DEFAULT NULL,
  `perjanjiandinas` enum('Y','T') DEFAULT NULL,
  `pajak` enum('Y','T') DEFAULT NULL,
  `penempatan` enum('Y','T') DEFAULT NULL,
  `komitmen` enum('Y','T') DEFAULT NULL,
  `kerahasiaan` enum('Y','T') DEFAULT NULL,
  `personactions` enum('Y','T') DEFAULT NULL,
  `pendaftaranasuransi` enum('Y','T') DEFAULT NULL,
  `pendbpjstenagakerja` enum('Y','T') DEFAULT NULL,
  `pendbpjspensiun` enum('Y','T') DEFAULT NULL,
  `norek` varchar(15) DEFAULT NULL,
  `namabank` varchar(25) DEFAULT NULL,
  `cabang` varchar(25) DEFAULT NULL,
  `hasilpauli` enum('Y','T') DEFAULT NULL,
  `psikogramrekrut` enum('Y','T') DEFAULT NULL,
  `wawancarauser` enum('Y','T') DEFAULT NULL,
  `psikogramassess` enum('Y','T') DEFAULT NULL,
  `beta3` enum('Y','T') DEFAULT NULL,
  `warteg` enum('Y','T') DEFAULT NULL,
  `wwcrhr` enum('Y','T') DEFAULT NULL,
  `wpt` enum('Y','T') DEFAULT NULL,
  `disc` enum('Y','T') DEFAULT NULL,
  `mcu` enum('Y','T') DEFAULT NULL,
  `lokasisimpan` varchar(100) DEFAULT NULL,
  `scanelo` enum('Y','T') DEFAULT NULL,
  `istatus` enum('aktif','non','destroy') DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`empno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of berkas_employeefile
-- ----------------------------
