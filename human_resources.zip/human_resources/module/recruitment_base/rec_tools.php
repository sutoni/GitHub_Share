<?php
if($_GET['act']=="input"){
	?>
<br><br>
               
              
              <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Basic Konfigurasi</a></li>
                    <li><a href="?module=view_recbase&act=view_recmethod">Recruitment</a></li>
                    <li class="active">Recruitment Method</li>
                  </ol>
                <!-- /.col-lg-12 -->
           
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Input Data Recruitment Method
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                    <form method="post" role="form" action="?module=simpan&act=input_recmethod">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>ID Recruitment Method</label>
                                            <input class="form-control" placeholder="ID Recruitment Method" name="txtidrecmethod" id="txtidrecmethod">
                                        </div>
                                        <div class="form-group">
                                            <label>Recruitment Method</label>
                                            <input class="form-control" placeholder="Recruitment Method" name="txtrecmethodname" id="txtrecmethodname">
                                        </div>
                                       <div class="form-group">
                                            <label>Recruitment Method Group</label>
                                            <input class="form-control" placeholder="Recruitment Method Group" name="txtrecmethodgroup" id="txtrecmethodgroup">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
<?php } ?>
           
           
 <?php
if($_GET['act']=="edit"){
$id=$_GET[id];	
    ?>
<br><br>
               
              
              <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Basic Konfigurasi</a></li>
                    <li><a href="?module=view_recbase&act=view_recmethod">Recruitment</a></li>
                    <li class="active">Recruitment Method</li>
                  </ol>
                <!-- /.col-lg-12 -->
           
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Update Data Recruitment Method
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form method="post" role="form" action="?module=simpan&act=edit_recmethod">
                                <?php
                                    $query="SELECT * FROM recruitment_method WHERE idrecmethod='$id'";
                                    $result=  mysql_query($query);
                                    $rs=  mysql_fetch_array($result);
                                    
                                ?>
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>ID Recruitment Method</label>
                                            <input class="form-control" placeholder="ID Recruitment Method" name="txtidrecmethod" id="txtidrecmethod" value="<?php echo $rs[idrecmethod]; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Recruitment Method</label>
                                            <input class="form-control" placeholder="Recruitment Method" name="txtrecmethodname" id="txtrecmethodname" value="<?php echo $rs[recmethodname]; ?>">
                                        </div>
                                       <div class="form-group">
                                            <label>Recruitment Method Group</label>
                                            <input class="form-control" placeholder="Recruitment Method Group" name="txtrecmethodgroup" id="txtrecmethodgroup" value="<?php echo $rs[recmethodgroup]; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rs[keterangan]; ?></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
<?php } ?>      