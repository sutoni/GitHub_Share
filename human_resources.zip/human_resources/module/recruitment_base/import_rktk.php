
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
<h2>Import data RKTK to Database</h2>

<form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
<font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
<input type='file' name='filename' size='20'><br>
<input type='submit' name='submit' value='Insert'><input type='submit' name='update' value='Update'></form>
<br>



<?php
print "<p>Catatan :  Apabila data yang diimport adalah data Baru silahkan tekan Insert<br>
              namun bila data yang diimport sudah ada silahkan tekan tombol Update
 </p>";



if(isset($_POST['submit']))
{
$target_path = 'c:\xampp\htdocs\recruitment_center\test';  

$target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
} else{
echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
} // ini untuk mengupload file CSV ke alamat tadi
// ini script untuk mengimport data CSV ke MySQL
$filename=$target_path;
$handle = fopen("$filename", "r");
while (($data = fgetcsv($handle, 10000, ",")) !== FALSE)
{

$import="INSERT into rktk values(
         '$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]',
        '$data[7]','$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]',
        '$data[14]','$data[15]','$data[16]','$data[17]','$data[18]','$data[19]','$data[20]',
        '$data[21]','$data[22]','$data[23]','$data[24]','$data[25]','$data[26]','$data[27]',
        '$data[28]','$data[29]')";
$masuk=  mysql_query($import);


}
fclose($handle);
print "<font face=arial size=2>Order data berhasil</font><BR>";
//ECHO "$import";

}


else
{

print "";
}

?>


</BODY>
</HTML>
