<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Recruitment Plan
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_transrec&act=view_recbudget">Recruitment Plan</a></li>
            <li class="active">Recruitment Budget</li>
          </ol>
        </section>
<?php
include 'config/conn.php';
if($_GET['act']=="input"){
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Budget</h3>
                                  <div class="pull-right hidden-xs"> 
                                     
                                      <a href="?module=rec_budget&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                 <form method="post" role="form" action="?module=simpan&act=input_costbudget">
                                <div class="box-body ">
                                    <button class="btn btn-primary " type="submit">Simpan</button>
                                   
                                    
                                </div>
                                
                            <div class="box-body">
                                   
                                        <table class="table border-left border-right padding-left-lg " >
                                            <tr>
                                                <td>No</td>
                                                <td>id</td>
                                                <td>Cost Item</td>
                                                <td align="center">Budget</td>
                                                <td align="center">Adjusted Budget</td>
                                                <td align="center">Remark</td>
                                                <td align="center">Periode</td>
                                            </tr>
                                            <?php
                                                $sql="SELECT idcostitem, costitem FROM t_rec_costitem ";
                                                $query=  mysql_query($sql);
                                                $year = DATE('Y');
                                                $yearnext = $year;
                                                WHILE($rc=mysql_fetch_array($query))
                                                {
                                                    $nomor++;
                                                        $idcost=$rc[idcostitem];
                                                        $idbudget=$yearnext.$idcost;
                                                        
                                                        
                                                        echo "<tr>";
                                                            echo "<td>$nomor</td>";
                                                            echo "<td>$idbudget <input type='hidden' id='txtidbudget[]' name='txtidbudget[]' value='$idbudget'></td>";
                                                            echo "<td>$rc[costitem]</td>";
                                                            echo "<td align='center'><input type='text' id='txtbudget[]' name='txtbudget[]' align='right'></td>";
                                                            echo "<td align='center'><input type='text' id='txtadjustbudget[]' name='txtadjustbudget[]' align='right' ></td>";
                                                            echo "<td align='center'><input type='text' id='txtremark[]' name='txtremark[]' size=70></td>";
                                                            echo "<td align='center'>$yearnext</td>";
                                                            echo "<td><input class='checkbox' type='checkbox' name='item[]' id=' id='item[]' value='$nomor'></td>";
                                                        echo "</tr>";    
                                                }       
                                            ?>
                                            
                                        </table>      
                                            
                                    

                            </div>
                            <!-- /.row (nested) -->
                        <!-- /.row (nested) -->
                        </form>
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
<?php } ?>

<?php
if($_GET['act']=="budgetperiode"){
        
            $tangkapperiode=$_POST['txtperiode1'];
          
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Budget</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_budget&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                 <form method="post" role="form" action="?module=simpan&act=input_costbudget">
                                <div class="box-body ">
                                    <button class="btn btn-primary " type="submit">Simpan</button>
                                    
                                </div>
                                
                            <div class="box-body">
                                   
                                        <table class="table border-left border-right padding-left-lg " >
                                            <tr>
                                                <td>No</td>
                                                <td>id</td>
                                                <td>Cost Item</td>
                                                <td>Budget</td>
                                                <td>Adjusted Budget</td>
                                                <td>Remark</td>
                                                <td>Periode </td>
                                            </tr>
                                            <?php
                                                
                                            
                                                $sql="SELECT idcostitem, costitem FROM t_rec_costitem ";
                                                $query=  mysql_query($sql);
                                                $year = DATE('Y');
                                                $yearnext = $year;
                                                WHILE($rc=mysql_fetch_array($query))
                                                {
                                                    $nomor++;
                                                        $idcost=$rc[idcostitem];
                                                        $idbudget=$tangkapperiode.$idcost;
                                                        
                                                        
                                                        echo "<tr>";
                                                            echo "<td>$nomor</td>";
                                                            echo "<td>$idbudget <input type='hidden' id='txtidbudget[]' name='txtidbudget[]' value='$idbudget'></td>";
                                                            echo "<td>$rc[costitem]</td>";
                                                            echo "<td align='right'><input type='text' id='txtbudget[]' name='txtbudget[]' align='right'></td>";
                                                            echo "<td align='right'><input type='text' id='txtadjustbudget[]' name='txtadjustbudget[]' align='right' ></td>";
                                                            echo "<td><input type='text' id='txtremark[]' name='txtremark[]' size=70></td>";
                                                            echo "<td>$tangkapperiode</td>";
                                                            echo "<td><input class='checkbox' type='checkbox' name='item[]' id=' id='item[]' value='$nomor'></td>";
                                                        echo "</tr>";    
                                                }       
                                            ?>
                                            
                                        </table>      
                                            
                                    

                            </div>
                            <!-- /.row (nested) -->
                        <!-- /.row (nested) -->
                        </form>
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
<?php } ?>
            
            
            
<?php
if($_GET['act']=="edit"){
    $id=$_GET[id];    
	?>
        <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Cost Budget</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_costitem&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                <form method="post" role="form" action="?module=simpan&act=edit_costbudget">
                                    <?php 
                                        $query="SELECT a.idbudget, b.costitem, a.budget, a.adjust, a.keterangan, a.periode FROM recruitment_budget a 
                                                INNER JOIN t_rec_costitem b ON a.idcostitem=b.idcostitem
                                                WHERE a.idbudget='$id'";
                                        $result=  mysql_query($query);
                                        $rs=  mysql_fetch_array($result);                                    
                                    ?>
                                <div class="col-lg-6">
                                         <div class="form-group">
                                            <label>Id Budget</label>
                                            <input class="form-control" placeholder="idbudget" name="txtidbudget" id="txtidbudget" value="<?php echo $rs[idbudget]; ?>">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Cost Item</label>
                                            <input class="form-control disabled" placeholder="Cost Item Name" name="txtcostitem" id="txtcostitem" value="<?php echo $rs[costitem]; ?>">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Budget</label>
                                            <input class="form-control" placeholder="Cost Item Name" name="txtbudget" id="txtbudget" value="<?php echo $rs[budget]; ?>">
                                        </div>
                                       
                                        <div class="form-group">
                                            <label>Adjusted</label>
                                            <input class="form-control" placeholder="Cost Item Name" name="txtadjust" id="txtadjust" value="<?php echo $rs[adjust]; ?>">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rs[keterangan]; ?></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                           </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
             </section>
            <!-- /.row -->
<?php } ?>
           
      </div> 