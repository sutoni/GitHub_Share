<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        <script>
        $('.dropdown-toggle').dropdown()
        </script>
<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Recruitment
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_transrec&act=view_recbudget">Recruitment Plan</a></li>
            <li class="active">Overview Recruitment Plan</li>
          </ol>
        </section>
   <br>
 
                <a href="?module=view_transrec&act=view_recbudget"><button type="submit" class="btn btn-default">Recruitment Budget</button></a>
                <a href="?module=view_transrec&act=view_recmpl"><button type="submit" class="btn btn-default"  >Man Power Plan</button></a>
                <a href="?module=view_transrec&act=view_recactivity"><button type="submit" class="btn btn-default"  >Activity Plan</button></a>
                
            <!-- /.row -->          
<br><br>
    <?php
    /*
        Overview Position Struktur
    */
    
if($_GET['act']=="view_recbudget"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Recruitment Budget</h3>
                                  
                                    <div class="btn btn-default pull-right ">
                                        <form method="post" role="form" action="?module=rec_budget&act=budgetperiode">
                                        <button class="inline" type="submit">Periode</button>
                                            <select id="txtperiode1" name="txtperiode1" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT periode FROM recruitment_periode ";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                $periode2=$rsd[periode];
                                                                 echo " <option value='$periode2'><a href='?module=rec_budget&act=budgetperiode'>$periode2</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                        
                                      <!--  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                                          Periode
                                          <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                            <?php
                                                $cari="SELECT periode FROM recruitment_periode ";
                                                $dapat=mysql_query($cari);
                                                WHILE($rsd=mysql_fetch_array($dapat))
                                                {
                                                    $periode2=$rs[periode];
                                                    ?>
                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="#"><?php echo "$periode2"; ?></a></li>
                                                    <?php
                                                    
                                                }
                                                
                                            ?>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="#">2015</a></li>
                                            
                                         
                                        </ul>
                                      -->
                                        </form>
                                      </div>
                                     
                                  
                                  
                                
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center">Id Budget</th>
                                            <th class="text-center">Cost Item</th>
                                            <th class="text-center">Budget Plan</th>
                                            <th class="text-center">Adjusted Plan</th>
                                            <th class="text-center">Total Budget</th>
                                            <th class="text-center">Periode</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="SELECT a.idbudget,  b.costitem, a.budget, a.adjust, a.totalbudget, a.periode, a.keterangan
            FROM recruitment_budget a
            INNER JOIN t_rec_costitem b ON a.idcostitem=b.idcostitem
            ";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
            $budget     = number_format($rsa[budget],0,",",".");
            $adjust     = number_format($rsa[adjust],0,",",".");
            $totalbudget     = number_format($rsa[totalbudget],0,",",".");
            
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[idbudget]";  ?></td>
                                            <td><?php echo"$rsa[costitem]";  ?></td>
                                            <td align="right"><?php echo"$budget";  ?></td>
                                            <td align="right"><?php echo"$adjust";  ?></td>
                                            <td align="right"><?php echo"$totalbudget";  ?></td>
                                            <td><?php echo"$rsa[periode]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                         <td class="text-center"><a href="?module=rec_budget&act=edit&id=<?php echo $rsa['idbudget'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                         <a href="?module=simpan&act=hapus_recbudget&id=<?php echo $rsa['idbudget'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                        
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                               <tfoot>
                                        <tr>
                                            <th class="text-center">Id Budget</th>
                                            <th class="text-center">Cost Item</th>
                                            <th class="text-center">Budget Plan</th>
                                            <th class="text-center">Adjusted Plan</th>
                                            <th class="text-center">Total Budget</th>
                                            <th class="text-center">Periode</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>



    <?php
    /*
        Overview Position Class
    */
if($_GET['act']=="view_recmpl"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Man Power Plan</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_mpl&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">ID Recruitment Plan</th>
                                            <th class="text-center">Id Position</th>
                                            <th class="text-center">Position Title</th>
                                            <th class="text-center">Company Office</th>
                                            <th class="text-center">Plan</th>
                                            <th class="text-center">Adjusted Plan</th>
                                            <th class="text-center">Total Plan</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="  SELECT a.idrecplan, a.posid, b.position_title, c.Nm_comp_office
                ,b.organization_code ,a.idcompdetail, a.target, a.adjust, a.totaltarget, a.keterangan
                FROM recruitment_plan a
                LEFT JOIN position_struktur b ON a.posid = b.id_position
                INNER JOIN company_office_detail c ON a.idcompdetail=c.idcompdetail";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[idrecplan]";  ?></td>
                                            <td><?php echo"$rsa[posid]";  ?></td>
                                            <td><?php echo"$rsa[position_title]";  ?></td>
                                            <td><?php echo"$rsa[Nm_comp_office]";  ?></td>
                                            <td><?php echo"$rsa[target]";  ?></td>
                                            <td><?php echo"$rsa[adjust]";  ?></td>
                                            <td><?php echo"$rsa[totaltarget]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                        <td class="text-center"><a href="?module=rec_method&act=edit&id=<?php echo $rsa['idrecmethod'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                        <a href="?module=simpan&act=hapus_recmethod&id=<?php echo $rsa['idrecmethod'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">ID Recruitment Plan</th>
                                            <th class="text-center">Id Position</th>
                                            <th class="text-center">Position Title</th>
                                            <th class="text-center">Company Office</th>
                                            <th class="text-center">Plan</th>
                                            <th class="text-center">Adjusted Plan</th>
                                            <th class="text-center">Total Plan</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>



    <?php
    /*
        Overview Industry Area
    */
if($_GET['act']=="view_recactivity"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Recruitment Activity</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_activity&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center" rowspan="2">idrec_activity</th>
                                            <th class="text-center" rowspan="2">Tempat Event</th>
                                            <th class="text-center" rowspan="2">Start Date</th>
                                            <th class="text-center" rowspan="2">End Date</th>
                                            <th class="text-center" rowspan="2">PIC</th>
                                            <th class="text-center"  colspan="8">Biaya</th>                   
                                            <th class="text-center" rowspan="2">Aksi</th>

                                        </tr>
                                        <tr>
                                            <th class="text-center">Transportasi</th>
                                            <th class="text-center">Makan</th>
                                            <th class="text-center">Penginapan</th>
                                            <th class="text-center">Iklan</th>
                                            <th class="text-center">Sewa Ruangan</th>
                                            <th class="text-center">Alat Test</th>
                                            <th class="text-center">Lain-lain</th>
                                            <th class="text-center">Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="  SELECT a.idrec_activity, a.tempat, a.kontakperson, a.kontakno, a.startdate, a.enddate, a.pic, a.keterangan,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='AT' AND b.idrec_activity=a.idrec_activity )AS AT,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='CK' AND b.idrec_activity=a.idrec_activity )AS CK,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='IK' AND b.idrec_activity=a.idrec_activity )AS IK,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='IP' AND b.idrec_activity=a.idrec_activity )AS IP,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='LN' AND b.idrec_activity=a.idrec_activity )AS LN,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='MK' AND b.idrec_activity=a.idrec_activity )AS MK,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='SR' AND b.idrec_activity=a.idrec_activity )AS SR,
                (SELECT b.budget  FROM recruitment_activitydetails b WHERE b.idcostitem='TR' AND b.idrec_activity=a.idrec_activity )AS TR
                FROM recruitment_activity a
                INNER JOIN recruitment_activitydetails b ON a.idrec_activity=b.idrec_activity
                GROUP BY a.idrec_activity" ;
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[idrec_activity]";  ?></td>
                                            <td><?php echo"$rsa[tempat]";  ?></td>
                                            <td><?php echo"$rsa[startdate]";  ?></td>
                                            <td><?php echo"$rsa[enddate]";  ?></td>
                                            <td><?php echo"$rsa[pic]";  ?></td>
                                            <td><?php echo"$rsa[TR]";  ?></td>
                                            <td><?php echo"$rsa[MK]";  ?></td>
                                            <td><?php echo"$rsa[IP]";  ?></td>
                                            <td><?php echo"$rsa[IK]";  ?></td>
                                            <td><?php echo"$rsa[SR]";  ?></td>
                                            <td><?php echo"$rsa[AT]";  ?></td>
                                            <td><?php echo"$rsa[LN]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                        <td class="text-center"><a href="?module=rec_activity&act=edit&id=<?php echo $rsa['idrec_activity'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                        <a href="?module=simpan&act=hapus_recactivity&id=<?php echo $rsa['idrec_activity'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>        
                                        
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="text-center" >idrec_activity</th>
                                            <th class="text-center" >Tempat Event</th>
                                            <th class="text-center" >Start Date</th>
                                            <th class="text-center" >End Date</th>
                                            <th class="text-center" >PIC</th>
                                            <th class="text-center">Transportasi</th>
                                            <th class="text-center">Makan</th>
                                            <th class="text-center">Penginapan</th>
                                            <th class="text-center">Iklan</th>
                                            <th class="text-center">Sewa Ruangan</th>
                                            <th class="text-center">Alat Test</th>
                                             <th class="text-center">Lain-lain</th>
                                            <th class="text-center">Keterangan</th>
                                            
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>

            
 <?php
    /*
        Overview  Job Family
    */
if($_GET['act']=="view_reccost"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Recruitment Cost Item</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_costitem&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Id Cost Item</th>                                            
                                            <th class="text-center">Cost Item</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from t_rec_costitem";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id]";  ?></td>
                                            <td><?php echo"$rsa[costitem]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            

                                            <td class="text-center"><a href="?module=rec_costitem&act=edit&id=<?php echo $rsa['id'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                        <a href="?module=simpan&act=hapus_costitem&id=<?php echo $rsa['id'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>        
                                            
                                            
                                        </tr>

<?php }
?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="text-center">Id Cost Item</th>                                            
                                            <th class="text-center">Cost Item</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>

      
 <?php
    /*
        Overview  Functional Area
    */
if($_GET['act']=="view_funcarea"){
	?>
              
           <div class="row">
                
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview  Functional Area
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="?module=pos_areajob&act=input"><button type="submit" class="btn btn-info text-right"  >Add</button></a>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Id functional area</th>                                                                                        
                                            <th class="text-center">Functional area name</th>                                                                                        
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from functional_area";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id_functarea]";  ?></td>
                                            <td><?php echo"$rsa[func_area]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            

                                        <td class="text-center"><a href="?module=pos_areajob&act=edit_jobfunctarea&id=<?php echo $rsa['id_functarea'] ?>"><button type="button" class="btn btn-info">Edit</button> 
                                                <a href="?module=simpan&act=hapus_funcarea&id=<?php echo $rsa['id_functarea'] ?>"><button type="button" class="btn btn-danger">Hapus</button></a></td>

                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">Id functional area</th>                                                                                        
                                            <th class="text-center">Functional area name</th>                                                                                        
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>
</div>
            <!-- /.row -->