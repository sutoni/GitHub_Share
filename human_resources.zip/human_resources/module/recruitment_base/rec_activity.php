<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Recruitment Plan
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_transrec&act=view_recbudget">Recruitment Plan</a></li>
            <li class="active">Recruitment Budget</li>
          </ol>
        </section>

<?php 
include 'config/conn.php';

if($_GET['act']=="input"){
        
            $tangkapperiode=$_POST['txtperiode1'];
          
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                  <form method="post" role="form" action="?module=simpan&act=input_recactivity">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Activity</h3>
                                  <div class="pull-right hidden-xs">
                                    
                                       <button type="submit" name="btnsubmit" class="btn " value="terima" >
                                           Save
                                            <span class="badge" >
                                                 <i class="fa fa-save"></i> 
                                            </span> 
                                       </button>&nbsp;&nbsp;&nbsp;&nbsp;
                                  </div> 
                                </div><!-- /.box-header -->
                         
                              <div class="box-body"> 
                                 <div class=" col-lg-6">
                                    <div class="form-group">
                                        <label >Nama Event &nbsp;&nbsp;</label>
                                            <select id="txteventid" name="txteventid" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT idevent, namaevent FROM recruitment_event ";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                $idevent=$rsd[idevent];
                                                                $namaevent=$rsd[namaevent];
                                                                 echo " <option value='$idevent'>$namaevent</option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                    </div>
                                        <div class="form-group">
                                            <label>Tempat Event</label>
                                            <input class="form-control" placeholder="Tempat diadakan event recruitment" name="txttempatevent" id="txttempatevent">
                                        </div>
                                        <div class="form-group">
                                            <label>Kontak Person</label>
                                            <input class="form-control" placeholder="Kontak Person Tempat Event" name="txtkontakperson" id="txtkontakperson">
                                        </div>
                                        <div class="form-group">
                                            <label>Kontak Number / Phone</label>
                                            <input class="form-control" placeholder="Kontak Telpon Tempat Event" name="txtkontakno" id="txtkontakno">
                                        </div>
                                         <div class="form-group" > 
                                        <label class="control-label"> Tanggal Awal Event </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglawal" id="txttglawal">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                         </div>
                                    
                                        <div class="form-group" > 
                                        <label class="control-label"> Tanggal Terakhir Event </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglakhir" id="txttglakhir">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                                        <div class="form-group">
                                            <label>Initial PIC</label>
                                            <input class="form-control" placeholder="Penanggung Jawab Event" name="txtpic" id="txtpic">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan berkenaan pelaksanaan event" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>
                                        
                                </div>
                                     
                                <div class=" col-lg-6">
                                   
                                        <table class="table border-left border-right padding-left-lg " >
                                            <tr>
                                                <td>No</td>
                                                <td>id</td>
                                                <td>Cost Item</td>
                                                <td>Budget</td>
                                               <td>Aksi</td>
                                            </tr>
                                            <?php
                                                
                                            
                                                $sql="SELECT idcostitem, costitem FROM t_rec_costitem ";
                                                $query=  mysql_query($sql);
                                                $year = DATE('Y');
                                                $yearnext = $year;
                                                WHILE($rc=mysql_fetch_array($query))
                                                {
                                                    $nomor++;
                                                        $idcost=$rc[idcostitem];
                                                        
                                                        
                                                        
                                                        echo "<tr>";
                                                            echo "<td>$nomor</td>";
                                                            echo "<td>$idcost <input type='hidden' id='txtidcost[]' name='txtidcost[]' value='$idcost'></td>";
                                                            echo "<td>$rc[costitem]</td>";
                                                            echo "<td><input type='text' id='txtbudget[]' name='txtbudget[]' align='right'></td>";
                                                          
                                                            echo "<td><input class='checkbox' type='checkbox' name='item[]' id=' id='item[]' value='$nomor' checked='checked' ></td>";
                                                        echo "</tr>";    
                                                }       
                                            ?>
                                            
                                        </table>      
                                            
                                    

                            </div>
                            </div>        
                            <!-- /.row (nested) -->
                        <!-- /.row (nested) -->
                        </form>
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
<?php }     
            
            
if($_GET['act']=="edit"){
            
            $id=$_GET['id'];
            $tangkapperiode=$_POST['txtperiode1'];
            $tarik="SELECT a.idrec_activity, b.namaevent, a.tempat, a.kontakperson, a.kontakno, a.startdate, a.enddate, a.pic, a.keterangan, a.istatus
                    FROM recruitment_activity a
                    INNER JOIN recruitment_event b ON b.idevent=substr(a.idrec_activity,1,2)
                    WHERE a.idrec_activity='$id'";
            $hasiltarik=  mysql_query($tarik);
            $rst= mysql_fetch_array($hasiltarik);       
            $event=$rst['namaevent'];
            $istatus=$rst['istatus'];
            $tempat=$rst['tempat'];
            $kontakperson=$rst['kontakperson'];
            $kontakno=$rst['kontakno'];
            $startdate=$rst['startdate'];
            $enddate=$rst['enddate'];
            $pic=$rst['pic'];
            $keterangan=$rst['keterangan'];
            $idrec_activity=$rst['idrec_activity'];
            
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                  <form method="post" role="form" action="?module=simpan&act=edit_recactivity&id=<?php echo "$idrec_activity" ?>">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Activity</h3>
                                  <div class="pull-right hidden-xs">
                                        
                                       <button type="submit" name="btnsubmit" class="btn " value="done" >
                                           Done
                                            <span class="badge" >
                                                 <i class="fa fa-check-square"></i> 
                                            </span> 
                                       </button>
                                       <button type="submit" name="btnsubmit" class="btn " value="cancel" >
                                           Cancel
                                            <span class="badge" >
                                                 <i class="fa fa-thumbs-down"></i> 
                                            </span> 
                                       </button>
                                       <button type="submit" name="btnsubmit" class="btn " value="update" >
                                           Update
                                            <span class="badge" >
                                                 <i class="fa fa-edit"></i> 
                                            </span> 
                                       </button>&nbsp;&nbsp;&nbsp;&nbsp;
                                  </div> 
                                </div><!-- /.box-header -->
                         
                              <div class="box-body"> 
                                 <div class=" col-lg-6">
                                    <div class="form-group">
                                        <label >Nama Event &nbsp;&nbsp;</label>
                                            <select id="txteventid" name="txteventid" class="form-control inline">
                                                <option value="<?php echo "$event"; ?>"><?php echo "$event"; ?></option>
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT idevent, namaevent FROM recruitment_event ";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                $idevent=$rsd[idevent];
                                                                $namaevent=$rsd[namaevent];
                                                                 echo " <option value='$idevent'>$namaevent</option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                    </div>
                                        <div class="form-group">
                                            <label>Tempat Event</label>
                                            <input class="form-control" placeholder="Tempat diadakan event recruitment" name="txttempatevent" id="txttempatevent" value="<?php echo "$tempat"; ?>"></div>
                                        <div class="form-group">
                                            <label>Kontak Person</label>
                                            <input class="form-control" placeholder="Kontak Person Tempat Event" name="txtkontakperson" id="txtkontakperson" value="<?php echo "$kontakperson"; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Kontak Number / Phone</label>
                                            <input class="form-control" placeholder="Kontak Telpon Tempat Event" name="txtkontakno" id="txtkontakno" value="<?php echo "$kontakno"; ?>">
                                        </div>
                                         <div class="form-group" > 
                                        <label class="control-label"> Tanggal Awal Event </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglawal" id="txttglawal" value="<?php echo "$startdate"; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                         </div>
                                    
                                        <div class="form-group" > 
                                        <label class="control-label"> Tanggal Terakhir Event </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txttglakhir" id="txttglakhir" value="<?php echo "$enddate"; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>
                                        <p></p>
                                        <!-- this java script must be appear when you use twitter bootstrop -->
                                        <script src="js/jquery.js"></script>


                                        <!--this datepicker java script for bootstrap 3-->
                                        <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                        </script>
                                        <div class="form-group">
                                            <label>Initial PIC</label>
                                            <input class="form-control" placeholder="Penanggung Jawab Event" name="txtpic" id="txtpic" value="<?php echo "$pic"; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan berkenaan pelaksanaan event" name="txtketerangan" id="txtketerangan" rows="3" value="<?php echo "$keterangan"; ?>"></textarea>
                                        </div>
                                        
                                </div>
                                     
                                <div class=" col-lg-6">
                                   
                                        <table class="table border-left border-right padding-left-lg " >
                                            <tr>
                                                <td>No</td>
                                                <td>id</td>
                                                <td>Cost Item</td>
                                                <td>Budget</td>
                                               <td>Aksi</td>
                                            </tr>
                                            <?php
                                                
                                            
                                                $sql="SELECT a.idcostitem, b.costitem, a.budget
                                                        FROM recruitment_activitydetails a INNER JOIN t_rec_costitem b ON a.idcostitem=b.idcostitem 
                                                        WHERE idrec_activity='$id'";
                                                $query=  mysql_query($sql);
                                                $year = DATE('Y');
                                                $yearnext = $year;
                                                WHILE($rc=mysql_fetch_array($query))
                                                {
                                                    $nomor++;
                                                        $idcost=$rc[idcostitem];
                                                        
                                                        $budgetnya=round($rc[budget],2);
                                                        
                                                        echo "<tr>";
                                                            echo "<td>$nomor</td>";
                                                            echo "<td>$idcost <input type='hidden' id='txtidcost[]' name='txtidcost[]' value='$idcost'></td>";
                                                            echo "<td>$rc[costitem]</td>";
                                                            echo "<td><input type='text' id='txtbudget[]' name='txtbudget[]' align='right'  value='$budgetnya'></td>";
                                                          
                                                            echo "<td><input class='checkbox' type='checkbox' name='item[]' id=' id='item[]' value='$nomor' checked='checked'></td>";
                                                        echo "</tr>";    
                                                }       
                                            ?>
                                            
                                        </table>      
                                            
                                    

                            </div>
                             <div class="btn-default">
                                 <button class="btn-default primary" name="status"  value="<?php  echo '<td>$rst[istatus]</td>';?>"></button> 
                             </div>               
                            </div>        
                            <!-- /.row (nested) -->
                        <!-- /.row (nested) -->
                        </form>
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
<?php } ?>
           
      </div> 