<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Recruitment Base
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_recbase&act=view_recmethod">Recruitment Base</a></li>
            <li class="active">Recruitment Method</li>
          </ol>
        </section>
<?php
if($_GET['act']=="input"){
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Event</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_method&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_recmethod">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>ID Recruitment Method</label>
                                            <input class="form-control" placeholder="ID Recruitment Method" name="txtidrecmethod" id="txtidrecmethod">
                                        </div>
                                        <div class="form-group">
                                            <label>Recruitment Method</label>
                                            <input class="form-control" placeholder="Recruitment Method" name="txtrecmethodname" id="txtrecmethodname">
                                        </div>
                                       <div class="form-group">
                                            <label>Recruitment Method Group</label>
                                            <input class="form-control" placeholder="Recruitment Method Group" name="txtrecmethodgroup" id="txtrecmethodgroup">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                         </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
<?php } ?>
           
           
 <?php
if($_GET['act']=="edit"){
$id=$_GET[id];	
    ?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Event</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_method&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                <form method="post" role="form" action="?module=simpan&act=edit_recmethod">
                                <?php
                                    $query="SELECT * FROM recruitment_method WHERE idrecmethod='$id'";
                                    $result=  mysql_query($query);
                                    $rs=  mysql_fetch_array($result);
                                    
                                ?>
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>ID Recruitment Method</label>
                                            <input class="form-control" placeholder="ID Recruitment Method" name="txtidrecmethod" id="txtidrecmethod" value="<?php echo $rs[idrecmethod]; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Recruitment Method</label>
                                            <input class="form-control" placeholder="Recruitment Method" name="txtrecmethodname" id="txtrecmethodname" value="<?php echo $rs[recmethodname]; ?>">
                                        </div>
                                       <div class="form-group">
                                            <label>Recruitment Method Group</label>
                                            <input class="form-control" placeholder="Recruitment Method Group" name="txtrecmethodgroup" id="txtrecmethodgroup" value="<?php echo $rs[recmethodgroup]; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rs[keterangan]; ?></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                         </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
<?php } ?>      
      </div>