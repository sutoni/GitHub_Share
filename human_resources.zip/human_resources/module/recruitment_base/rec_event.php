<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Recruitment Base
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_recbase&act=view_recevent">Recruitment Base</a></li>
            <li class="active">Recruitment Event</li>
          </ol>
        </section>

<?php
if($_GET['act']=="input"){
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Event</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_event&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_recevent">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Event ID</label>
                                            <input class="form-control" placeholder="Nama Event" name="txteventid" id"txteventid">
                                        </div>
                                    
                                       <div class="form-group">
                                            <label>Nama Event</label>
                                            <input class="form-control" placeholder="Nama Event" name="txtnamaevent" id="txtnamaevent">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>
                                    
                                          <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>

                                        <div class="form-group col-lg-5"> 
                                            <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                                <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                    <input class="form-control" type="text" name="txtvalidto" id="txtvalidto">
                                                    <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                                </div>
                                        </div>
                                   
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                       <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
           <?php } ?>
           
 <?php
if($_GET['act']=="edit"){
    $id=$_GET[id];
	?>  
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Event</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_event&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=edit_recevent">
                                <?php
                                    $query="SELECT * FROM recruitment_event WHERE idevent ='$id'";
                                    $result=  mysql_query($query);
                                    $rs=  mysql_fetch_array($result);
                                    
                                ?>
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Event ID</label>
                                            <input class="form-control" placeholder="Nama Event" name="txteventid" id="txteventid" value="<?php echo $rs[idevent]; ?>">
                                        </div>
                                    
                                       <div class="form-group">
                                            <label>Nama Event</label>
                                            <input class="form-control" placeholder="Nama Event" name="txtnamaevent" id="txtnamaevent" value="<?php echo $rs[namaevent]; ?>">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rs[keterangan]; ?></textarea>
                                        </div>
                                    
                                          <div class="form-group col-lg-5"> 
                                        <label class="control-label"> Valid From &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                            <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                <input class="form-control" type="text" name="txtvalidfrom" id="txtvalidfrom" value="<?php echo $rs[validfrom]; ?>">
                                                <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>
                                        </div>

                                        <div class="form-group col-lg-5"> 
                                            <label class="control-label"> Valid To &nbsp;&nbsp;&nbsp;&nbsp; </label>
                                                <div class="input-group date" data-date="" data-date-format="yyyy-mm-dd">
                                                    <input class="form-control" type="text" name="txtvalidto" id="txtvalidto" value="<?php echo $rs[validto]; ?>">
                                                    <span class="input-group-addon" id=".input-group.date"><i class="glyphicon glyphicon-calendar"></i></span>
                                                </div>
                                        </div>
                                   
                                      <!-- this java script must be appear when you use twitter bootstrop -->
                                    <script src="js/jquery.js"></script>


                                     <!--this datepicker java script for bootstrap 3-->
                                    <script src="js/bootstrap-datepicker3.js"></script>

                                        <script>
                                        //options method for call datepicker
                                        $(".input-group.date").datepicker({ autoclose: true, todayHighlight: true });

                                    </script>
                                        

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                         </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
           <?php } ?>
           
      </div>  