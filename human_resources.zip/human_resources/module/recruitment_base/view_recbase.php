<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
     
<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Recruitment Base
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_recbase&act=view_recevent">Recruitment Base</a></li>
            <li class="active">Overview Recruitment Base</li>
          </ol>
        </section>

 
                <a href="?module=view_recbase&act=view_recevent"><button type="submit" class="btn btn-default">Overview Recruitment Event</button></a>
                <a href="?module=view_recbase&act=view_recmethod"><button type="submit" class="btn btn-default"  >Overview Rec Method</button></a>
                <a href="?module=view_recbase&act=view_recperiode"><button type="submit" class="btn btn-default"  >Overview Rec Periode</button></a>
                <a href="?module=view_recbase&act=view_jobfam"><button type="submit" class="btn btn-default"  >Overview Rec Tools</button></a>
                <a href="?module=view_recbase&act=view_reccost"><button type="submit" class="btn btn-default"  >Overview Rec Cost Item</button></a>
            <!-- /.row -->          
<br><br>
    <?php
    /*
        Overview Position Struktur
    */
    
if($_GET['act']=="view_recevent"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Recruitment Event</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_event&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center">Id Event</th>
                                            <th class="text-center">Nama Event</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from recruitment_event";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[idevent]";  ?></td>
                                            <td><?php echo"$rsa[namaevent]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            <td><?php echo"$rsa[validfrom]";  ?></td>
                                            <td><?php echo"$rsa[validto]";  ?></td>
                                            

                                         <td class="text-center"><a href="?module=rec_event&act=edit&id=<?php echo $rsa['idevent'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                         <a href="?module=simpan&act=hapus_recevent&id=<?php echo $rsa['idevent'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                        
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                               <tfoot>
                                        <tr>
                                            <th class="text-center">Id Event</th>
                                            <th class="text-center">Nama Event</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>



    <?php
    /*
        Overview Position Class
    */
if($_GET['act']=="view_recmethod"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Recruitment Method</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_method&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">ID Recruitment Method</th>
                                            <th class="text-center">Recruitment Method</th>
                                            <th class="text-center">Recruitment Method Group</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from recruitment_method";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[idrecmethod]";  ?></td>
                                            <td><?php echo"$rsa[recmethodname]";  ?></td>
                                            <td><?php echo"$rsa[recmethodgroup]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            
                                        <td class="text-center"><a href="?module=rec_method&act=edit&id=<?php echo $rsa['idrecmethod'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                        <a href="?module=simpan&act=hapus_recmethod&id=<?php echo $rsa['idrecmethod'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>    
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">ID Recruitment Method</th>
                                            <th class="text-center">Recruitment Method</th>
                                            <th class="text-center">Recruitment Method Group</th>
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>



    <?php
    /*
        Overview Industry Area
    */
if($_GET['act']=="view_recperiode"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Recruitment Periode</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_periode&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Recruitment Periode</th>                                            
                                            <th class="text-center">Tahun</th>                                            
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from recruitment_periode";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[recperiode]";  ?></td>
                                            <td><?php echo"$rsa[periode]";  ?></td>
                                            <td><?php echo"$rsa[validfrom]";  ?></td>
                                            <td><?php echo"$rsa[validto]";  ?></td>
                                            
                                        <td class="text-center"><a href="?module=rec_periode&act=edit&id=<?php echo $rsa['recperiode'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                        <a href="?module=simpan&act=hapus_recperiode&id=<?php echo $rsa['recperiode'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>        
                                        
                                        
                                        </tr>

<?php }
?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="text-center">Recruitment Periode</th>                                            
                                            <th class="text-center">Tahun</th>                                            
                                            <th class="text-center">Valid From</th>
                                            <th class="text-center">Valid To</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>

            
 <?php
    /*
        Overview  Job Family
    */
if($_GET['act']=="view_reccost"){
	?>
              
           <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Overview Recruitment Cost Item</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_costitem&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                
                               <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Id Cost Item</th>                                            
                                            <th class="text-center">Cost Item</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from t_rec_costitem";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[idcostitem]";  ?></td>
                                            <td><?php echo"$rsa[costitem]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            

                                            <td class="text-center"><a href="?module=rec_costitem&act=edit&id=<?php echo $rsa['id'] ?>"><i class="fa fa-edit text-success"></i></a> | 
                                        <a href="?module=simpan&act=hapus_costitem&id=<?php echo $rsa['id'] ?>"><i class="fa fa-trash-o text-success"></i></a></td>        
                                            
                                            
                                        </tr>

<?php }
?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="text-center">Id Cost Item</th>                                            
                                            <th class="text-center">Cost Item</th>                                            
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>

      
 <?php
    /*
        Overview  Functional Area
    */
if($_GET['act']=="view_funcarea"){
	?>
              
           <div class="row">
                
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Overview  Functional Area
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="?module=pos_areajob&act=input"><button type="submit" class="btn btn-info text-right"  >Add</button></a>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Id functional area</th>                                                                                        
                                            <th class="text-center">Functional area name</th>                                                                                        
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>

                                        </tr>
                                    </thead>
                                    <tbody>
<?php
include "config/conn.php";
$no=1;
	$sql="select * from functional_area";
        $hasil1=  mysql_query($sql);
	
        while($rsa=mysql_fetch_array($hasil1)){
	
?>                                        <tr class="odd gradeX">
                                            <td><?php echo"$rsa[id_functarea]";  ?></td>
                                            <td><?php echo"$rsa[func_area]";  ?></td>
                                            <td><?php echo"$rsa[keterangan]";  ?></td>
                                            

                                        <td class="text-center"><a href="?module=pos_areajob&act=edit_jobfunctarea&id=<?php echo $rsa['id_functarea'] ?>"><button type="button" class="btn btn-info">Edit</button> 
                                                <a href="?module=simpan&act=hapus_funcarea&id=<?php echo $rsa['id_functarea'] ?>"><button type="button" class="btn btn-danger">Hapus</button></a></td>

                                        </tr>

<?php }
?>
                                    </tbody>
                                <tfoot>
                                        <tr>
                                            <th class="text-center">Id functional area</th>                                                                                        
                                            <th class="text-center">Functional area name</th>                                                                                        
                                            <th class="text-center">Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              <!--   </div>
                /.col-lg-12 -->
            <!--</div>
             /.row -->
            
            </div><!-- /.row -->
        </section><!-- /.content -->
  <?php } ?>
</div>
            <!-- /.row -->