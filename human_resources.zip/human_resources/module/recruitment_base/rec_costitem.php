<!-- Content Wrapper. Contains page content -->
      <div class="table-responsive">
   <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
            &nbsp;Recruitment Base
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-female"></i> Home</a></li>
            <li><a href="?module=view_recbase&act=view_reccost">Recruitment Base</a></li>
            <li class="active">Recruitment Cost Item</li>
          </ol>
        </section>
<?php
if($_GET['act']=="input"){
	?>
            <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Cost Item</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_costitem&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                    <form method="post" role="form" action="?module=simpan&act=input_costitem">

                                <div class="col-lg-6">
                                         <div class="form-group">
                                            <label>Id Cost Item</label>
                                            <input class="form-control" placeholder="Cost Item Name" name="txtidcostitem" id="txtidcostitem">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Cost Item</label>
                                            <input class="form-control" placeholder="Cost Item Name" name="txtcostitem" id="txtcostitem">
                                        </div>
                                       
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                  </div>
            </div>
            </section>
            <!-- /.row -->
<?php } ?>

<?php
if($_GET['act']=="edit"){
    $id=$_GET[id];    
	?>
        <section class="content">
             <!-- /.row -->
            <div class="row">
                  <div class="col-xs-12">    
               
                              <div class="box">
                                <div class="box-header">
                                  <h3 class="box-title">Recuitment Cost Item</h3>
                                  <div class="pull-right hidden-xs">
                                      <a href="?module=rec_costitem&act=input"><i class="fa fa-plus text-success"></i></a>&nbsp;&nbsp;
                                      
                                  </div> 
                                </div><!-- /.box-header -->
                                
                            <div class="box-body">
                                <form method="post" role="form" action="?module=simpan&act=edit_costitem">
                                    <?php 
                                        $query="SELECT * FROM t_rec_costitem WHERE id='$id'";
                                        $result=  mysql_query($query);
                                        $rs=  mysql_fetch_array($result);                                    
                                    ?>
                                <div class="col-lg-6">
                                         <div class="form-group">
                                            <label>Id Cost Item</label>
                                            <input class="form-control" placeholder="Cost Item Name" name="txtidcostitem" id="txtidcostitem" value="<?php echo $rs[id]; ?>">
                                        </div>
                                    
                                        <div class="form-group">
                                            <label>Cost Item</label>
                                            <input class="form-control" placeholder="Cost Item Name" name="txtcostitem" id="txtcostitem" value="<?php echo $rs[costitem]; ?>">
                                        </div>
                                       
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <textarea class="form-control" placeholder="Keterangan" name="txtketerangan" id="txtketerangan" rows="3"><?php echo $rs[keterangan]; ?></textarea>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Update Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                           </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
             </section>
            <!-- /.row -->
<?php } ?>
           
      </div> 