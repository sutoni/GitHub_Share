
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
        <section class="content-header">
          <h1> Import data PRP Employee </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Import</a></li>
            <li class="active">PRP Employee</li>
          </ol>
        </section>
            <div class="row">
                  <div class="col-xs-12">    
                            
                              <div class="box">
                                <div class="box-header">
                                 
                                </div><!-- /.box-header -->
                                <div class="box col-xs-12">
                                    <br><br>
                            <form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
                            <font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
                            <input type='file' name='filename' size='20'><br>
                            <input type='submit' name='submit' value='Insert '><input type='submit' name='submit' value='Update'></form>
                            <br>



                            <?php
                            print "<p>Catatan :  Apabila data yang diimport adalah data Baru silahkan tekan Insert<br>
                                          namun bila data yang diimport sudah ada silahkan tekan tombol Update
                             </p>";

                             include "config/conn.php";   

                            if(isset($_POST['submit']))
                            {
                            $target_path = 'c:\xampp\htdocs\human_resources\test';  

                            $target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

                            if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
                            echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
                            } else{
                            echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
                            } // ini untuk mengupload file CSV ke alamat tadi
                            // ini script untuk mengimport data CSV ke MySQL
                            $filename=$target_path;
                            $handle = fopen("$filename", "r");
                            while (($data = fgetcsv($handle, 30000, ",")) !== FALSE)
                            {
                                $idbaru=$data[0];
                                $empno=$data[1];
                                $effdate=$data[11];
                                //$idbaru=$empno.$effdate;
                                $querycek="SELECT COUNT(id_prp)as Jumlah
                                           FROM prp_information
                                           WHERE id_prp='$idbaru'
                                            ";
                                $hasilcek=mysql_query($querycek);
                                 
                                $row=  mysql_fetch_array($hasilcek);
                                $tglsekarang=DATE('Y-m-d');
                                $user=$_SESSION['username'];
                                    $row1=$row[Jumlah];
                                    if($row1 > 0){
                                        
                                        $empno=$data[1];
                                        $lastnilai=$data[9];
                                        $curnilai=$data[10];
                                        $lasttb=$data[11];
                                        $draft_tbcur=$data[12];
                                        $tbfinal=$data[13];
                                        $actionplan=$data[14];
                                        $waktuaction=$data[15];
                                        $backgroundplan=$data[16];
                                        $waktuback=$data[17];
                                        $lastnoteplus=$data[18];
                                        $curnoteplus=$data[19];
                                        $lastnotemin=$data[20];
                                        $curnotemin=$data[21];
                                        $lastdevimplement=$data[22];
                                        $waktuimplement=$data[23];
                                        $curdevelopment=$data[24];
                                        $curwaktudev=$data[25];
                                        $loginput=$tglsekarang;
                                        $logupdate=$tglsekarang;
                                        $loguser=$user;
                                       
                                        
                                       $updateexist    =" UPDATE prp_information SET
                                                            empno      =   '$empno',
                                                            lastnilai       =   '$lastnilai',
                                                            curnilai           =   '$curnilai',
                                                            lasttb     =   '$lasttb',
                                                            draft_tbcur        =   '$draft_tbcur',
                                                            tbfinal       =   '$tbfinal',
                                                            actionplan      =   '$actionplan',
                                                            waktuaction            =   '$waktuaction',
                                                            backgroundplan          =   '$backgroundplan',
                                                            waktuback         =   '$waktuback',
                                                            lastnoteplus    =   '$lastnoteplus',
                                                            curnoteplus       =   '$curnoteplus',
                                                            lastnotemin       =   '$lastnotemin',
                                                                
                                                            curnotemin       =   '$curnotemin',
                                                            lastdevimplement       =   '$lastdevimplement',
                                                            waktuimplement       =   '$waktuimplement',
                                                            curdevelopment       =   '$curdevelopment',
                                                            curwaktudev       =   '$curwaktudev',
                                                            
                                                            logupdate       =   '$logupdate',
                                                            loguser       =   '$loguser'

                                                            WHERE id_prp  =   '$idbaru'";       
                                                        $masuk=  mysql_query($updateexist); 
                                        
                                    }
                                    else{
                                    $import="INSERT into prp_information values(
                                             '$data[0]','$data[1]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]',
                                            '$data[14]','$data[15]','$data[16]','$data[17]','$data[18]','$data[19]','$data[20]',
                                            '$data[21]','$data[22]','$data[23]','$data[24]','$data[25]','$tglsekarang','$tglsekarang','$loguser')";
                                    $masuk=  mysql_query($import);
                                       
                                    }
                            }
                            fclose($handle);
                           echo "<script>window.alert(' Terima kasih yaa, Data Telah Terimport');
                                    window.location=('?module=view_prp')</script>";
                               
                            }


                            else
                            {

                            print "";
                            }

                            ?>  </div>                
                 </div>
                </div>
                </div>

</BODY>
</HTML>
