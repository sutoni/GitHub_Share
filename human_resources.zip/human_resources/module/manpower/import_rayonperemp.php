
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
<h2>Import data to Database Rayon per Employee</h2>

<form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
<font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
<input type='file' name='filename' size='20'><br>
<input type='submit' name='submit' value='Insert'></form>
<br>



<?php



include "config/conn.php";
if(isset($_POST['submit']))
{
$target_path = 'c:\xampp\htdocs\human_resources\test';  

$target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
} else{
echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
} // ini untuk mengupload file CSV ke alamat tadi
// ini script untuk mengimport data CSV ke MySQL
$filename=$target_path;
$handle = fopen("$filename", "r");
while (($data = fgetcsv($handle, 10000, ",")) !== FALSE)
{
        $idrayon=$data[0];
        $rayoneffdate=$data[8];
        $idbaru=$idrayon.$rayoneffdate;
        $querycek="SELECT COUNT(idbaru)as Jumlah
                   FROM std_rayonperemployee
                   WHERE idbaru='$idbaru'
                    ";
        $hasilcek=mysql_query($querycek);
        
        $row=  mysql_fetch_array($hasilcek);
        
            $row1=$row[Jumlah];
            if($row1 > 0){
            
            $rayoncode=$data[0];
           
            $empno=$data[2];
            $personid=$data[3];
            $validfrom=$data[7];
            $validto=$data[8];
            
            
           $updaterayon    =" UPDATE std_rayonperemployee SET
                                rayoncode          =   '$rayoncode',
                                empno          =   '$empno',
                                personid         =   '$personid',
                                validfrom      =   '$validfrom',
                                validto         =   '$validto'
                                    
                                WHERE idbaru  =   '$idbaru'";       
                            $masuk=  mysql_query($updaterayon); 
                            
            }               
                
        else {
    
$import="INSERT into std_rayonperemployee values(
         '$idbaru','$data[0]','$data[2]','$data[3]','$data[7]','$data[8]'
        )
        ";
$masuk=  mysql_query($import);
      
        }
}
fclose($handle);
        echo "$import";

}


else
{

print "";
}

?>


</BODY>
</HTML>
