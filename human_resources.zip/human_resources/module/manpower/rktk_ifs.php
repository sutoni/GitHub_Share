<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
              Dashboard Rencana Kerja Tenaga Kerja (RKTK)<small>Current Year</small>
                  
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Man Power Plan</a></li>
            <li class="active">RKTK</li>
          </ol>
        </section>
        
         <!-- /.col-lg-12 -->
                <br>
                &nbsp;&nbsp;&nbsp; <a href="?module=view_organization&act=view_orgstruktur"><button type="submit" class="btn btn-default">By Unit</button></a>                
                <a href="?module=view_organization&act=view_org"><button type="submit" class="btn btn-default"  >By Position</button></a>
                <div class="btn btn-default pull-right ">
                                        <form method="post" role="form" action="?module=rec_budget&act=budgetperiode">
                                        <button class="inline" type="submit">Tahun</button>
                                            <select id="txtperiode1" name="txtperiode1" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'><a href='?module=rec_budget&act=budgetperiode'>$rsd[tahun]</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                        
                                     
                                        </form>
                                      </div>
                
                <br><br>
            <!-- /.row -->  
            
            
            
            <!-- Raw Data Applicant Submission -->
               <div class="col-md-12">
                   
                   
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Site Palembang</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit='Site Palembang '
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit='Site Palembang') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit='Site Palembang') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit='Site Palembang') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit='Site Palembang') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit='Site Palembang') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit='Site Palembang') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='Site Palembang') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='Site Palembang') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='Site Palembang') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='Site Palembang') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='Site Palembang') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='Site Palembang') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit='Site Palembang'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total Site Palembang</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
         
            <!-- Operation -->
             <div class="col-md-12">
                   
                   
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Operations</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
(SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

FROM view_rktk a
INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
WHERE b.unit='operations'
GROUP BY a.orgcode
ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit='operations') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit='operations') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit='operations') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit='operations') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit='operations') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit='operations') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='operations') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='operations') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='operations') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='operations') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='operations') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit='operations') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit='operations'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            
            <!-- Commercial -->
             <div class="col-md-12">
                   
                   
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Commercial</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit LIKE '%commercial%'
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit LIKE '%commercial%') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit LIKE '%commercial%') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit LIKE '%commercial%') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit LIKE '%commercial%') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit LIKE '%commercial%') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit LIKE '%commercial%') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%commercial%') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%commercial%') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%commercial%') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%commercial%') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%commercial%') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%commercial%') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit LIKE '%commercial%'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            
            <!-- OBU -->
            <div class="col-md-12">
                   
                   
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Overseas Business Unit</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit = 'OBU'
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit = 'OBU') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit = 'OBU') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit = 'OBU') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit = 'OBU') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit = 'OBU') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit = 'OBU') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'OBU') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'OBU') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'OBU') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'OBU') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'OBU') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'OBU') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit = 'OBU'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            
             <!-- Development HO -->
            <div class="col-md-12">
                   
                   
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Development</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit = 'Development'
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit = 'Development') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit = 'Development') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit = 'Development') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit = 'Development') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit = 'Development') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit = 'Development') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'Development') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'Development') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'Development') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'Development') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'Development') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit = 'Development') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit = 'Development'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            
            <!-- Development -->
            <div class="col-md-12">
                   
                   
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">RND</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit LIKE '%Development RND%'
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit LIKE '%Development RND%') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit LIKE '%Development RND%') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit LIKE '%Development RND%') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit LIKE '%Development RND%') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit LIKE '%Development RND%') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit LIKE '%Development RND%') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development RND%') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development RND%') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development RND%') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development RND%') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development RND%') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development RND%') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit LIKE '%Development RND%'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            
            <!-- DLBS -->
            <div class="col-md-12">
                   
                   
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">DLBS</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit LIKE '%Development DLBS%'
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit LIKE '%Development DLBS%') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit LIKE '%Development DLBS%') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit LIKE '%Development DLBS%') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit LIKE '%Development DLBS%') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit LIKE '%Development DLBS%') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit LIKE '%Development DLBS%') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development DLBS%') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development DLBS%') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development DLBS%') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development DLBS%') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development DLBS%') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Development DLBS%') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit LIKE '%Development DLBS%'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            <!-- Supporting -->
            <div class="col-md-12">      
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Supporting</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit LIKE '%Supporting%'
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit LIKE '%Supporting%') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit LIKE '%Supporting%') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit LIKE '%Supporting%') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit LIKE '%Supporting%') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit LIKE '%Supporting%') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit LIKE '%Supporting%') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Supporting%') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Supporting%') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Supporting%') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Supporting%') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Supporting%') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Supporting%') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit LIKE '%Supporting%'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            
            <!-- Others -->
            <div class="col-md-12">      
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Others</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                               
                                <th class="text-center">Organization Name</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                           
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT b.unit, b.groupunit, a.idbaru2, a.orgcode, a.orgname, 
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=01) AS rktk_jan,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=02) AS rktk_feb,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=03) AS rktk_mar,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=04) AS rktk_apr,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=05) AS rktk_mei,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=06) AS rktk_jun,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=07) AS rktk_jul,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=08) AS rktk_ags,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=09) AS rktk_sep,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=10) AS rktk_okt,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=11) AS rktk_nov,
                                        (SELECT c.adjusttotal_target FROM view_rktk c WHERE a.orgcode=c.orgcode AND c.bulan=12) AS rktk_des

                                        FROM view_rktk a
                                        INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                        WHERE b.unit LIKE '%Others%'
                                        GROUP BY a.orgcode
                                        ORDER BY b.nourut";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){
                                    
                        ?>                                        <tr class="odd gradeX">
                                                                   
                                                                    <td ><?php echo"$rsa[orgname]"; ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                   
                                                                       </td>

                                                                </tr>

                        <?php
                        }
                            
                        ?>

                      <tfoot>
                          <?php 
                                                   $sql  ="
                                                           SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 AND b.unit LIKE '%Others%') AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02 AND b.unit LIKE '%Others%') AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03 AND b.unit LIKE '%Others%') AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 AND b.unit LIKE '%Others%') AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 AND b.unit LIKE '%Others%') AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 AND b.unit LIKE '%Others%') AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 AND b.unit LIKE '%Others%') AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=08 AND b.unit LIKE '%Others%') AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=09 AND b.unit LIKE '%Others%') AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=10 AND b.unit LIKE '%Others%') AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=11 AND b.unit LIKE '%Others%') AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=12 AND b.unit LIKE '%Others%') AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            WHERE b.unit LIKE '%Others%'
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)
                                                           ";
                                                   
                                                     $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr>
                                                                     <td ><b>Total operations</td>
                                                                     <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                                                    <td align="center"><b></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            <!-- Total All -->
            <div class="col-md-12">
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Total : RKTK</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                                <th class="text-center">Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                            <th class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                            <th class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                      </tr>                 
                    </thead>
                    <tbody>
                     
                          
                          <?php 
                                                   $sql3  ="SELECT SUBSTR(a.idbaru2,1,4) AS tahun,
                                                           (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=01 ) AS rktk_jan,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=02) AS rktk_feb,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=03) AS rktk_mar,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=04 ) AS rktk_apr,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=05 ) AS rktk_mei,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=06 ) AS rktk_jun,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=07 ) AS rktk_jul,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=08 ) AS rktk_ags,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=09 ) AS rktk_sep,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=10 ) AS rktk_okt,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=11 ) AS rktk_nov,
                                                            (SELECT SUM(c.adjusttotal_target)AS rJan FROM view_rktk c INNER JOIN organization_mapping b ON c.orgcode=b.orgcode WHERE SUBSTR(a.idbaru2,1,4)=SUBSTR(c.idbaru2,1,4) AND c.bulan=12) AS rktk_des
                                                            FROM view_rktk a
                                                            INNER JOIN organization_mapping b ON a.orgcode=b.orgcode
                                                            
                                                            GROUP BY SUBSTR(a.idbaru2,1,4)
                                                            ORDER BY SUBSTR(a.idbaru2,1,4)";
                                                     $hasil1=  mysql_query($sql3);
                                                   
                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr bgcolor="FFF000" >
                                                                     <td ><b>Total Rencana Kerja Tenaga Kerja</b></td>
                                                                   <td align="center"><?php echo"$rsa[rktk_jan]";  ?> </td>
                                                                    <td align="center"><?php echo"$rsa[rktk_feb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_apr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_mei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_jul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_ags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_sep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_okt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_nov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[rktk_des]";  ?></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                                                 
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
        
        <!-- jQuery 2.1.3 -->
    <script src="../../plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='../../plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- jQuery Knob -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    

    <!-- page script -->
    
