
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<br><br>
<h2>Import data to Database Standar Rayon</h2>

<form enctype='multipart/form-data' action="<?php $_SERVER['PHP_SELF'] ?>" method='post'>
<font face=arial size=2>Silahkan Pilih file yang akan diimport:</font>
<input type='file' name='filename' size='20'><br>
<input type='submit' name='submit' value='Insert'></form>
<br>



<?php



include "config/conn.php";
if(isset($_POST['submit']))
{
$target_path = 'c:\xampp\htdocs\human_resources\test';  

$target_path = $target_path . basename( $_FILES['filename']['tmp_name']);

if(move_uploaded_file($_FILES['filename']['tmp_name'], $target_path)) {
echo "<font face=arial size=2>Report : file ". basename( $_FILES['filename']['name']). " berhasil di upload</font><br>";
} else{
echo "<font face=arial size=2>upload data gagal, silahkan ulangi lagi</font><br>";
} // ini untuk mengupload file CSV ke alamat tadi
// ini script untuk mengimport data CSV ke MySQL
$filename=$target_path;
$handle = fopen("$filename", "r");
while (($data = fgetcsv($handle, 10000, ",")) !== FALSE)
{
        $idrayon=$data[1];
        $rayoneffdate=$data[6];
        $idbaru=$idrayon.$rayoneffdate;
        $querycek="SELECT COUNT(idrayon)as Jumlah
                   FROM standar_rayon
                   WHERE idrayon='$idbaru'
                    ";
        $hasilcek=mysql_query($querycek);
        
        $row=  mysql_fetch_array($hasilcek);
        
            $row1=$row[Jumlah];
            if($row1 > 0){
            $pt=$data[0];
            $rayon_name=$data[2];
           
            $lini=$data[3];
            $linidesc=$data[4];
            $rayonvalid=$data[6];
            $rayonemail=$data[7];
            $area=$data[8];
            $nextlini=$data[9];
            
            $nextlinidesc=$data[10];
            $lastupdate=$data[11];
            $updateby=$data[12];
            $updatename=$data[13];
            $remark=$data[14];
            
           $updaterayon    =" UPDATE standar_rayon SET
                                pt          =   '$pt',
                                rayon_name          =   '$rayon_name',
                                lini         =   '$lini',
                                linidesc      =   '$linidesc',
                                rayonvalid         =   '$rayonvalid',
                                rayonemail       =   '$rayonemail',
                                area            =   '$area',
                                nextlini            =   '$nextlini',
                                nextlinidesc          =   '$nextlinidesc',
                                lastupdate         =   '$lastupdate',
                                updateby    =   '$updateby',
                                updatename       =   '$updatename',
                                remark       =   '$remark'
                                    
                                WHERE idrayon  =   '$idbaru'";       
                            $masuk=  mysql_query($updaterayon); 
                            
            }               
                
        else {
    
$import="INSERT into standar_rayon values(
         '$idbaru','$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]',
        '$data[7]','$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]',
        '$data[14]')
        ";
$masuk=  mysql_query($import);
       echo "$import";
        }
}
fclose($handle);
        echo "<script>window.alert('Data Tersimpan');
                window.location=('?module=overviewstdrayon')</script>";

}


else
{

print "";
}

?>


</BODY>
</HTML>
