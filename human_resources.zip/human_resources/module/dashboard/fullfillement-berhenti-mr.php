<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Dashboard Termination Medical Representative
            
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Fullfillment</a></li>
            <li class="active">Termination</li>
          </ol>
        </section>
        
         <!-- /.col-lg-12 -->
                <br>
                &nbsp;&nbsp;&nbsp; <a href="?module=view_organization&act=view_orgstruktur"><button type="submit" class="btn btn-default">By Unit</button></a>                
                <a href="?module=view_organization&act=view_org"><button type="submit" class="btn btn-default"  >By Position</button></a>
                <div class="btn btn-default pull-right ">
                                        <form method="post" role="form" action="?module=rec_budget&act=budgetperiode">
                                        <button class="inline" type="submit">Tahun</button>
                                            <select id="txtperiode1" name="txtperiode1" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'><a href='?module=rec_budget&act=budgetperiode'>$rsd[tahun]</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                        
                                     
                                        </form>
                                      </div>
                
                <br><br>
            <!-- /.row -->  
            
<div class="col-md-12">        
            
              <div class="box box-warning">
                <div class="box-header with-border">
                    <h3 class="box-title">Grafik Drop Out By Termination Type Medical Representative </h3><small> Current Year</small>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                   
                            <div class="box-body">
                                <!-- Grafik Company Initiated -->
                                
                                 <?php
                                    $strXML = "<graph caption=' ' subCaption='  ' pieSliceDepth='30' showBorder='0' showNames='1' formatNumberScale='0' numberSuffix='' decimalPrecision='0'>";
                                       
                                        include "config/conn.php";
                                        include "plugins/FusionCharts.php";
                                        $tanggal=date('Y-m-d');
					$pecahtglsekarang=explode("-",$tanggal);
					$datesekarang= $pecahtglsekarang[2];
					$monthsekarang= $pecahtglsekarang[1];
					$tahun= $pecahtglsekarang[0];
                                        $sqlcari  =mysql_query("SELECT
                                                                CONCAT(YEAR(`a`.`effdate`),'',`a`.`termtype`) AS `idbaru`,
                                                                YEAR(`a`.`effdate`) AS `tahun`,
                                                                MONTH(`a`.`effdate`) AS `bulan`,
                                                                `a`.`termtype` AS `termtype`,
                                                                COUNT(`a`.`empno`) AS `DO`,
                                                                (SELECT
                                                                   COUNT(`b`.`empno`) AS `total`
                                                                 FROM (`i_personnelaction` `b`
                                                                    JOIN `organization_mapping` `f`
                                                                      ON ((`b`.`orgcode` = `f`.`orgcode`))
                                                                      INNER JOIN `position_mapping` `g`
                                                                   ON(`b`.`curposid` = `g`.`idposition`)	
                                                                      )
                                                                 WHERE ((`a`.`orgname` = `b`.`orgname`)
                                                                        AND (`b`.`termtypegroup` = 'Employee initiated')
                                                                        AND (`b`.`termtype` <> 'Bad Attitude')
                                                                        AND (CONCAT(MONTH(`a`.`effdate`),'',`a`.`termtype`) = CONCAT(MONTH(`b`.`effdate`),'',`b`.`termtype`))
                                                                        AND ((`b`.`istatus` = 'Processed')
                                                                              OR (`b`.`istatus` = 'Approved')
                                                                              OR (`b`.`istatus` = 'Prepared')
                                                                              OR (`b`.`istatus` = 'Submitted'))
                                                                        AND (`a`.`patype` = 'Terminate Employee')
                                                                         AND (`g`.`poslevel` = 'MR')
                                                                        AND (`f`.`groupunit` <> 'Commercial Overseas'))) AS `turnover`,
                                                                (SELECT
                                                                   COUNT(`c`.`empno`) AS `total`
                                                                 FROM (`i_personnelaction` `c`
                                                                    JOIN `organization_mapping` `f`
                                                                      ON ((`c`.`orgcode` = `f`.`orgcode`))
                                                              INNER JOIN `position_mapping` `g`
                                                                   ON(`c`.`curposid` = `g`.`idposition`)        
                                                                      )
                                                                 WHERE ((`c`.`orgname` = `a`.`orgname`)
                                                                        AND (`c`.`termtypegroup` = 'Employee initiated')
                                                                        AND (`c`.`termtype` <> 'Bad Attitude')
                                                                        AND (`c`.`termstatus` = 'Regretted')
                                                                        AND (CONCAT(MONTH(`a`.`effdate`),'',`a`.`termtype`) = CONCAT(MONTH(`c`.`effdate`),'',`c`.`termtype`))
                                                                        AND ((`c`.`istatus` = 'Processed')
                                                                              OR (`c`.`istatus` = 'Approved')
                                                                              OR (`c`.`istatus` = 'Prepared')
                                                                              OR (`c`.`istatus` = 'Submitted'))
                                                                        AND (`a`.`patype` = 'Terminate Employee')
                                                                         AND (`g`.`poslevel` = 'MR')
                                                                        AND (`f`.`groupunit` <> 'Commercial Overseas'))) AS `toregreted`
                                                              FROM (`i_personnelaction` `a`
                                                                 JOIN `organization_mapping` `f`
                                                                   ON ((`a`.`orgcode` = `f`.`orgcode`))
                                                                  INNER JOIN `position_mapping` `g`
                                                                   ON(`a`.`curposid` = `g`.`idposition`)
                                                                   )
                                                              WHERE (((`a`.`istatus` = 'Processed')
                                                                       OR (`a`.`istatus` = 'Approved')
                                                                       OR (`a`.`istatus` = 'Prepared')
                                                                       OR (`a`.`istatus` = 'Submitted'))
                                                                     AND (`a`.`patype` = 'Terminate Employee')
                                                                     AND (`g`.`poslevel` = 'MR')
                                                                     AND (`f`.`groupunit` <> 'Commercial Overseas'))
                                                              GROUP BY CONCAT(YEAR(`a`.`effdate`),'',`a`.`termtype`)");
                                     
                                        while ($row1 = mysql_fetch_array($sqlcari)) {
                                        
                                        
                                         $strXML .= "<set name='" . $row1['termtype'] . " ' value='" . $row1['DO'] . "' color='F6BD01' />";

			
                                                   //free the resultset
                                                }
                                       $strXML .= "</graph>";
                                       
                                        echo renderChart("Column3D.swf", "", $strXML, "test1", 1200, 500);
                                        
                                         $strXML2 = "<graph caption=' ' subCaption='  ' pieSliceDepth='30' showBorder='0' showNames='1' formatNumberScale='0' numberSuffix='' decimalPrecision='0'>";
                                    $cari1="SELECT b.poslevel, COUNT(a.empno)AS jumlah
                                            FROM i_personnelaction a
                                            INNER JOIN position_mapping b ON b.idposition=a.curposid
                                            WHERE patype='Terminate Employee' AND (a.istatus !='Cancel Approved' OR a.istatus !='Cancel Processe')
                                            AND YEAR(a.effdate)=2015
                                            GROUP BY b.poslevel"    ;
                                    $hasilnya=  mysql_query($cari1);
                                      
                                        for($i=0;$i<11;$i++)
                                        {
                                            $ss=($s.$i++);
                                            echo "$ss";
                                    WHILE($rsb=  mysql_fetch_array($hasilnya)){
                                        $rsb1=$rsb['poslevel'];
                                        
                                        $s1='AFD8F8';
                                        $s2='F6BD0F';$s3='8BBA00';$s4='FF8E46';$s5='008E8E';$s6='D64646';$s7='8E468E';$s8='588526';
                                        $s9='B3AA00';
                                        $s10='008ED6';
                                            
                                      
                                            $strXML2 .= "<set name='" . $rsb['poslevel'] . " ' value='" . $rsb['jumlah'] . "' color='$ss' />"; }
                                            
                                        }
                                      //Finally, close <graph> element
                                        $strXML2 .= "</graph>";
                                        
                                        //Create the chart - Pie 3D Chart with data from $strXML
                                      
                                       echo renderChart("Pie3D.swf", "", $strXML2, "test2", 600, 500);

                             ?>
                                
                                <!-- End Grafik Company Initiated -->            
            
</div>      </div></div>      </div>
          
            <!-- Raw Data Applicant Submission -->
               
                   
            <div class="col-md-12">        
            
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Details Termination Type Group :  Company Initiate </h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                   
                            <div class="box-body">
                                
                             <table  class="table table-bordered table-hover">
                               <thead>
                                 <tr>
                                           <th class="text-center">Termination Type</th>
                                                       <th class="text-center">Jan</th>
                                                       <th class="text-center">Feb</th>
                                                       <th class="text-center">Mar</th>
                                                       <th class="text-center">Apr </th>
                                                       <th class="text-center">Mei</th>
                                                       <th class="text-center">Jun</th>
                                                       <th class="text-center">Jul</th>
                                                       <th class="text-center">Ags</th>
                                                       <th class="text-center">Sep</th>
                                                       <th class="text-center">Okt</th>
                                                       <th class="text-center">Nov</th>
                                                       <th class="text-center">Des</th>
                                                       <th class="text-center">Total</th>
                                                       <th class="text-center">%</th>
                                 </tr>
                               </thead>
                               <tbody>
                                   <?php
                                  include "config/conn.php";
                               $no=1;
                                           $sql  ="SELECT a.termtype as terminationtype, 
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=1)AS dojan,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype )AS jmlbad,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=2)AS dofeb,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=3)AS domar,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=4)AS doapr,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=5)AS domei,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=6)AS dojun,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=7)AS dojul,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=8)AS doags,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=9)AS dosep,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=10)AS dookt,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=11)AS donov,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype AND bulan=12)AS dodes,
                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude')as total,
                                                   (((SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE a.termtype=b.termtype )/(SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))*100)as persen1
                                                   FROM `resign_bytermtype_mr` a WHERE a.termtype='End of Contract' OR a.termtype='Retired' OR a.termtype='Cancel'
                                                   OR a.termtype='Failed Probation' OR a.termtype='Non Performing' OR a.termtype='Fraude' OR a.termtype='' OR a.termtype='Death'
                                                   OR a.termtype='Desertion' OR a.termtype='Bad  Attitude'
                                                   GROUP BY termtype

                                                   ";
                                           $hasil1=  mysql_query($sql);

                                           while($rsa=mysql_fetch_array($hasil1)){

                                   ?>                                        <tr class="odd gradeX">
                                                                               <td ><a href="module?detailstermtype&act=<?php echo"$rsa[terminationtype]";  ?>"><?php echo"$rsa[terminationtype] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";  ?> </a></td>
                                                                               <td align="center"><?php echo"$rsa[dojan]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[dofeb]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[domar]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[doapr]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[domei]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[dojun]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[dojul]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[doags]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[dosep]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[dookt]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[donov]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[dodes]";  ?></td>
                                                                               <td align="center"><?php echo"$rsa[jmlbad]";  ?></td>
                                                                               <td align="center"><?php $persen=round((($rsa['jmlbad']/$rsa['total'])*100),1); echo "$persen %";  ?></td>

                                                                                  </td>

                                                                           </tr>

                                   <?php
                                   }

                                   ?>

                                 <tfoot>
                                     <?php 
                                                              $sql  ="SELECT a.tahun,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE  bulan=1 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS dojan,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE  bulan=2 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS dofeb,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=3 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS domar,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE  bulan=4 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS doapr,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=5 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS domei,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=6 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS dojun,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=7 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS dojul,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=8 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS doags,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=9 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS dosep,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=10 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS dookt,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=11 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS donov,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE bulan=12 AND (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS dodes,
                                                                   (SELECT SUM(DO)AS DO1 FROM `resign_bytermtype_mr` b WHERE b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death' OR b.termtype='Desertion' OR b.termtype='Bad  Attitude')as total
                                                                   FROM `resign_bytermtype_mr` a
                                                                   WHERE a.termtype='End of Contract' OR a.termtype='Retired' OR a.termtype='Cancel' OR a.termtype='Failed Probation' OR a.termtype='Non Performing' OR a.termtype='Fraude' OR a.termtype='' OR a.termtype='Death' OR a.termtype='Desertion' OR a.termtype='Bad  Attitude'
                                                                   GROUP BY a.tahun";
                                                                $hasil1=  mysql_query($sql);

                                           while($rsa=mysql_fetch_array($hasil1)){        
                                     ?>
                                           <tr>
                                                                                <td ><b>Total Company Initiate</td>
                                                                               <td align="center"><b><?php echo"$rsa[dojan]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[dofeb]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[domar]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[doapr]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[domei]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[dojun]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[dojul]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[doags]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[dosep]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[dookt]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[donov]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[dodes]";  ?></td>
                                                                               <td align="center"><b><?php echo"$rsa[total]";  ?></td>
                                                                               <td align="center"><b></td>
                                           </tr>
                                    <?php
                                   }

                                   ?>
                               </tfoot>
                               </tbody>

                             </table>
                            </div>
                        </div>
                     
                    </div>
                         
               
            </div>
            
         
          <!-- employee initiate -->
            <div class="col-md-12">
              <div class="box box-warning">
                <div class="box-header with-border">
                    <h3 class="box-title">Details Termination Type Group :  Employee Initiate</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="col-md-12">
                        
                        
                  <table  class="table table-bordered table-hover col-md-6 row-md-12 ">
                    <thead>
                      <tr>
                                <th class="text-center">Termination Type</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">%</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT a.termtype as terminationtype, 
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=1)AS dojan,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=2)AS dofeb,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=3)AS domar,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=4)AS doapr,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=5)AS domei,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=6)AS dojun,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=7)AS dojul,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=8)AS doags,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=9)AS dosep,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=10)AS dookt,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=11)AS donov,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND bulan=12)AS dodes,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype )AS jumlahempin,
                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE a.termtype=b.termtype AND b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign')AS total2
                                        FROM `resign-byterminationtype_all` a 
                                        WHERE a.termtype='Resign to Competitor' OR a.termtype='Resign New Career'
                                        OR a.termtype='Resign Become Entrepreneuer' OR a.termtype='Resign School' OR a.termtype='Resign Work Environment' OR a.termtype='' OR a.termtype='Resign Health Condition'
                                        OR a.termtype='Resign Family Matters' OR a.termtype='Resign'
                                        GROUP BY termtype

                                        ";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){

                        ?>                                        <tr class="odd gradeX">
                                                                    <td ><?php echo"$rsa[terminationtype]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[dojan]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[dofeb]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[domar]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[doapr]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[domei]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[dojun]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[dojul]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[doags]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[dosep]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[dookt]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[donov]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[dodes]";  ?></td>
                                                                    <td align="center"><?php echo"$rsa[jumlahempin]";  ?></td>
                                                                    <td align="center" font color="blue"><?php $persen2=round((($rsa['jumlahempin']/$rsa['total2'])*100),1); echo"$persen2 %";  ?></td>
                                                               
                                                                       </td>

                                                                </tr>

                        <?php }
                        ?>
                           <tfoot>
                          <?php 
                                                   $sql3  ="SELECT 
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE  bulan=1 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS dojan,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE  bulan=2 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS dofeb,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=3 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS domar,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE  bulan=4 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS doapr,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=5 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS domei,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=6 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS dojun,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=7 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS dojul,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=8 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS doags,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=9 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS dosep,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=10 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS dookt,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=11 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS donov,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=12 AND (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS dodes
                                                        FROM `resign-byterminationtype_all` a
                                                        WHERE a.termtype='Resign to Competitor' OR a.termtype='Resign New Career' OR a.termtype='Resign Become Entrepreneuer' OR a.termtype='Resign School' OR a.termtype='Resign Work Environment' OR a.termtype='' OR a.termtype='Resign Health Condition' OR a.termtype='Resign Family Matters' OR a.termtype='Resign'
                                                        GROUP BY a.tahun";
                                                     $hasil1=  mysql_query($sql3);
                                                   
                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr >
                                                                     <td ><b>Total Employee Initiate</b></td>
                                                                    <td align="center"><b><?php echo"$rsa[dojan]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dofeb]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[domar]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[doapr]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[domei]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dojun]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dojul]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[doags]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dosep]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dookt]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[donov]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dodes]";  ?></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                    </tfoot>                                     
                    </tbody>
                   
                  </table>
                </div>
                    
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
             <!-- Total employee initiate -->
            <div class="col-md-12">
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Total : Drop Out Employee</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table  class="table table-bordered table-hover">
                    <thead>
                      <tr>
                                <th class="text-center">Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                            <th class="text-center">Jan</th>
                                            <th class="text-center">Feb</th>
                                            <th class="text-center">Mar</th>
                                            <th class="text-center">Apr </th>
                                            <th class="text-center">Mei</th>
                                            <th class="text-center">Jun</th>
                                            <th class="text-center">Jul</th>
                                            <th class="text-center">Ags</th>
                                            <th class="text-center">Sep</th>
                                            <th class="text-center">Okt</th>
                                            <th class="text-center">Nov</th>
                                            <th class="text-center">Des</th>
                                            <th class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                            <th class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                      </tr>                 
                    </thead>
                    <tbody>
                     
                          
                          <?php 
                                                   $sql3  ="SELECT 
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE  bulan=1)AS dojan,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE  bulan=2)AS dofeb,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=3 )AS domar,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE  bulan=4)AS doapr,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=5 )AS domei,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=6 )AS dojun,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=7 )AS dojul,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=8 )AS doags,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=9 )AS dosep,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=10 )AS dookt,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=11 )AS donov,
                                                        (SELECT SUM(DO)AS DO1 FROM `resign-byterminationtype_all` b WHERE bulan=12 )AS dodes
                                                        FROM `resign-byterminationtype_all` a
                                                        
                                                        GROUP BY a.tahun";
                                                     $hasil1=  mysql_query($sql3);
                                                   
                                while($rsa=mysql_fetch_array($hasil1)){        
                          ?>
                                <tr bgcolor="FFF000" >
                                                                     <td ><b>Total Drop Out Employee </b></td>
                                                                    <td align="center"><b><?php echo"$rsa[dojan]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dofeb]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[domar]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[doapr]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[domei]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dojun]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dojul]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[doags]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dosep]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dookt]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[donov]";  ?></td>
                                                                    <td align="center"><b><?php echo"$rsa[dodes]";  ?></td>
                                </tr>
                         <?php
                        }
                            
                        ?>
                                                 
                    </tbody>
                   
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
        
        <!-- jQuery 2.1.3 -->
    <script src="../../plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='../../plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- jQuery Knob -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    <SCRIPT LANGUAGE="Javascript" src="FusionCharts.js"></SCRIPT>
    <script src="plugins/FusionCharts.js" type="text/javascript"></script>
    
    
    
 <!-- page script -->
    <script>
      $(function () {
        /* ChartJS
         * -------
         * Here we will create a few charts using ChartJS
         */

        //--------------
        //- AREA CHART -
        //--------------

        // Get context with jQuery - using jQuery's .get() method.
        var areaChartCanvas = $("#areaChart").get(0).getContext("2d");
        // This will get the first returned node in the jQuery collection.
        var areaChart = new Chart(areaChartCanvas);

        var areaChartData = {
          labels: ["January", "February", "March", "April", "May", "June", "July"],
          datasets: [
            {
              label: "Electronics",
              fillColor: "rgba(210, 214, 222, 1)",
              strokeColor: "rgba(210, 214, 222, 1)",
              pointColor: "rgba(210, 214, 222, 1)",
              pointStrokeColor: "#c1c7d1",
              pointHighlightFill: "#fff",
              pointHighlightStroke: "rgba(220,220,220,1)",
              data: [65, 59, 80, 81, 56, 55, 40]
            },
            {
              label: "Digital Goods",
              fillColor: "rgba(60,141,188,0.9)",
              strokeColor: "rgba(60,141,188,0.8)",
              pointColor: "#3b8bba",
              pointStrokeColor: "rgba(60,141,188,1)",
              pointHighlightFill: "#fff",
              pointHighlightStroke: "rgba(60,141,188,1)",
              data: [28, 48, 40, 19, 86, 27, 90]
            }
          ]
        };

        var areaChartOptions = {
          //Boolean - If we should show the scale at all
          showScale: true,
          //Boolean - Whether grid lines are shown across the chart
          scaleShowGridLines: false,
          //String - Colour of the grid lines
          scaleGridLineColor: "rgba(0,0,0,.05)",
          //Number - Width of the grid lines
          scaleGridLineWidth: 1,
          //Boolean - Whether to show horizontal lines (except X axis)
          scaleShowHorizontalLines: true,
          //Boolean - Whether to show vertical lines (except Y axis)
          scaleShowVerticalLines: true,
          //Boolean - Whether the line is curved between points
          bezierCurve: true,
          //Number - Tension of the bezier curve between points
          bezierCurveTension: 0.3,
          //Boolean - Whether to show a dot for each point
          pointDot: false,
          //Number - Radius of each point dot in pixels
          pointDotRadius: 4,
          //Number - Pixel width of point dot stroke
          pointDotStrokeWidth: 1,
          //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
          pointHitDetectionRadius: 20,
          //Boolean - Whether to show a stroke for datasets
          datasetStroke: true,
          //Number - Pixel width of dataset stroke
          datasetStrokeWidth: 2,
          //Boolean - Whether to fill the dataset with a color
          datasetFill: true,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].lineColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
          //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true
        };

        //Create the line chart
        areaChart.Line(areaChartData, areaChartOptions);

        //-------------
        //- LINE CHART -
        //--------------
        var lineChartCanvas = $("#lineChart").get(0).getContext("2d");
        var lineChart = new Chart(lineChartCanvas);
        var lineChartOptions = areaChartOptions;
        lineChartOptions.datasetFill = false;
        lineChart.Line(areaChartData, lineChartOptions);

        //-------------
        //- PIE CHART -
        //-------------
        // Get context with jQuery - using jQuery's .get() method.
        var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
        var pieChart = new Chart(pieChartCanvas);
        var PieData = [
          {
            value: 100,
            color: "#f56954",
            highlight: "#f56954",
            label: "Chrome"
          },
          {
            value: 500,
            color: "#00a65a",
            highlight: "#00a65a",
            label: "IE"
          },
          {
            value: 400,
            color: "#f39c12",
            highlight: "#f39c12",
            label: "FireFox"
          },
          {
            value: 600,
            color: "#00c0ef",
            highlight: "#00c0ef",
            label: "Safari"
          },
          {
            value: 300,
            color: "#3c8dbc",
            highlight: "#3c8dbc",
            label: "Opera"
          },
          {
            value: 100,
            color: "#d2d6de",
            highlight: "#d2d6de",
            label: "Navigator"
          }
        ];
        var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 2,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
        };
        //Create pie or douhnut chart
        // You can switch between pie and douhnut using the method below.
        pieChart.Doughnut(PieData, pieOptions);

        //-------------
        //- BAR CHART -
        //-------------
        var barChartCanvas = $("#barChart").get(0).getContext("2d");
        var barChart = new Chart(barChartCanvas);
        var barChartData = areaChartData;
        barChartData.datasets[1].fillColor = "#00a65a";
        barChartData.datasets[1].strokeColor = "#00a65a";
        barChartData.datasets[1].pointColor = "#00a65a";
        var barChartOptions = {
          //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
          scaleBeginAtZero: true,
          //Boolean - Whether grid lines are shown across the chart
          scaleShowGridLines: true,
          //String - Colour of the grid lines
          scaleGridLineColor: "rgba(0,0,0,.05)",
          //Number - Width of the grid lines
          scaleGridLineWidth: 1,
          //Boolean - Whether to show horizontal lines (except X axis)
          scaleShowHorizontalLines: true,
          //Boolean - Whether to show vertical lines (except Y axis)
          scaleShowVerticalLines: true,
          //Boolean - If there is a stroke on each bar
          barShowStroke: true,
          //Number - Pixel width of the bar stroke
          barStrokeWidth: 2,
          //Number - Spacing between each of the X value sets
          barValueSpacing: 5,
          //Number - Spacing between data sets within X values
          barDatasetSpacing: 1,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
          //Boolean - whether to make the chart responsive
          responsive: true,
          maintainAspectRatio: false
        };

        barChartOptions.datasetFill = false;
        barChart.Bar(barChartData, barChartOptions);
      });
    </script>