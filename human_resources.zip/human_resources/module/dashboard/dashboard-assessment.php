<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
            
          <h1>
           Summary Assessment Management  <?php
                    $tahun = date("Y");
                    $bulan=date("M"); 
                    echo "Periode  $tahun   ";
            ?>
            
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="?module=dashboard-assessment">Dashboard</a></li>
            <li class="active">Talent Mapping</li>
          </ol>
        </section>
        
         <!-- /.col-lg-12 -->
                <br>
                &nbsp;&nbsp;&nbsp; 
                <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myModal">By Unit</button>              
                <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myPosition" >By Position</button>
                
                <div class="btn btn-default pull-right ">
                                        <form method="post" role="form" action="?module=rec_budget&act=budgetperiode">
                                        <button class="inline" type="submit">Tahun</button>
                                            <select id="txtpilihtahun" name="txtpilihtahun" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'><a href='?module=#'>$rsd[tahun]</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                        
                                     
                                        </form>
                                      </div>
                
                <br><br>
            <!-- /.row -->  
            
            <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Talent Mapping Analytics</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Assessment</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale=" 
                                                        SELECT a.tbfinal,COUNT(c.idassessment)AS jumlah,
                                                        ((COUNT(c.idassessment))/(SELECT COUNT(g.idassessment)AS totala FROM assessment_information g)*100)AS persen
                                                        FROM prp_information a
                                                        LEFT JOIN assessment_information c ON a.empno=c.empno
                                                        INNER JOIN exist_employee b ON a.empno=b.empno
                                                        WHERE SUBSTR(a.id_prp,12,6)='2.2014' AND 
                                                        SUBSTR(b.idempno1,1,4)=YEAR(CURDATE())  AND SUBSTR(b.idempno1,5,2)=MONTH(NOW()) 
                                                        GROUP BY a.tbfinal
                                                        ORDER BY a.tbfinal
                                                     ";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jumlah'];
                                                $sqlmale="
                                                        SELECT COUNT(g.idassessment)AS totala FROM assessment_information g";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['totala'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jumlah]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[tbfinal]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table> 
                        <br>
                           <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Personnel Action</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale=" 
                                                        SELECT b.patype, COUNT(idassessment)AS jml
                                                        FROM assessment_information a
                                                        INNER JOIN i_personnelaction b ON a.empno=SUBSTR(b.idbaru,1,11)
                                                        WHERE YEAR(b.effdate)=YEAR(CURDATE()) 
                                                        GROUP BY b.patype
                                                        ORDER BY b.patype
                                                     ";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jml'];
                                                $sqlmale="
                                                       SELECT COUNT(g.idassessment)AS total FROM assessment_information g";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['total'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[patype]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table> 
                        <br>
                        <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Status</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale=" 
                                                        SELECT a.istatus, COUNT(idassessment)AS JML
                                                        FROM assessment_information a
                                                        GROUP BY a.istatus
                                                        ORDER BY a.istatus
                                                     ";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jml'];
                                                $sqlmale="
                                                       SELECT COUNT(g.idassessment)AS total FROM assessment_information g";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['total'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[istatus]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table> 
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <!-- Raw Data Applicant Submission -->
               <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Talent Box 1</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Education</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT c.leveledukasi, a.tbfinal,COUNT(a.id_prp)AS jumlah,(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='1')AS TOtal,
                                                    (((COUNT(a.id_prp))/(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='1'))*100)AS PERSEN
                                                    FROM prp_information a
                                                    INNER JOIN exist_employee b ON a.empno=b.empno
                                                    INNER JOIN education_level c ON b.edulevel=c.idlevel
                                                    WHERE SUBSTR(a.id_prp,12,6)='2.2014' AND 
                                                    SUBSTR(b.idempno1,1,4)=YEAR(CURDATE())  AND SUBSTR(b.idempno1,5,2)=MONTH(NOW()) AND a.tbfinal='1'
                                                    GROUP BY c.leveledukasi
                                                    ORDER BY c.urutan";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jumlah'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rmale['TOtal'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jumlah]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[leveledukasi]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">TB 1 BY Unit</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT c.unit, a.tbfinal,COUNT(a.id_prp)AS jumlah,(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='1')AS TOtal,
                                                        (((COUNT(a.id_prp))/(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='1'))*100)AS PERSEN
                                                        FROM prp_information a
                                                        INNER JOIN exist_employee b ON a.empno=b.empno
                                                        INNER JOIN organization_mapping c ON b.orgcode=c.orgcode
                                                        WHERE SUBSTR(a.id_prp,12,6)='2.2014' AND 
                                                        SUBSTR(b.idempno1,1,4)=YEAR(CURDATE())  AND SUBSTR(b.idempno1,5,2)=MONTH(NOW()) AND a.tbfinal='1'
                                                        GROUP BY c.unit
                                                        ORDER BY c.nourut";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jumlah'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rmale['TOtal'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jumlah]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[unit]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        <br>
                        
                        <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Turn Over</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT
                                                        CONCAT(`prp_information`.`tbfinal`,'',SUBSTR(`i_personnelaction`.`idbaru`,12,4),'',SUBSTR(`i_personnelaction`.`idbaru`,17,2),'',`i_personnelaction`.`termtype`) AS `idbarubanget`,
                                                        `i_personnelaction`.`termtype` AS `termtype`,
                                                        COUNT(`i_personnelaction`.`idbaru`) AS `jml`
                                                      FROM `i_personnelaction`
                                                      LEFT JOIN `prp_information` ON `prp_information`.`empno` = `i_personnelaction`.`empno`
                                                      WHERE ((`i_personnelaction`.`patype` = 'Terminate Employee')
                                                             AND ((`i_personnelaction`.`istatus` <> 'Cancel Processe')
                                                                   OR (`i_personnelaction`.`istatus` = 'Cancel Approved')
                                                                   OR (`i_personnelaction`.`istatus` = 'Rejected'))) AND `prp_information`.`tbfinal`='1' 
                                                      GROUP BY CONCAT(`prp_information`.`tbfinal`,'',SUBSTR(`i_personnelaction`.`idbaru`,12,4),'',SUBSTR(`i_personnelaction`.`idbaru`,17,2),'',`i_personnelaction`.`termtype`)";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jml'];
                                                $sqlmale="
                                                        SELECT SUBSTR(a.idbaru,12,4)AS THN, COUNT(a.empno)AS total 
                                                        FROM i_personnelaction a 
                                                        LEFT JOIN prp_information b ON SUBSTR(a.idbaru,1,11)=SUBSTR(b.id_prp,1,11)   
                                                        WHERE SUBSTR(a.idbaru,12,4)='2015' AND a.patype='Terminate Employee' AND (a.istatus='Processed' OR a.istatus='Prepared' OR a.istatus='Approved' OR a.istatus='Submitted' )";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['total'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[termtype]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        
                        
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
         
          <!-- PA -->
          <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Talent Box 2</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Education</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT c.leveledukasi, a.tbfinal,COUNT(a.id_prp)AS jumlah,(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='2')AS TOtal,
                                                    (((COUNT(a.id_prp))/(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='2'))*100)AS PERSEN
                                                    FROM prp_information a
                                                    INNER JOIN exist_employee b ON a.empno=b.empno
                                                    INNER JOIN education_level c ON b.edulevel=c.idlevel
                                                    WHERE SUBSTR(a.id_prp,12,6)='2.2014' AND 
                                                    SUBSTR(b.idempno1,1,4)=YEAR(CURDATE())  AND SUBSTR(b.idempno1,5,2)=MONTH(NOW()) AND a.tbfinal='2'
                                                    GROUP BY c.leveledukasi
                                                    ORDER BY c.urutan";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jumlah'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rmale['TOtal'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jumlah]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[leveledukasi]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        
                        <br>
                           <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">TB 2 BY Unit</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT c.unit, a.tbfinal,COUNT(a.id_prp)AS jumlah,(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='2')AS TOtal,
                                                        (((COUNT(a.id_prp))/(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='2'))*100)AS PERSEN
                                                        FROM prp_information a
                                                        INNER JOIN exist_employee b ON a.empno=b.empno
                                                        INNER JOIN organization_mapping c ON b.orgcode=c.orgcode
                                                        WHERE SUBSTR(a.id_prp,12,6)='2.2014' AND 
                                                        SUBSTR(b.idempno1,1,4)=YEAR(CURDATE())  AND SUBSTR(b.idempno1,5,2)=MONTH(NOW()) AND a.tbfinal='2'
                                                        GROUP BY c.unit
                                                        ORDER BY c.nourut";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jumlah'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rmale['TOtal'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jumlah]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[unit]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        <br>
                        <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Turn Over</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT
                                                        CONCAT(`prp_information`.`tbfinal`,'',SUBSTR(`i_personnelaction`.`idbaru`,12,4),'',SUBSTR(`i_personnelaction`.`idbaru`,17,2),'',`i_personnelaction`.`termtype`) AS `idbarubanget`,
                                                        `i_personnelaction`.`termtype` AS `termtype`,
                                                        COUNT(`i_personnelaction`.`idbaru`) AS `jml`
                                                      FROM `i_personnelaction`
                                                      LEFT JOIN `prp_information` ON `prp_information`.`empno` = `i_personnelaction`.`empno`
                                                      WHERE ((`i_personnelaction`.`patype` = 'Terminate Employee')
                                                             AND ((`i_personnelaction`.`istatus` <> 'Cancel Processe')
                                                                   OR (`i_personnelaction`.`istatus` = 'Cancel Approved')
                                                                   OR (`i_personnelaction`.`istatus` = 'Rejected'))) AND `prp_information`.`tbfinal`='2' 
                                                      GROUP BY CONCAT(`prp_information`.`tbfinal`,'',SUBSTR(`i_personnelaction`.`idbaru`,12,4),'',SUBSTR(`i_personnelaction`.`idbaru`,17,2),'',`i_personnelaction`.`termtype`)";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jml'];
                                                $sqlmale="
                                                        SELECT SUBSTR(a.idbaru,12,4)AS THN, COUNT(a.empno)AS total 
                                                        FROM i_personnelaction a 
                                                        LEFT JOIN prp_information b ON SUBSTR(a.idbaru,1,11)=SUBSTR(b.id_prp,1,11)   
                                                        WHERE SUBSTR(a.idbaru,12,4)='2015' AND a.patype='Terminate Employee' AND (a.istatus='Processed' OR a.istatus='Prepared' OR a.istatus='Approved' OR a.istatus='Submitted' )";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['total'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[termtype]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                              
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          
            <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Talent Box 3</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Education</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT c.leveledukasi, a.tbfinal,COUNT(a.id_prp)AS jumlah,(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='3')AS TOtal,
                                                    (((COUNT(a.id_prp))/(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='3'))*100)AS PERSEN
                                                    FROM prp_information a
                                                    INNER JOIN exist_employee b ON a.empno=b.empno
                                                    INNER JOIN education_level c ON b.edulevel=c.idlevel
                                                    WHERE SUBSTR(a.id_prp,12,6)='2.2014' AND 
                                                    SUBSTR(b.idempno1,1,4)=YEAR(CURDATE())  AND SUBSTR(b.idempno1,5,2)=MONTH(NOW()) AND a.tbfinal='3'
                                                    GROUP BY c.leveledukasi
                                                    ORDER BY c.urutan";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jumlah'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rmale['TOtal'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jumlah]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[leveledukasi]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                              <br>
                        <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">TB 3 BY Unit</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT c.unit, a.tbfinal,COUNT(a.id_prp)AS jumlah,(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='3')AS TOtal,
                                                        (((COUNT(a.id_prp))/(SELECT COUNT(f.id_prp)AS jml FROM prp_information f  WHERE SUBSTR(f.id_prp,12,6)='2.2014' AND tbfinal ='3'))*100)AS PERSEN
                                                        FROM prp_information a
                                                        INNER JOIN exist_employee b ON a.empno=b.empno
                                                        INNER JOIN organization_mapping c ON b.orgcode=c.orgcode
                                                        WHERE SUBSTR(a.id_prp,12,6)='2.2014' AND 
                                                        SUBSTR(b.idempno1,1,4)=YEAR(CURDATE())  AND SUBSTR(b.idempno1,5,2)=MONTH(NOW()) AND a.tbfinal='3'
                                                        GROUP BY c.unit
                                                        ORDER BY c.nourut";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jumlah'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rmale['TOtal'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jumlah]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[unit]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                              <br>
                              <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Turn Over</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT
                                                        CONCAT(`prp_information`.`tbfinal`,'',SUBSTR(`i_personnelaction`.`idbaru`,12,4),'',SUBSTR(`i_personnelaction`.`idbaru`,17,2),'',`i_personnelaction`.`termtype`) AS `idbarubanget`,
                                                        `i_personnelaction`.`termtype` AS `termtype`,
                                                        COUNT(`i_personnelaction`.`idbaru`) AS `jml`
                                                      FROM `i_personnelaction`
                                                      LEFT JOIN `prp_information` ON `prp_information`.`empno` = `i_personnelaction`.`empno`
                                                      WHERE ((`i_personnelaction`.`patype` = 'Terminate Employee')
                                                             AND ((`i_personnelaction`.`istatus` <> 'Cancel Processe')
                                                                   OR (`i_personnelaction`.`istatus` = 'Cancel Approved')
                                                                   OR (`i_personnelaction`.`istatus` = 'Rejected'))) AND `prp_information`.`tbfinal`='3' 
                                                      GROUP BY CONCAT(`prp_information`.`tbfinal`,'',SUBSTR(`i_personnelaction`.`idbaru`,12,4),'',SUBSTR(`i_personnelaction`.`idbaru`,17,2),'',`i_personnelaction`.`termtype`)";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jml'];
                                                $sqlmale="
                                                        SELECT SUBSTR(a.idbaru,12,4)AS THN, COUNT(a.empno)AS total 
                                                        FROM i_personnelaction a 
                                                        LEFT JOIN prp_information b ON SUBSTR(a.idbaru,1,11)=SUBSTR(b.id_prp,1,11)   
                                                        WHERE SUBSTR(a.idbaru,12,4)='2015' AND a.patype='Terminate Employee' AND (a.istatus='Processed' OR a.istatus='Prepared' OR a.istatus='Approved' OR a.istatus='Submitted' )";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['total'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jml]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[termtype]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          <!-- Turnover -->
          
    
            
            
    <!-- Modal -->
                <div id="myModal" class="modal fade" role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Report by Unit</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewunit">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   <br><br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'><a href='?module=rec_budget&act=budgetperiode'>$rsd[tahun]</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                             <label>Bulan :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                                <option value="01">Januari</option>
                                                <option value="02">Februari</option>  
                                                <option value="03">Maret</option>  
                                                <option value="04">April</option>  
                                                <option value="05">Mei</option>  
                                                <option value="06">Juni</option>  
                                                <option value="07">Juli</option>  
                                                <option value="08">Agustus</option>  
                                                <option value="09">September</option>  
                                                <option value="10">Oktober</option>  
                                                <option value="11">November</option>  
                                                <option value="12">Desember</option>  
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            
                                     
                                            
                                        </form>
                                      
                            
                            <!--  -->
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>

                  </div>
                </div>
            
            <!-- Modal Position -->
                  <div id="myPosition" class="modal fade "  role="dialog">
                  <div class="modal-dialog">

                    
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Report by Position</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewposition">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'>$rsd[tahun]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   <br><br>
                                                &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                                            <label>Position Level :</label>
                                            <select id="txtposlevel" name="txtposlevel" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT poslevel FROM `position_mapping` GROUP BY poslevel";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[poslevel]'>$rsd[poslevel]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>  
                                            
                                        </form>
                                      
                            
                           
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  
                  </div>
                </div>
                    
                    <!-- End Modal Position -->
        <!-- jQuery 2.1.3 -->
    <script src="../../plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='../../plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- jQuery Knob -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    

    <!-- page script -->
    
