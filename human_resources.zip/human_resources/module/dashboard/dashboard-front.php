<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
            
          <h1>
           Summary Exist, Join, Personnel Action  <?php
                    $tahun = date("Y");
                    $bulan=date("M"); 
                    echo "Periode $bulan $tahun   ";
            ?>
            
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Dashboard</a></li>
            <li class="active">Dashboard All</li>
          </ol>
        </section>
        
         <!-- /.col-lg-12 -->
                <br>
                &nbsp;&nbsp;&nbsp; 
                <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myModal">By Unit</button>              
                <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myPosition" >By Position</button>
                
                <div class="btn btn-default pull-right ">
                                        <form method="post" role="form" action="?module=rec_budget&act=budgetperiode">
                                        <button class="inline" type="submit">Tahun</button>
                                            <select id="txtpilihtahun" name="txtpilihtahun" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'><a href='?module=#'>$rsd[tahun]</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                        
                                     
                                        </form>
                                      </div>
                
                <br><br>
            <!-- /.row -->  
            
            <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Existing Analytics</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Education</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $tanggalsekarang=date('Ymd');
                                        $tahun = date("Y");
                                        $bulan=date("m");
                                        $tahunbulan=$tahun.$bulan;
                                        
                                        $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                        $pisah = explode("-", $bulan2);
                                        $tgl = $pisah[2];
                                        $bulansebelum = $pisah[1];
                                        $thn = $pisah[0];
                                       // $bulansebelum=date_format($bulan2,'m');
                                        
                                        $tahunbulansebelum=$tahun.$bulansebelum;
                                        $no=1;
                                        
                                        
                                        $eduSql="SELECT a.leveledukasi, 
                                                (SELECT SUM(b.jml)AS jmlsekarang1 FROM view_existingeduall b WHERE SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulan' )AS jmlsekarang,
                                                (SELECT SUM(b.jml)AS jml FROM view_existingeduall b WHERE a.leveledukasi=b.leveledukasi AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulan' )AS edusekarang,
                                                (SELECT SUM(b.jml)AS jmlsekarang1 FROM view_existingeduall b WHERE SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulansebelum')AS jmlsebelum,
                                                (SELECT SUM(b.jml)AS jml FROM view_existingeduall b WHERE a.leveledukasi=b.leveledukasi AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulansebelum' )AS edusebelum,
                                                (((SELECT SUM(b.jml)AS jml FROM view_existingeduall b WHERE a.leveledukasi=b.leveledukasi AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulansebelum' )/ (SELECT SUM(b.jml)AS jmlsekarang1 FROM view_existingeduall b WHERE SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulansebelum'))*100)AS persensebelum,
                                                (((SELECT SUM(b.jml)AS jml FROM view_existingeduall b WHERE a.leveledukasi=b.leveledukasi AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulan' )/(SELECT SUM(b.jml)AS jmlsekarang1 FROM view_existingeduall b WHERE SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulan' ))*100)AS persensekarang
                                                FROM view_existingeduall a
                                                INNER JOIN education_level c ON a.leveledukasi=c.leveledukasi
                                                WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' 
                                                GROUP BY a.leveledukasi
                                                ORDER BY c.urutan";
                                       
                                        
                                        $hasiledu=  mysql_query($eduSql);
                                        WHILE($rs=mysql_fetch_array($hasiledu))
                                        {
                                            $existedusekarang=$rs['edusekarang'];
                                            $existedusebelum=$rs['edusebelum'];
                                            $jmlexistedusekarang=$rs['jmlsekarang'];
                                            $jmlexistedusebelum=$rs['jmlsebelum'];
                                            $persennya=round(($existedusekarang/$jmlexistedusekarang)*100,2);
                                            $persensebelumnya=round(($existedusebelum/$jmlexistedusebelum)*100,2);
                                            
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya  "; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                 
                                                      <?php 
                                                            
                                                            
                                                         
                                       
                                                                
                                                                  if($persensebelumnya < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelumnya == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                   
                                                  <td align="center"><?php echo "$rs[edusekarang]  ";  ?> </td>
                                                  <td align="center"><?php echo "$rs[leveledukasi]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Gender</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $tanggalsekarang=date('Ymd');
                                            $tahun = date("Y");
                                            $bulan=date("m");
                                            $tahunbulan=$tahun.$bulan;

                                            $bulan2=date('Y-m-d', strtotime('-1 month', strtotime( $tanggalsekarang )));
                                            $pisah = explode("-", $bulan2);
                                            $tgl = $pisah[2];
                                            $bulansebelum = $pisah[1];
                                            $thn = $pisah[0];
                                           // $bulansebelum=date_format($bulan2,'m');

                                            $tahunbulansebelum=$tahun.$bulansebelum;
                                            $no=1;
                                            $sqlmale="  SELECT  a.gender, COUNT(a.idempno1)AS jmlgender
                                                        FROM exist_employee a
                                                        WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan' 
                                                        GROUP BY a.gender";    
                                            $hasilmale=  mysql_query($sqlmale);
                                            WHILE($rmale=mysql_fetch_array($hasilmale))
                                            {
                                                $jmlgender=$rmale['jmlgender'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlgender/$rd['total'])*100,2);
                                            ?>          
                                            <tr class="odd gradeX">
                                                  
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  <!-- tanda perbandingan gender bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT  a.gender, COUNT(a.idempno1)AS jmlgender2
                                                                    FROM exist_employee a
                                                                    WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum' 
                                                                    GROUP BY a.gender";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlgender2=$rs2['jmlgender2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total2 FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql2=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql2);
                                                                $persennyasebelum2=round(($jmlgender2/$rd2['total2'])*100,2);
                                                                 $total2=$rd2['total2'];
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$rmale[jmlgender]";  ?> </td>
                                                  <td align="center"><?php echo "$rmale[gender]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Group Unit</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlunit="  SELECT c.groupunit,COUNT(b.idempno1)AS jmlexist
                                                    FROM exist_employee b
                                                    INNER JOIN organization_mapping c ON b.orgcode=c.orgcode
                                                    WHERE SUBSTR(b.idempno1,1,6)='$tahunbulan'
                                                    GROUP BY c.groupunit
                                                    ORDER BY c.nourut";
                                        $hasilunit=  mysql_query($sqlunit);
                                        WHILE($rsunit=  mysql_fetch_array($hasilunit))
                                        {
                                                $jmlunit=$rsunit['jmlexist'];
                                                $sqlmale="SELECT COUNT(a.idempno1)AS total FROM exist_employee a WHERE SUBSTR(a.idempno1,1,6)='$tahunbulan'";
                                                $hasilsql=  mysql_query($sqlmale);
                                                $rd=mysql_fetch_array($hasilsql);
                                                $persennya=round(($jmlunit/$rd['total'])*100,2);
                                  ?>          <tr class="odd gradeX">
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                    <!-- tanda perbandingan BY Unit bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                            $eduSql2="SELECT c.groupunit,COUNT(b.idempno1)AS jmlexist2
                                                                    FROM exist_employee b
                                                                    INNER JOIN organization_mapping c ON b.orgcode=c.orgcode
                                                                    WHERE SUBSTR(b.idempno1,1,6)='$tahunbulansebelum'
                                                                    GROUP BY c.groupunit
                                                                    ORDER BY c.nourut";
                                                            
                                                            $hasiledu2=  mysql_query($eduSql2);
                                                            WHILE($rs2=mysql_fetch_array($hasiledu2))
                                                            {
                                                                $jmlunit2=$rs2['jmlexist2'];
                                                                $sqlmale2="SELECT COUNT(a.idempno1)AS total FROM exist_employee a "
                                                                        . "WHERE SUBSTR(a.idempno1,1,6)='$tahunbulansebelum'";
                                                                $hasilsql=  mysql_query($sqlmale2);
                                                                $rd2=mysql_fetch_array($hasilsql);
                                                                $persennyasebelum2=round(($jmlunit2/$rd2['total'])*100,2);
                                                               
                                                            }
                                                              if($persennyasebelum2 < $persennya){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persennyasebelum2 == $persennya) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                      ?>
                                                  
                                                  <!--  -->
                                                  <td align="center"><?php echo "$jmlunit";  ?> </td>
                                                  <td align="center"><?php echo "$rsunit[groupunit]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>          

                              </tbody>

                            </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <!-- Raw Data Applicant Submission -->
               <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Join Analytics</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Education</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.leveledukasi, 
                                                (SELECT SUM(b.jml)AS jml FROM view_joinbyeduall b WHERE a.leveledukasi=b.leveledukasi AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 7,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulan' AND SUBSTR(b.idbarubanget, 11,2)='$bulan')AS joinedusekarang,
                                                (SELECT SUM(b.jml)AS jml FROM view_joinbyeduall b WHERE a.leveledukasi=b.leveledukasi AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 7,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulansebelum' AND SUBSTR(b.idbarubanget, 11,2)='$bulansebelum')AS joinedusebelum
                                                FROM view_joinbyeduall a
                                                INNER JOIN education_level c ON a.leveledukasi=c.leveledukasi
                                                WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun'
                                                GROUP BY a.leveledukasi
                                                ORDER BY c.urutan";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                    // echo "$sqlpa";
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                               
                                                //hitung jumlah pembagi sekarang
                                                       $sqlpembagisekarang= "SELECT 
                                                                     SUM(jml)AS jumlahbagisekarang
                                                                    FROM view_joinbyeduall a
                                                                   WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun' AND  SUBSTR(a.idbarubanget, 5,2)='$bulan' AND  SUBSTR(a.idbarubanget, 11,2)='$bulan' "; 
                                                       $hasilpembagisekarang=  mysql_query($sqlpembagisekarang);   
                                                       $rsbagisekarang=mysql_fetch_array($hasilpembagisekarang);
                                                       $jmlbagisekarang=$rsbagisekarang['jumlahbagisekarang'];
                                                 //end pembagi sekarang
                                                       
                                                  //hitung jumlah pembagi sebelum
                                                       $sqlpembagisebelum= "SELECT 
                                                                     SUM(jml)AS jumlahbagisebelum
                                                                    FROM view_joinbyeduall a
                                                                   WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun' AND  SUBSTR(a.idbarubanget, 5,2)='$bulansebelum' AND  SUBSTR(a.idbarubanget, 11,2)='$bulansebelum' "; 
                                                       $hasilpembagisebelum=  mysql_query($sqlpembagisebelum);   
                                                       $rsbagisebelum=mysql_fetch_array($hasilpembagisebelum);
                                                       $jmlbagisebelum=$rsbagisebelum['jumlahbagisebelum'];
                                                
                                                
                                                        $joinedusebelum=$rspa['joinedusebelum'];
                                                        $joinedusekarang=$rspa['joinedusekarang'];
                                               $persensekarang=round(($joinedusekarang/$jmlbagisekarang)*100,2);
                                               $persensebelumnya=round(($joinedusebelum/$jmlbagisebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persensekarang"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                          
                                                             
                                                            if($persensebelumnya < $persensekarang){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelumnya == $persensekarang) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$joinedusekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[leveledukasi]"; ?></td>

                                              </tr>

                                      <?php
                                        }
                                       ?>

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Gender</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                            include "config/conn.php";
                                            $no=1;
                                            $sqlpa="SELECT a.gender, 
                                                    (SELECT SUM(b.jml)AS jml FROM view_joinbygenderall b WHERE a.gender=b.gender AND  SUBSTR(b.idbarubanget, 1,4)='$tahun'AND SUBSTR(b.idbarubanget, 7,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulan' AND SUBSTR(b.idbarubanget, 11,2)='$bulan')AS joingendersekarang,
                                                    (SELECT SUM(b.jml)AS jml FROM view_joinbygenderall b WHERE a.gender=b.gender AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 7,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)='$bulansebelum' AND SUBSTR(b.idbarubanget, 11,2)='$bulansebelum')AS joingendersebelum
                                                   

                                                    FROM view_joinbygenderall a
                                                    WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun'
                                                    GROUP BY a.gender
                                                    ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                        
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                               // $nomor=$i++;
                                                 //hitung jumlah pembagi sekarang
                                                       $sqlpembagisekarang= "SELECT 
                                                                     SUM(jml)AS jumlahbagisekarang
                                                                    FROM view_joinbygenderall a
                                                                   WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun' AND  SUBSTR(a.idbarubanget, 5,2)='$bulan' AND  SUBSTR(a.idbarubanget, 11,2)='$bulan' "; 
                                                       $hasilpembagisekarang=  mysql_query($sqlpembagisekarang);   
                                                       $rsbagisekarang=mysql_fetch_array($hasilpembagisekarang);
                                                       $jmlbagisekarang=$rsbagisekarang['jumlahbagisekarang'];
                                                 //end pembagi sekarang
                                                       
                                                  //hitung jumlah pembagi sebelum
                                                       $sqlpembagisebelum= "SELECT 
                                                                     SUM(jml)AS jumlahbagisebelum
                                                                    FROM view_joinbygenderall a
                                                                   WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun' AND  SUBSTR(a.idbarubanget, 5,2)='$bulansebelum' AND  SUBSTR(a.idbarubanget, 11,2)='$bulansebelum' "; 
                                                       $hasilpembagisebelum=  mysql_query($sqlpembagisebelum);   
                                                       $rsbagisebelum=mysql_fetch_array($hasilpembagisebelum);
                                                       $jmlbagisebelum=$rsbagisebelum['jumlahbagisebelum'];
                                                 //end pembagi sebelum
                                               // $persennya=round($rspa['persenjoingendersekarang'],2);
                                               // $persensebelum=round($rspa['persenjoingendersebelum'],2);
                                              //  $jmlpatypesekarang=$rspa['jmljoingendersekarang'];
                                                //$jmlpatypesebelum=$rspa['jmljoingendersebelum'];
                                                $joingendersebelum=$rspa['joingendersebelum'];
                                                $joingendersekarang=$rspa['joingendersekarang'];
                                               $persengendersekarang=round(($joingendersekarang/$jmlbagisekarang)*100,2);
                                               $persengendersebelumnya=round(($joingendersebelum/$jmlbagisebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persengendersekarang"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                          
                                                             
                                                            if($persengendersebelumnya < $persengendersekarang){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persengendersebelumnya == $persengendersekarang) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$joingendersekarang ";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[gender]"; ?></td>

                                              </tr>
                                               
                                           <?php
                                        }
                                       ?>      

                              </tbody>

                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Group Unit</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.groupunit, 
                                                (SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget, 7,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND SUBSTR(b.idbarubanget,11,2)='$bulan')AS joingroupunitsekarang,
                                                (SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' )AS jmljoingroupunitsekarang,
                                                (SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget, 7,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum'AND SUBSTR(b.idbarubanget,11,2)='$bulansebelum')AS joingroupunitsebelum,
                                                (SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)<'$bulan')AS jmljoingroupunitsebelum,
                                                (((SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan')/(SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget, 1,4)='$tahun'))*100)AS persenjoingroupunitsekarang,
                                                (((SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum')/(SELECT SUM(b.jml)AS jml FROM view_joinbyunitall b WHERE a.groupunit=b.groupunit AND  SUBSTR(b.idbarubanget, 1,4)='$tahun' AND SUBSTR(b.idbarubanget, 5,2)<'$bulan'))*100)AS persenjoingroupunitsebelum

                                                FROM view_joinbyunitall a
                                                WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun'
                                                GROUP BY a.groupunit
                                                    ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                       // echo "$sqlpa";
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                              
                                                 //hitung jumlah pembagi unit sekarang
                                                       $sqlpembagisekarang= "SELECT 
                                                                     SUM(jml)AS jumlahbagisekarang
                                                                    FROM view_joinbyunitall a
                                                                   WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun' AND  SUBSTR(a.idbarubanget, 5,2)='$bulan' AND  SUBSTR(a.idbarubanget, 11,2)='$bulan' "; 
                                                       $hasilpembagisekarang=  mysql_query($sqlpembagisekarang);   
                                                       $rsbagisekarang=mysql_fetch_array($hasilpembagisekarang);
                                                       $jmlbagisekarang=$rsbagisekarang['jumlahbagisekarang'];
                                                 //end pembagi sekarang
                                                       
                                                  //hitung jumlah pembagi unit sebelum
                                                       $sqlpembagisebelum= "SELECT 
                                                                     SUM(jml)AS jumlahbagisebelum
                                                                    FROM view_joinbyunitall a
                                                                   WHERE SUBSTR(a.idbarubanget, 1,4)='$tahun' AND SUBSTR(a.idbarubanget, 7,4)='$tahun' AND  SUBSTR(a.idbarubanget, 5,2)='$bulansebelum' AND  SUBSTR(a.idbarubanget, 11,2)='$bulansebelum' "; 
                                                       $hasilpembagisebelum=  mysql_query($sqlpembagisebelum);   
                                                       $rsbagisebelum=mysql_fetch_array($hasilpembagisebelum);
                                                       $jmlbagisebelum=$rsbagisebelum['jumlahbagisebelum'];
                                                 //end pembagi sebelum     
                                                //$persennya=round($rspa['persenjoingroupunitsekarang'],2);
                                                //$persensebelum=round($rspa['persenjoingendersebelum'],2);
                                               // $jmlpatypesekarang=$rspa['jmljoingendersekarang'];
                                                //$jmlpatypesebelum=$rspa['jmljoingendersebelum'];
                                                $joingroupunitsebelum=$rspa['joingroupunitsebelum'];
                                               $joingroupunitsekarang=$rspa['joingroupunitsekarang'];
                                               
                                               $persensekarang=round(($joingroupunitsekarang/$jmlbagisekarang)*100,2);
                                               $persensebelumnya=round(($joingroupunitsebelum/$jmlbagisebelum)*100,2);
                                                
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persensekarang"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                          
                                                             
                                                             if($persensebelumnya < $persensekarang){
                                                                 echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelumnya == $persensekarang) {
                                                                    echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                    echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$joingroupunitsekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[groupunit]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>          

                              </tbody>

                            </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
         
          <!-- PA -->
          <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Personnel Action  Analytics</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">PA Type</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $no=1;
                                        $sqlpa="SELECT a.patype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan')AS patypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum')AS patypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun')AS jmlpatypesekarang,
                                                    (((SELECT SUM(b.jml) AS jmljan FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'))*100)as persensekarang,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan')AS jmlpatypesebelum,
                                                    (((SELECT SUM(b.jml) AS jmljan FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelaction b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan'))*100)as persensebelum
                                                    
                                                FROM view_personnelaction a
                                                GROUP BY a.patype ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                     
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                               // $nomor=$i++;
                                                $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                                $patypesebelum=$rspa['patypesebelum'];
                                                $patypesekarang=$rspa['patypesekarang'];
                                               
                                               // $persennya=round(($patypesekarang/$jmlpatypesekarang)*100,2);
                                               // $persennyasebelum5=round(($patypesebelum/$jmlpatypesebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[patype]"; ?></td>

                                              </tr>

                                       <?php
                                        }
                                       ?>  

                              </tbody>

                            </table>
                        <br>
                        <!-- Termination detaiil -->
                       
                              <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Terminate Employee</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT a.groupunit, a.patype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Terminate Employee')AS patypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Terminate Employee')AS patypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Terminate Employee')AS jmlpatypesekarang,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Terminate Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Terminate Employee'))*100)AS persensekarang,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Terminate Employee')AS jmlpatypesebelum,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Terminate Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Terminate Employee') )*100)AS persensebelum

                                                FROM view_personnelactionbyunit a
                                                WHERE a.patype='Terminate Employee'
                                                GROUP BY a.groupunit ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                     //echo "$sqlpa";
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                               // $nomor=$i++;
                                                $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                                $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['patypesekarang'];
                                               // $persennya=round(($patypesekarang/$jmlpatypesekarang)*100,2);
                                               // $persennyasebelum5=round(($patypesebelum/$jmlpatypesebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                           
                                                             if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[groupunit]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>
                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Promotion Type</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT a.groupunit, a.patype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Promote Employee')AS patypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Promote Employee')AS patypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Promote Employee')AS jmlpatypesekarang,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Promote Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Promote Employee'))*100)AS persensekarang,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Promote Employee')AS jmlpatypesebelum,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Promote Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Promote Employee') )*100)AS persensebelum

                                                FROM view_personnelactionbyunit a
                                                WHERE a.patype='Promote Employee'

                                                GROUP BY a.groupunit ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                     
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                               // $nomor=$i++;
                                                $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                                $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['patypesekarang'];
                                               // $persennya=round(($patypesekarang/$jmlpatypesekarang)*100,2);
                                               // $persennyasebelum5=round(($patypesebelum/$jmlpatypesebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[groupunit]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>

                            </table>
                        
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Adjust Employee Grade Type</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT a.groupunit, a.patype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Adjust Employee Grade')AS patypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Adjust Employee Grade')AS patypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Adjust Employee Grade')AS jmlpatypesekarang,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Adjust Employee Grade')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Adjust Employee Grade'))*100)AS persensekarang,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Adjust Employee Grade')AS jmlpatypesebelum,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Adjust Employee Grade')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Adjust Employee Grade') )*100)AS persensebelum

                                                FROM view_personnelactionbyunit a
                                                WHERE a.patype='Adjust Employee Grade'

                                                GROUP BY a.groupunit ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                     
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                               // $nomor=$i++;
                                                $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                                $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['patypesekarang'];
                                               // $persennya=round(($patypesekarang/$jmlpatypesekarang)*100,2);
                                               // $persennyasebelum5=round(($patypesebelum/$jmlpatypesebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[groupunit]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>

                            </table>
                        <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Change Employment Type</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT a.groupunit, a.patype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Change Employment Type')AS patypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Change Employment Type')AS patypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Change Employment Type')AS jmlpatypesekarang,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Change Employment Type')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Change Employment Type'))*100)AS persensekarang,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Change Employment Type')AS jmlpatypesebelum,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Change Employment Type')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Change Employment Type') )*100)AS persensebelum

                                                FROM view_personnelactionbyunit a
                                                WHERE a.patype='Change Employment Type'

                                                GROUP BY a.groupunit ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                     
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                              //  $nomor=$i++;
                                                $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                                $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['patypesekarang'];
                                               // $persennya=round(($patypesekarang/$jmlpatypesekarang)*100,2);
                                               // $persennyasebelum5=round(($patypesebelum/$jmlpatypesebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[groupunit]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>
                              <!-- Confirm Orientation -->
                              <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Confirm Orientation Employee</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT a.groupunit, a.patype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Confirm Orientation Employee')AS patypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Confirm Orientation Employee')AS patypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Confirm Orientation Employee')AS jmlpatypesekarang,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Confirm Orientation Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Confirm Orientation Employee'))*100)AS persensekarang,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Confirm Orientation Employee')AS jmlpatypesebelum,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Confirm Orientation Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Confirm Orientation Employee') )*100)AS persensebelum

                                                FROM view_personnelactionbyunit a
                                                WHERE a.patype='Confirm Orientation Employee'

                                                GROUP BY a.groupunit ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                     
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                               // $nomor=$i++;
                                                $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                                $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['patypesekarang'];
                                               // $persennya=round(($patypesekarang/$jmlpatypesekarang)*100,2);
                                               // $persennyasebelum5=round(($patypesebelum/$jmlpatypesebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            
                                                          if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[groupunit]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>
                            </table>
                              <!-- Confirm Probation -->
                            <br>
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Confirm Probationary Employee</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT a.groupunit, a.patype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Confirm Probationary Employee')AS patypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Confirm Probationary Employee')AS patypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Confirm Probationary Employee')AS jmlpatypesekarang,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND b.patype='Confirm Probationary Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND b.patype='Confirm Probationary Employee'))*100)AS persensekarang,
                                                (SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Confirm Probationary Employee')AS jmlpatypesebelum,
                                                (((SELECT SUM(b.jml) AS jmljan FROM view_personnelactionbyunit b WHERE a.groupunit=b.groupunit AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND b.patype='Confirm Probationary Employee')/(SELECT SUM(b.jml) AS jmldes FROM view_personnelactionbyunit b WHERE a.patype=b.patype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND b.patype='Confirm Probationary Employee') )*100)AS persensebelum

                                                FROM view_personnelactionbyunit a
                                                WHERE a.patype='Confirm Probationary Employee'

                                                GROUP BY a.groupunit ";
                                        $hasilpa=mysql_query($sqlpa);
                                        
                                     
                                        WHILE($rspa=mysql_fetch_array($hasilpa))
                                        {       
                                                //$nomor=$i++;
                                                $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                                $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['patypesekarang'];
                                               // $persennya=round(($patypesekarang/$jmlpatypesekarang)*100,2);
                                               // $persennyasebelum5=round(($patypesebelum/$jmlpatypesebelum)*100,2);
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[groupunit]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>
                            </table>
                              
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          
          <!-- Turnover -->
          <div class="col-md-3">
                <div class="box box-warning">
                <div class="box-header with-border text-center">
                    <h3 class="box-title text-center">Turn over Analytics</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                        <!-- Termination Type -->
                        
                            <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Company Initiate</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT  a.termtype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS termtypesekarang,
                                                (SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS termtypesebelum,
                                                (SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude') )AS jmltermtypesekarang,
                                                (((SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))/(SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun'  AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude')))*100)AS persensekarang
                                                ,
                                                (SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude'))AS jmltermtypesebelum,

                                                (((SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude') )/(SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan'  AND 
                                                (b.termtype='End of Contract' OR b.termtype='Retired' OR b.termtype='Cancel' OR b.termtype='Failed Probation' OR b.termtype='Non Performing' OR b.termtype='Fraude' OR b.termtype='' OR b.termtype='Death'
                                                OR b.termtype='Desertion' OR b.termtype='Bad  Attitude') ))*100)AS persensebelum

                                                FROM doterminationbytypeall a
                                                WHERE (a.termtype='End of Contract' OR a.termtype='Retired' OR a.termtype='Cancel'
                                                OR a.termtype='Failed Probation' OR a.termtype='Non Performing' OR a.termtype='Fraude' OR a.termtype='' OR a.termtype='Death'
                                                OR a.termtype='Desertion' OR a.termtype='Bad  Attitude')
                                                AND SUBSTR(a.idbarubanget,1,4)='$tahun'      
                                                GROUP BY a.termtype";
                                        $hasilpa=  mysql_query($sqlpa);
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                               $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                                //$jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                               // $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['termtypesekarang'];
                                               
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[termtype]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>
                            </table>
                        <!--  --> 
                        <BR>
                        <table  class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                    <th class="text-left" colspan="4" bgColor="#C0C0C0">Employee Initiate</th>    
                                </tr>
                              </thead>
                              <tbody>
                                  <?php
                                        include "config/conn.php";
                                        $sqlpa="SELECT a.termtype, 
                                                (SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' 
                                                AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND 
                                                (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' 
                                                OR b.termtype='Resign Work Environment' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' 
                                                OR b.termtype='Resign'))AS termtypesekarang,

                                                (SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND 
                                                (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS termtypesebelum, 
                                                (SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND 
                                                (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS jmltermtypesekarang, 
                                                (((SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulan' AND 
                                                (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))/
                                                (SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND 
                                                (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign')))*100)AS persensekarang , 
                                                (SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND 
                                                (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))AS jmltermtypesebelum, 
                                                (((SELECT SUM(b.jml) AS jmljan FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun' AND SUBSTR(b.idbarubanget,5,2)='$bulansebelum' AND 
                                                (b.termtype='Resign to Competitor' OR b.termtype='Resign New Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign Work Environment' OR b.termtype='Resign Health Condition' OR b.termtype='Resign Family Matters' OR b.termtype='Resign'))/
                                                (SELECT SUM(b.jml) AS jmldes FROM doterminationbytypeall b WHERE a.termtype=b.termtype AND SUBSTR(b.idbarubanget,1,4)='$tahun'AND SUBSTR(b.idbarubanget,5,2)<'$bulan' AND 
                                                (b.termtype='Resign TO Competitor' OR b.termtype='Resign NEW Career' OR b.termtype='Resign Become Entrepreneuer' OR b.termtype='Resign School' OR b.termtype='Resign WORK Environment' OR b.termtype='Resign Health CONDITION' OR b.termtype='Resign Family Matters' OR b.termtype='Resign')))*100)AS persensebelum 

                                                FROM doterminationbytypeall a
                                                WHERE (a.termtype='Resign to Competitor' OR a.termtype='Resign New Career' OR a.termtype='Resign Become Entrepreneuer' OR a.termtype='Resign School' OR a.termtype='Resign Work Environment' OR a.termtype='Resign Health Condition' OR a.termtype='Resign Family Matters' OR a.termtype='Resign') AND SUBSTR(a.idbarubanget,1,4)='$tahun' 
                                                GROUP BY a.termtype";
                                        $hasilpa=  mysql_query($sqlpa);
                                        
                                        WHILE($rspa=  mysql_fetch_array($hasilpa))
                                        {        
                                               $persennya=round($rspa['persensekarang'],2);
                                                $persensebelum=round($rspa['persensebelum'],2);
                                               // $jmlpatypesebelum=$rspa['jmlpatypesebelum'];
                                               // $patypesebelum=$rspa['patypesebelum'];
                                               $patypesekarang=$rspa['termtypesekarang'];
                                               
                                                 
                                  ?>          <tr class="odd gradeX">
                                      
                                                  <td align="center"><input type="text" class="knob" value="<?php echo "$persennya"; ?>% " data-thickness="0.2" data-skin="tron" data-width="50" data-height="50" data-fgColor="#39CCCC"/></td>
                                                  
                                                  <!-- tanda perbandingan PA Type bulan ini dengan bulan lalu -->
                                                         <?php 
                                                            
                                                            if($persensebelum < $persennya){
                                                                       echo "<td align='center'> ";?> <img src=" panahnaik.png" alt="Up then last month" ><?php echo "</td>";
                                                                }
                                                                elseif ($persensebelum == $persennya) {
                                                                     echo "<td align='center'> ";?> <img src="panahnetral.png" alt="Idem then last month"> <?php echo "</td>";
                                                            }
                                                                else {
                                                                   echo "<td align='center'> ";?> <img src="panahturun.png" alt="Down then last month" > <?php echo "</td>";
                                                                }
                                                            
                                                      ?>
                                                  
                                                  <!--  -->
                                                  
                                                  <td align="center"><?php echo "$patypesekarang";  ?> </td>
                                                  <td align="center"><?php echo "$rspa[termtype]"; ?></td>


                                              </tr>

                                              <?php
                                        }
                                       ?>     

                              </tbody>
                            </table>
                        <!-- -->
                            
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
    
            
            
    <!-- Modal -->
                <div id="myModal" class="modal fade" role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Report by Unit</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewunit">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   <br><br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'><a href='?module=rec_budget&act=budgetperiode'>$rsd[tahun]</a></option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                             <label>Bulan :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                                <option value="01">Januari</option>
                                                <option value="02">Februari</option>  
                                                <option value="03">Maret</option>  
                                                <option value="04">April</option>  
                                                <option value="05">Mei</option>  
                                                <option value="06">Juni</option>  
                                                <option value="07">Juli</option>  
                                                <option value="08">Agustus</option>  
                                                <option value="09">September</option>  
                                                <option value="10">Oktober</option>  
                                                <option value="11">November</option>  
                                                <option value="12">Desember</option>  
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            
                                     
                                            
                                        </form>
                                      
                            
                            <!--  -->
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>

                  </div>
                </div>
            
            <!-- Modal Position -->
                  <div id="myPosition" class="modal fade "  role="dialog">
                  <div class="modal-dialog">

                    
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Report by Position</h4>
                      </div>
                      <div class="modal-body">
                            <!--  -->
                         
                                        <form method="post" role="form" action="?module=exitinterviewposition">
                                        <button class="inline" type="submit">Generate</button>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label>Tahun :</label>
                                            <select id="txttahununit" name="txttahununit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT tahun FROM `resign-byterminationtype_all` GROUP BY tahun";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[tahun]'>$rsd[tahun]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>    
                                            &nbsp;&nbsp;&nbsp;
                                            <label>Unit :</label>
                                            <select id="txtunit" name="txtunit" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT unit FROM `organization_mapping` GROUP BY unit";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[unit]'>$rsd[unit]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>   <br><br>
                                                &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                                            <label>Position Level :</label>
                                            <select id="txtposlevel" name="txtposlevel" class="form-control inline">
                                               
                                                        <?php
                                                                include 'config/conn.php';
                                                            $cari="SELECT poslevel FROM `position_mapping` GROUP BY poslevel";
                                                            $dapat=mysql_query($cari);
                                                            WHILE($rsd=mysql_fetch_array($dapat))
                                                            {
                                                                
                                                                 echo " <option value='$rsd[poslevel]'>$rsd[poslevel]</option>";
                                                            }

                                                            ?>
                                               
                                            </select>  
                                            
                                        </form>
                                      
                            
                           
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  
                  </div>
                </div>
                    
                    <!-- End Modal Position -->
        <!-- jQuery 2.1.3 -->
    <script src="../../plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='../../plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- jQuery Knob -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    

    <!-- page script -->
    
