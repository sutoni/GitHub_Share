<!DOCTYPE html>

      <!-- Content Wrapper. Contains page content -->
      
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Dashboard Applicant Submission 
            
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Dashboard</a></li>
            <li class="active">Recruitment Process</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                    <?php
                        $sekarang=getdate();
                        $tahun= $sekarang['year'];
                        $querysubmission="SELECT COUNT(applicantid)AS Jumlah
                                            FROM applicant_personal
                                            WHERE substr(tglapply,1,4)='$tahun'";
                        $hasil=  mysql_query($querysubmission);
                        $rc= mysql_fetch_array($hasil);
                        //$jmlsubmission=$rc[Jumlah];
                     echo "<h3>$rc[Jumlah] </h3>"; ?>
                    
                     
                    
                  <p>Applicant Submission in Year</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                    
                    <?php 
                    $sekarang=getdate();
                        $tahun= $sekarang['year'];
                        
                        $appweek="SELECT  (
                                            SELECT COUNT(applicantid) AS jmlmingguini from applicant_personal
                                            WHERE yearweek(tglapply) = yearweek(curdate()))as minggu,

                                            (SELECT COUNT(applicantid) AS jmlmingguini from applicant_personal
                                            WHERE month(tglapply) = month( curdate()) )as bulan,
                                            (SELECT COUNT(applicantid)AS Jumlah
                                            FROM applicant_personal
                                            WHERE substr(tglapply,1,4)='$tahun')as tahun,    
                                                
                                            ((
                                            (SELECT COUNT(applicantid) AS jmlmingguini from applicant_personal
                                            WHERE month(tglapply) = month( curdate()) ) / (SELECT COUNT(applicantid)AS Jumlah
                                            FROM applicant_personal WHERE substr(tglapply,1,4)='$tahun')
                                                )*100)as persen

                                            FROM applicant_personal
                                            GROUP BY year(tglapply)";
                        $hasilappweek=  mysql_query($appweek);
                        $rcapweek=  mysql_fetch_array($hasilappweek);
                        //$jmlappmonth=  $rcapweek[bulan]/$rcapweek[tahun];       
                        ?>
                    <h3><?php $jmlappmonth= round($rcapweek['bulan'])/round($rcapweek['tahun']) ;   
                    echo "$jmlappmonth"; ?><sup style="font-size: 20px">%</sup></h3>
                    
                    
                  
                  <p>Applicant Submission in Month</p>
                </div>
                <div class="icon fontawesome-icon-list">
                    <input type="hidden" class="knob" value="<?php echo $jmlappmonth ; ?> " data-readonly="true" data-width="50" data-height="60" data-fgColor="#39CCCC"/>
                  
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                    <?php
                        $sekarang=getdate();
                        $tahun= $sekarang['year'];
                        
                        $appweek="SELECT  (
                                            SELECT COUNT(applicantid) AS jmlmingguini from applicant_personal
                                            WHERE yearweek(tglapply) = yearweek(curdate()))as minggu,

                                            (SELECT COUNT(applicantid) AS jmlmingguini from applicant_personal
                                            WHERE month(tglapply) = month( curdate()) )as bulan,
                                            (SELECT COUNT(applicantid)AS Jumlah
                                            FROM applicant_personal
                                            WHERE substr(tglapply,1,4)='$tahun')as tahun,    
                                                
                                            ((
                                            (SELECT COUNT(applicantid) AS jmlmingguini from applicant_personal
                                            WHERE yearweek(tglapply) = yearweek(curdate())
                                            ) / (SELECT COUNT(applicantid)AS Jumlah
                                            FROM applicant_personal WHERE substr(tglapply,1,4)='$tahun')
                                                )*100)as persen

                                            FROM applicant_personal
                                            GROUP BY year(tglapply)";
                        $hasilappweek=  mysql_query($appweek);
                        $rcapweek=  mysql_fetch_array($hasilappweek);
                        $jmlappwek=  round($rcapweek['persen']);       
                        ?>
                        <h3><?php echo "$jmlappwek "; ?><sup style="font-size: 20px">%</sup></h3>
                    
                  
                  <p>Applicant Submission in Week</p>
                </div>
                <div class="icon">
                  <input type="hidden" class="knob" value="<?php echo $jmlappwek ; ?> " data-readonly="true" data-width="50" data-height="60" data-fgColor="#39CCCC"/>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                   <?php
                        $sekarang=getdate();
                        $tahun= $sekarang['year'];
                        
                        $hariini=date('d');
                        $appday="SELECT ((
                                (SELECT COUNT(applicantid)AS jmlhariini FROM applicant_personal WHERE substr(tglapply,9,2)='$hariini')/
                                (SELECT COUNT(applicantid)AS Jumlah FROM applicant_personal WHERE substr(tglapply,1,4)='$tahun')
                                                                                )*100)as persen
                                FROM applicant_personal GROUP BY year(tglapply) ";
                        $hasilappweek=  mysql_query($appday);
                        $rcapweek=  mysql_fetch_array($hasilappweek);
                        $jmlappday=  round($rcapweek['persen']);       
                        
                       
                        ?>
                        <h3><?php echo "$jmlappday "; ?><sup style="font-size: 20px">%</sup></h3>
                  <p>Applicant Submission in Day</p>
                </div>
                <div class="icon">
                  <input type="hidden" class="knob" value="<?php echo $jmlappday ; ?> " data-readonly="true" data-width="50" data-height="60" data-fgColor="#39CCCC"/>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
             
           <!-- Grafik New Hire -->     
           <!-- Grafik New per Day -->  
           <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue"> App Submission per Month</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body text-center">
                  <div class="sparkline" data-type="line" data-spot-Radius="3" data-highlight-Spot-Color="#f39c12" data-highlight-Line-Color="#222" data-min-Spot-Color="#f56954" data-max-Spot-Color="#00a65a" data-spot-Color="#39CCCC" data-offset="90" data-width="100%" data-height="100px" data-line-Width='2' data-line-Color='#39CCCC' data-fill-Color='rgba(57, 204, 204, 0.08)'>
                  <?php
                    $carigrafbulan="
                                    SELECT( SELECT COUNT(applicantid) AS blnjan from applicant_personal
                                    WHERE month(tglapply) ='01')as jan,
                                   (SELECT COUNT(applicantid) AS blnfeb from applicant_personal
                                    WHERE month(tglapply) ='02')as feb,

                                   (SELECT COUNT(applicantid) AS blnmar from applicant_personal
                                    WHERE month(tglapply) ='03')as mar,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='04')as apr,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='05')as mei,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='06')as jun,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='07')as jul,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='08')as ags,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='09')as sep,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='10')as okt,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='11')as nov,
                                   (SELECT COUNT(applicantid) AS blnapr from applicant_personal
                                    WHERE month(tglapply) ='12')as des

                                    FROM applicant_personal
                                    WHERE year(tglapply)='2015'
                                    GROUP BY year(tglapply)
                                    ";
                                     $hasilgrapbulan=  mysql_query($carigrafbulan);
                                    $rcapgraphbulan=  mysql_fetch_array($hasilgrapbulan);
                                    $jan=$rcapgraphbulan['jan'];     
                                    $feb=$rcapgraphbulan['feb'];
                                    $mar=$rcapgraphbulan['mar'];
                                    $apr=$rcapgraphbulan['apr'];
                                    $mei=$rcapgraphbulan['mei'];
                                    $jun=$rcapgraphbulan['jun'];
                                    $jul=$rcapgraphbulan['jul'];
                                    $ags=$rcapgraphbulan['ags'];
                                    $sep=$rcapgraphbulan['sep'];
                                    $okt=$rcapgraphbulan['okt'];
                                    $nov=$rcapgraphbulan['nov'];
                                    $des=$rcapgraphbulan['des'];
                                    
                                    echo "$jan, $feb, $mar, $apr, $mei, $jun, $jul, $ags, $sep, $okt, $nov, $des";
                  ?>
                      
                  </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <!-- Grafik New per Week -->  
            <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue"> App Submission per Week</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body text-center">
                  <div class="sparkline" data-type="line" data-spot-Radius="3" data-highlight-Spot-Color="#f39c12" data-highlight-Line-Color="#222" data-min-Spot-Color="#f56954" data-max-Spot-Color="#00a65a" data-spot-Color="#39CCCC" data-offset="90" data-width="100%" data-height="100px" data-line-Width='2' data-line-Color='#39CCCC' data-fill-Color='rgba(57, 204, 204, 0.08)'>
                   10,5,7,8
                  </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <!-- Grafik New per Month -->  
            <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue"> New Hire per Month</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body text-center">
                  <div class="sparkline" data-type="line" data-spot-Radius="3" data-highlight-Spot-Color="#f39c12" data-highlight-Line-Color="#222" data-min-Spot-Color="#f56954" data-max-Spot-Color="#00a65a" data-spot-Color="#39CCCC" data-offset="90" data-width="100%" data-height="100px" data-line-Width='2' data-line-Color='#39CCCC' data-fill-Color='rgba(57, 204, 204, 0.08)'>
                   25,30,33,25,40,20,33,28,25,32,21
                  </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <!-- Grafik New per Year -->  
            <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue"> New Hire per Year in Five Year</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body text-center">
                  <div class="sparkline" data-type="line" data-spot-Radius="3" data-highlight-Spot-Color="#f39c12" data-highlight-Line-Color="#222" data-min-Spot-Color="#f56954" data-max-Spot-Color="#00a65a" data-spot-Color="#39CCCC" data-offset="90" data-width="100%" data-height="100px" data-line-Width='2' data-line-Color='#39CCCC' data-fill-Color='rgba(57, 204, 204, 0.08)'>
                   300,250,320,240,210
                  </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            
             <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue">App Submit by Education(%)</h3>
                    </div><!-- /.box-header -->
                  <div class="box-body text-center">
                    <?php
                        $getedu="SELECT SLTA,(D1 + D2 + D3 + D4) AS diploma, (S1 + S2 + S3) AS strata, S1, S2, S3, PROFESI
                                 FROM view_education_in_year ";
                        $hasil=  mysql_query($getedu);
                        $redu=  mysql_fetch_array($hasil);
                        
                    ?>                
                      <input type="text" class="knob" value="<?php echo $redu['SLTA']; ?>% " data-thickness="0.2" data-skin="tron" data-width="90" data-height="90" data-fgColor="#39CCCC"/>
                      <div class="knob-label">SLTA</div>
                    </div><!-- ./col -->
               
                 
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            
            
             <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue"></h3>
                    </div><!-- /.box-header -->
                  <div class="box-body text-center">
                    <?php
                        $getedu="SELECT SLTA,(D1 + D2 + D3 + D4) AS diploma, (S1 + S2 + S3) AS strata, S1, S2, S3, PROFESI
                                 FROM view_education_in_year ";
                        $hasil=  mysql_query($getedu);
                        $redu=  mysql_fetch_array($hasil);
                        
                    ?>                
                      <input type="text" class="knob" value="<?php echo $redu['diploma'] ; ?>% " data-thickness="0.2" data-skin="tron" data-width="90" data-height="90" data-fgColor="#39CCCC"/>
                      <div class="knob-label">DIPLOMA</div>
                    </div><!-- ./col -->
               
                 
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue"></h3>
                    </div><!-- /.box-header -->
                  <div class="box-body text-center">
                    <?php
                        $getedu="SELECT SLTA,(D1 + D2 + D3 + D4) AS diploma, (S1 + S2 + S3) AS strata, S1, S2, S3, PROFESI
                                 FROM view_education_in_year ";
                        $hasil=  mysql_query($getedu);
                        $redu=  mysql_fetch_array($hasil);
                        
                    ?>                
                      <input type="text" class="knob" value="<?php echo $redu['S1'] ; ?>% " data-skin="tron" data-thickness="0.2" data-width="90" data-height="90" data-fgColor="#39CCCC"/>
                      <div class="knob-label">STRATA 1</div>
                    </div><!-- ./col -->
               
                 
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue"></h3>
                    </div><!-- /.box-header -->
                  <div class="box-body text-center">
                    <?php
                        $getedu="SELECT SLTA,(D1 + D2 + D3 + D4) AS diploma, (S1 + S2 + S3) AS strata, S1, S2, S3, PROFESI
                                 FROM view_education_in_year ";
                        $hasil=  mysql_query($getedu);
                        $redu=  mysql_fetch_array($hasil);
                        
                    ?>                
                      <input type="text" class="knob" value="<?php echo $redu['S2'] ; ?>% " data-skin="tron" data-thickness="0.2" data-width="90" data-height="90" data-fgColor="#39CCCC"/>
                      <div class="knob-label">STRATA 2</div>
                    </div><!-- ./col -->
               
                 
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            
            
            <div class="col-md-3">
              <div class="box box-solid">
                <div class="box-header">
                  <h3 class="box-title text-blue">App Submission by Gender (%)</h3>
                    </div><!-- /.box-header -->
                  <div class="box-body text-center ">
                    <?php
                        $getedu="SELECT YEAR(tglapply), (SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='male')AS male, 
                            (SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='female')AS female, 
                            ((SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='male')/
                            ((SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='male')+(SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='female'))*100)AS persenmale,
                            ((SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='female')/
                            ((SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='male')+(SELECT COUNT(applicantid) FROM applicant_personal WHERE gender='female'))*100)AS persenfemale
                                FROM applicant_personal
                                GROUP BY YEAR(tglapply) ";
                        $hasil=  mysql_query($getedu);
                        $redu=  mysql_fetch_array($hasil);
                        //$persenmale=round($redu['persenmale']);   
                        //$persenfemale=round($redu['persen']);   
                        
                    ?>        
                
            
                      <input type="text" class="knob " value="<?php echo round($redu['persenmale'],1); ?>% " data-width="90" data-height="90" data-fgColor="#39CCCC"/>
                      <div class="knob-label">Male</div>
                        </div>
              </div>
            </div>
                 <div class="col-md-3">
              <div class="box box-solid">
                    <div class="box-header">
                  <h3 class="box-title text-blue">App Submission by Gender (%)</h3>
                    </div><!-- /.box-header -->  
                         <div class="box-body text-center">          
                      <input type="text" class="knob " value="<?php echo round($redu['persenfemale'],1) ; ?>% " data-width="90" data-height="90" data-fgColor="#39CCCC"/>
                      <div class="knob-label ">Female</div>
                    
                    
                    </div><!-- ./col -->
               
                 
              </div><!-- /.box -->
            </div><!-- /.col -->
            
            
            
            
            
            <!-- Raw Data Applicant Submission -->
               <div class="col-md-12">
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Raw Data New Hire</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                 
                    <div class="box-body">
                  <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                                <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                       include "config/conn.php";
                    $no=1;
                                $sql  ="SELECT a.applicantid, CONCAT(a.firstname,' ',a.lastname)AS nama, a.tgllahir, CONCAT(a.telpon,' / ',a.hp)AS komunikasi, a.email,
                                        b.leveledukasi,b.jurusan, c.position, c.functionalarea,a.status
                                        FROM applicant_personal a
                                        LEFT JOIN applicant_education b ON a.applicantid=b.applicantid
                                        LEFT JOIN applicant_experience c ON a.applicantid=c.applicantid";
                                $hasil1=  mysql_query($sql);

                                while($rsa=mysql_fetch_array($hasil1)){

                        ?>                                        <tr class="odd gradeX">
                                                                    <td><?php echo"$rsa[applicantid]";  ?></td>
                                                                    <td><?php echo"$rsa[nama]";  ?></td>
                                                                    <td><?php echo"$rsa[tgllahir]";  ?></td>
                                                                    <td><?php echo"$rsa[komunikasi]";  ?></td>
                                                                    <td><?php echo"$rsa[email]";  ?></td>
                                                                    <td><?php echo"$rsa[leveledukasi]";  ?></td>
                                                                    <td><?php echo"$rsa[jurusan]";  ?></td>
                                                                    <td><?php echo"$rsa[position]";  ?></td>
                                                                    <td><?php echo"$rsa[functionalarea]";  ?></td>
                                                                    <td><?php echo"$rsa[status]";  ?></td>
                                                               
                                                                       </td>

                                                                </tr>

                        <?php }
                        ?>

                    </tbody>
                    <tfoot>
                      <tr>
                          <th class="text-center">App Id</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Tgl Lahir</th>
                                            <th class="text-center">Telpon</th>
                                            <th class="text-center">Email </th>
                                            <th class="text-center">Education</th>
                                            <th class="text-center">Jurusan</th>
                                            <th class="text-center">Experience</th>
                                            <th class="text-center">Function</th>
                                            <th class="text-center">Status</th>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          
          </div><!-- /.row -->

        </section><!-- /.content -->
        <!-- jQuery 2.1.3 -->
    <script src="../../plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='../../plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- jQuery Knob -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    

    <!-- page script -->
    
