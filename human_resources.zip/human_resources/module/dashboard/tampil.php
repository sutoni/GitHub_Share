<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of tampil
 *
 * @author toni.sutoni_dxm
 */
include("koneksi.php");
$sql = mysql_query("SELECT * FROM resign_byterminationtype_all");
$result = array();
 
while($row = mysql_fetch_array($sql)){
	array_push($result, array('nama' => $row[0], 'kelas' => $row[1], 'jurusan' => $row[2]));
}
echo json_encode(array("result" => $result));

class tampil {
    //put your code here
        //include("koneksi.php");
        
        $sql = "SELECT * FROM siswa ORDER BY nama ASC";
        
        $result = array();

        while($row = mysql_fetch_array($sql)){
                array_push($result, array('nama' => $row[0], 'kelas' => $row[1], 'jurusan' => $row[2]));
        }
        echo json_encode(array("result" => $result));
}
?>